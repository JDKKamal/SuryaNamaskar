package com.live.kooralivehd.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.customviews.recyclerview.BaseRecyclerView
import com.live.customviews.recyclerview.BaseViewHolder
import com.live.kooralivehd.R
import com.live.model.api.response.video.VideoList

class VideosAdapter(private val context: Context, private val menuList: MutableList<VideoList>) : BaseRecyclerView<VideoList>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): VideoList {
        return menuList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<VideoList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_videos, parent, false))
    }

    override fun getItemCount(): Int {
        return menuList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<VideoList>(itemView) {
        var appTvDescription: AppCompatTextView? = null

        init {
            appTvDescription = itemView.findViewById(R.id.appTvDescription)
        }

        override fun populateItem(videoList: VideoList) {
            appTvDescription!!.text = videoList.title
            //AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + modelMenu.categoryImage, appIvMenuIcon!!)

            itemView.setOnClickListener { listener!!.onClickMenu(menuList[layoutPosition]) }
        }
    }

    interface ItemListener {
        fun onClickMenu(liveChannels: VideoList)
    }
}
