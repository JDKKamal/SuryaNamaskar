package com.live.presenter

import com.live.baseclass.BasePresenter
import com.live.constant.RestConstant
import com.live.interacter.InterActorCallback
import com.live.model.api.response.livechannels.LiveChannelsResponse
import com.live.view.LiveChannelView

class LiveChannelPresenter : BasePresenter<LiveChannelView>() {
    private fun callLiveChannelApiGet(swipeRefreshStatus: Int) {
        appInteractor.apiGetLiveChannel(view!!.activity(), object : InterActorCallback<LiveChannelsResponse> {
            override fun onStart() {
                when (swipeRefreshStatus) {
                    0 -> view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: LiveChannelsResponse) {
                view!!.liveChannelApiGet(response)
            }

            override fun onFinish() {
                when (swipeRefreshStatus) {
                    0 -> view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(swipeRefreshStatus: Int, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.NO_API_GET_LIVE_CHANNEL_LIST -> callLiveChannelApiGet(swipeRefreshStatus)
            }
        }
    }
}

