package com.live.view

import com.live.baseclass.BaseView
import com.live.model.api.response.todaymatch.TodayMatchResponse

interface TodayMatchView : BaseView {
    fun todayMatchApiGet(response: TodayMatchResponse)
}