package com.live.kooralivehd.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.constant.RestConstant
import com.live.customviews.recyclerview.BaseRecyclerView
import com.live.customviews.recyclerview.BaseViewHolder
import com.live.kooralivehd.R
import com.live.model.api.response.latestnews.LatestNewsList
import com.live.utils.AppUtils

class LatestNewsAdapter(private val context: Context, private val newsList: MutableList<LatestNewsList>) : BaseRecyclerView<LatestNewsList>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): LatestNewsList {
        return newsList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<LatestNewsList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_latest_news, parent, false))
    }

    override fun getItemCount(): Int {
        return newsList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<LatestNewsList>(itemView) {
        var appTvDescription: AppCompatTextView? = null
        var appIvLatestNews: AppCompatImageView? = null
        init {
            appTvDescription = itemView.findViewById(R.id.appTvDescription)
            appIvLatestNews = itemView.findViewById(R.id.appIvLatestNews)
        }

        override fun populateItem(t: LatestNewsList) {
            appTvDescription!!.text = t.newsTilte
            AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + t.image, appIvLatestNews!!)

            itemView.setOnClickListener { listener!!.onClickLatestNews(layoutPosition, newsList) }
        }
    }

    interface ItemListener {
        fun onClickLatestNews(position : Int, latestNews: MutableList<LatestNewsList>)
    }
}
