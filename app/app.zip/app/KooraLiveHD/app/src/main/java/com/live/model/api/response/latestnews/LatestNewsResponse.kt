package com.live.model.api.response.latestnews

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.live.model.api.Response

class LatestNewsResponse {

    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("latest_news_list")
    @Expose
    var latestNewsList: MutableList<LatestNewsList>? = null

}