package com.live.model.api.response.video

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.live.model.api.Response

class VideosResponse {

    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("video_list")
    @Expose
    var videoList: MutableList<VideoList>? = null

}