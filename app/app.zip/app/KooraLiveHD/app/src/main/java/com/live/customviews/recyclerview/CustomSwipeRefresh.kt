package com.live.customviews.recyclerview

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.support.v4.widget.SwipeRefreshLayout
import android.util.AttributeSet

import com.live.kooralivehd.R;

class CustomSwipeRefresh : SwipeRefreshLayout {
    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    private fun init() {
        setColorSchemeResources(R.color.colorAccent)

    }

    override fun canChildScrollUp(): Boolean {
        return false
    }
}
