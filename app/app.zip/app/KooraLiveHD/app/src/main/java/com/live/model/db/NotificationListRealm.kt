package com.restaurant.model.db

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

@RealmClass
open class NotificationList : RealmObject {
    @PrimaryKey
    var uuid: String? = null
    var title: String? = null
    var description: String? = null
    var date: String? = null

    constructor() {}

    constructor(uuid: String, title: String, description: String, date: String) {
        this.uuid = uuid
        this.title = title
        this.description = description
        this.date = date
    }
}
