package com.live.kooralivehd.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.Toolbar
import android.view.View
import com.live.baseclass.BaseActivity
import com.live.kooralivehd.R
import com.live.utils.AppUtils

class MatchInfoActivity : BaseActivity(), View.OnClickListener {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appBtnWatchNow : AppCompatButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match_info)
        activity.window.setBackgroundDrawableResource(R.drawable.background)

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        appBtnWatchNow = findViewById(R.id.appBtnWatchNow)

        appTvTitle!!.text = getString(R.string.app_name)
        appIvDrawer!!.setImageResource(R.drawable.ic_back)

        appIvDrawer!!.setOnClickListener(this)
        appBtnWatchNow!!.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> finish()
            R.id.appBtnWatchNow ->  AppUtils.startActivity(this, LiveStreamActivity::class.java)
        }
    }

    override fun onBackPressed() {
        finish()
    }
}
