package com.live.firebase

import android.content.Intent
import android.support.v4.content.LocalBroadcastManager

import com.google.firebase.iid.FirebaseInstanceId
import com.google.firebase.iid.FirebaseInstanceIdService
import com.live.constant.RestConstant
import com.live.utils.PreferenceUtils

class MyFirebaseInstanceIDService : FirebaseInstanceIdService() {
    override fun onTokenRefresh() {

        //Getting registration token
        val refreshedToken = FirebaseInstanceId.getInstance().token

        when {
            refreshedToken != null && PreferenceUtils.preferenceInstance(applicationContext).fireBaseToken != refreshedToken -> PreferenceUtils.preferenceInstance(applicationContext).fcmToken = refreshedToken
        }
        sendRegistrationToServer(refreshedToken!!)

        // Notify UI that registration has completed, so the progress indicator can be hidden.
        val registrationComplete = Intent(RestConstant.NOTIFICATION_APP)
        registrationComplete.putExtra("token", refreshedToken)
        LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete)
    }

    private fun sendRegistrationToServer(token: String) {
        //You can implement this method to store the token on your server
        //Not required for current project
    }

}
