package com.live.baseclass

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313

   * P - PRESENTER
   * V - VIEW
   * EXTENDS BASEACTIVITY
* */

import android.app.Activity
import android.os.Bundle

abstract class MVPActivity<P : BasePresenter<V>, V : BaseView> : BaseActivity() {
    var presenter: P? = null
        private set

    override val activity: Activity
        get() = this

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        presenter = createPresenter()
        presenter!!.attachView(attachView())
    }

    public override fun onDestroy() {
        super.onDestroy()
    }

    abstract fun createPresenter(): P

    abstract fun attachView(): V
}
