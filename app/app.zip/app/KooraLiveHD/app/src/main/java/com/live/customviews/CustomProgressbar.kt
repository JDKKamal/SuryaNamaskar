package com.live.customviews

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Dialog
import android.content.Context

import com.live.kooralivehd.R;

class CustomProgressbar(private val context: Context) {
    private val dialog: Dialog?

    val isShowing: Boolean?
        get() = dialog!!.isShowing

    init {
        dialog = Dialog(context, R.style.CircularProgressTransparent)
    }

    fun show(isCancelable: Boolean?) {
        dialog!!.setCancelable(isCancelable!!)
        dialog.setContentView(R.layout.progressbar_dialog)
        dialog.show()
    }

    fun hide() {
        if (dialog != null) {
            dialog.cancel()
            dialog.dismiss()
        }
    }
}
