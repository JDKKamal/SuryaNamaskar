package com.live.model.api.response.latestnews

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LatestNewsList {

    @SerializedName("id")
    @Expose
    var id: String? = null
    @SerializedName("news_tilte")
    @Expose
    var newsTilte: String? = null
    @SerializedName("image")
    @Expose
    var image: String? = null
    @SerializedName("content")
    @Expose
    var content: String? = null

}