package com.live.constant

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

interface RestConstant {
    companion object {
        var FOLDER_NAME = ""

        //TODO FIREBASE
        val NOTIFICATION_APP = "notificationFCM"

        //TODO API
        var BASE_URL = ""
        var API_GET = ""
        var IMAGE_URL = ""

        var API_GET_LIVE_CHANNEL_LIST = ""
        var API_GET_VIDEOS = ""
        var API_GET_LATEST_NEWS = ""
        var API_GET_TODAY_MATCH = ""

        //TODO API NUMBER
        var NO_API_GET_LIVE_MATCH_TODAY = 1
        var NO_API_GET_LIVE_MATCH_TOMORROW = 2
        var NO_API_GET_LIVE_CHANNEL_LIST = 3
        var NO_API_GET_LATEST_NEWS = 4
        var NO_API_GET_VIDEOS = 5

        /* DB STATUS */
        var TYPE_DELETION = 0
        var TYPE_INSERTION = 1
        var TYPE_MODIFICATION = 2

        /* ERROR CODE */
        var OK_200 = 200
        var created_201 = 201
        var accepted_202 = 202
        var non_authoritative_information_203 = 203
        var no_content_203 = 204
        var reset_content_205 = 205

        var found_302 = 302
        var see_other_303 = 303
        var not_modified_304 = 304
        var use_proxy_305 = 305
        var temporary_redirect_307 = 307
        var unused_306 = 306
        var permanent_redirect_308 = 308

        var bad_request_400 = 400 //Bad request
        var unauthorized_401 = 401
        var forbidden_403 = 403 //Account is disabled / Authentication failed / Read disabled / Insufficient account permissions
        var not_found_404 = 404
        var method_not_allowed_405 = 405
        var not_acceptable_406 = 406
        var proxy_authentication_required_407 = 407
        var request_timeout_408 = 408
        var conflict_409 = 409 //Account already exists
        var gone_410 = 410
        var length_required_411 = 411
        var precondition_failed_412 = 412
        var request_entity_too_large_413 = 413
        var unsupported_media_type_415 = 415
        var requested_range_not_satisfiable_416 = 416
        var missing_arguments_419 = 419
        var invarid_arguments_420 = 420
        var too_many_requests_429 = 429

        var internal_server_error_500 = 500
        var not_implemented_501 = 501
        var bad_gateway_502 = 502
        var service_unavailable_503 = 503
        var gateway_timeout_504 = 504
        var http_version_not_supported_505 = 505
        var network_authentication_required_511 = 511

        //TODO PARAM
        var PARAM_FACEBOOK_ID = "fb_id"
        var PARAM_GOOGLE_PLUS_ID = "gplus_id"
        var PARAM_TWITTER_ID = "twiter_id"

        var PARAM_NAME = "name"
        var PARAM_EMAIL = "email"
        var PARAM_PASSWORD = "password"
        var PARAM_PHONE = "phone"
        var PARAM_USER_ID = "user_id"
        var PARAM_CART_ID = "cart_id"
        var REST_ID = "rest_id"
        var MENU_ID = "menu_id"
        var MENU_NAME = "menu_name"
        var MENU_QTY = "menu_qty"
        var MENU_PRICE = "menu_price"
        var PARAM_MENU_LIST_CAT_ID = "menu_list_cat_id"
        var PARAM_DISTRICT_CAT = "district_cat"
        var PARAM_TITLE_NAME = "title_name"
        var PARAM_FULL_NAME = "full_name"
        var PARAM_MOBILE_NUMBER = "mobile_number"
        var PARAM_ADDRESS = "address"
        var PARAM_STATE_ID = "state_id"
        var PARAM_COUNTRY_ID = "country_id"
        var PARAM_USER_IMAGE = "user_image"

        var PARAM_RATE = "rate"
        var PARAM_MSG = "msg"
        var PARAM_MID = "mid"
        var PARAM_R_ID = "r_id"
        var PARAM_COMMENT = "comment"
        var PARAM_VIEW_MORE_COMMENT = "view_more_comment"

    }
}
