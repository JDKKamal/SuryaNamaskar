package com.live.kooralivehd.adapter

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.constant.RestConstant
import com.live.customviews.recyclerview.BaseRecyclerView
import com.live.customviews.recyclerview.BaseViewHolder
import com.live.kooralivehd.R
import com.live.kooralivehd.fragment.LatestNewsFragment
import com.live.model.parcelable.LatestNewsParcelable
import com.live.utils.AppUtils

class LatestNewsNextPreviousAdapter(private val context: Context, private val contentList: List<LatestNewsParcelable>) : BaseRecyclerView<LatestNewsParcelable>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var navigation = 0

    override fun getItem(position: Int): LatestNewsParcelable {
        return contentList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<LatestNewsParcelable> {
        return ViewHolder(inflater.inflate(R.layout.itemview_latest_news_next_previous, parent, false))
    }

    override fun getItemCount(): Int {
        return 1
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<LatestNewsParcelable>(itemView) {
        var appIvLatestNews: AppCompatImageView? = null
        var appIvNext: AppCompatImageView? = null
        var appIvPrevious: AppCompatImageView? = null
        var appTvTitle: AppCompatTextView? = null
        var appTvDescription: AppCompatTextView? = null

        init {
            appIvLatestNews = itemView.findViewById(R.id.appIvLatestNews)
            appIvNext = itemView.findViewById(R.id.appIvNext)
            appIvPrevious = itemView.findViewById(R.id.appIvPrevious)
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appTvDescription = itemView.findViewById(R.id.appTvDescription)
        }

        override fun populateItem(latestNewsList: LatestNewsParcelable) {
            /*
              appTvDescription!!.text = latestNewsList.content
              appTvTitle!!.text = latestNewsList.title
              AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + contentList[navigation].image, appIvLatestNews!!)
           */

            navigation = LatestNewsFragment.firstNavigation!!

            appTvDescription!!.text = contentList[navigation].content
            appTvTitle!!.text = contentList[navigation].title
            AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + contentList[navigation].image, appIvLatestNews!!)

            appIvNext!!.setOnClickListener({
                navigation++

                if (navigation >= contentList.size) {
                    navigation = contentList.size - 1
                } else {
                    appTvDescription!!.text = contentList[navigation].content
                    appTvTitle!!.text = contentList[navigation].title
                    AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + contentList[navigation].image, appIvLatestNews!!)
                }
            })

            appIvPrevious!!.setOnClickListener({
                --navigation

                if (navigation == -1) {
                    navigation = 0
                } else {
                    appTvDescription!!.text = contentList[navigation].content
                    appTvTitle!!.text = contentList[navigation].title
                    AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + contentList[navigation].image, appIvLatestNews!!)

                }
            })
        }
    }
}
