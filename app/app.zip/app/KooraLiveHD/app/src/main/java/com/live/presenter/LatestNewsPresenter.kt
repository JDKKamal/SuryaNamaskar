package com.live.presenter

import com.live.baseclass.BasePresenter
import com.live.constant.RestConstant
import com.live.interacter.InterActorCallback
import com.live.model.api.response.latestnews.LatestNewsResponse
import com.live.model.api.response.livechannels.LiveChannelsResponse
import com.live.model.api.response.video.VideosResponse
import com.live.view.LatestNewsView
import com.live.view.LiveChannelView
import com.live.view.VideosView

class LatestNewsPresenter : BasePresenter<LatestNewsView>() {
    private fun callLatestNewsApiGet(swipeRefreshStatus: Int) {
        appInteractor.apiGetLatestNews(view!!.activity(), object : InterActorCallback<LatestNewsResponse> {
            override fun onStart() {
                when (swipeRefreshStatus) {
                    0 -> view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: LatestNewsResponse) {
                view!!.latestNewsApiGet(response)
            }

            override fun onFinish() {
                when (swipeRefreshStatus) {
                    0 -> view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(swipeRefreshStatus: Int, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.NO_API_GET_LATEST_NEWS -> callLatestNewsApiGet(swipeRefreshStatus)
            }
        }
    }
}

