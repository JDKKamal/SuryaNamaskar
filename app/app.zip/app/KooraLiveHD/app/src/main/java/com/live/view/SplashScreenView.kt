package com.live.view

import com.live.baseclass.BaseView

interface SplashScreenView : BaseView {
    fun setSplashScreenWait()
}

