package com.live.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Handler
import com.live.baseclass.BasePresenter
import com.live.kooralivehd.MainActivity
import com.live.kooralivehd.activity.DrawerActivity
import com.live.utils.AppUtils
import com.live.view.SplashScreenView

class SplashScreenPresenter : BasePresenter<SplashScreenView>() {
    fun getSplashScreenWait(timeOut: Int) {
        Handler().postDelayed({
            AppUtils.startActivity(view!!.activity(), MainActivity::class.java)
            view!!.activity().finish()

        }, timeOut.toLong())
    }
}