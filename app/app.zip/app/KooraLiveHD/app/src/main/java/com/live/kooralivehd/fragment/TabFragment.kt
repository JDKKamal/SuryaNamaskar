package com.live.kooralivehd.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.baseclass.BaseFragment
import com.live.kooralivehd.R
import android.support.v4.view.ViewPager
import com.live.kooralivehd.adapter.viewpager.TabViewPagerAdapter

class TabFragment : BaseFragment() {
    private var tabLayout: TabLayout? = null
    private var viewPager: ViewPager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_tab, container, false)

        tabLayout = view.findViewById(R.id.tabLayout)
        viewPager = view.findViewById(R.id.viewPager)
        setupViewPager(viewPager)
        viewPager!!.offscreenPageLimit = 3

        tabLayout!!.setupWithViewPager(viewPager)
        return view
    }

    private fun setupViewPager(viewPager: ViewPager?) {
        val adapter = TabViewPagerAdapter(activity!!.supportFragmentManager)
        adapter.addFragment(TabLiveMatchFragment(), getString(R.string.tab_live_match))
        adapter.addFragment(LiveChannelsFragment(), getString(R.string.tab_live_channels))
        adapter.addFragment(LatestNewsFragment(), getString(R.string.tab_latest_news))
        adapter.addFragment(VideosFragment(), getString(R.string.tab_videos))
        viewPager!!.adapter = adapter
    }
}
