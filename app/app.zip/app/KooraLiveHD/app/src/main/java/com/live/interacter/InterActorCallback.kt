package com.live.interacter

/*
   Developed BY live Solution
   info@live.com
   +91 9601501313
*/

interface InterActorCallback<in T> {

    fun onStart()

    fun onResponse(response: T)

    fun onFinish()

    fun onError(message: String)
}
