package com.live.view

import com.live.baseclass.BaseView
import com.live.model.api.response.livechannels.LiveChannelsResponse

interface LiveChannelView : BaseView {
    fun liveChannelApiGet(response: LiveChannelsResponse)
}

