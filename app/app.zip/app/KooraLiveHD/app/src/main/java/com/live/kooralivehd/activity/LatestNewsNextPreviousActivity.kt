package com.live.kooralivehd.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.View
import com.live.baseclass.BaseActivity
import com.live.constant.AppConstant
import com.live.kooralivehd.R
import com.live.kooralivehd.adapter.LatestNewsNextPreviousAdapter
import com.live.model.parcelable.LatestNewsParcelable
import com.live.utils.AppUtils

class LatestNewsNextPreviousActivity : BaseActivity() {

    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null

    private var parcelableLatestNews: List<LatestNewsParcelable>? = null

    private var recyclerView: RecyclerView? = null

    private lateinit var latestNewsAdapter: LatestNewsNextPreviousAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_latest_news_next_previous)
        activity.window.setBackgroundDrawableResource(R.drawable.background)

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)

        appTvTitle!!.text = getString(R.string.app_name)
        appIvDrawer!!.setImageResource(R.drawable.ic_back)

        appIvDrawer!!.setOnClickListener { finish() }

        recyclerView = findViewById(R.id.recyclerView)
        setRecyclerView(recyclerView!!, 0, 0)

        parcelableLatestNews = AppUtils.getParcelable(activity, AppConstant.BUNDLE_PARCELABLE)
        when {
            parcelableLatestNews != null -> {
                latestNewsAdapter = LatestNewsNextPreviousAdapter(activity!!, parcelableLatestNews!!)
                recyclerView!!.adapter = latestNewsAdapter
            }
        }
    }
}
