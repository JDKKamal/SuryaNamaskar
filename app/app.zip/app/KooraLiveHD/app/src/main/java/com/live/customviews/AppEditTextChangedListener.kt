package com.live.customviews

import android.support.v7.widget.AppCompatEditText
import android.text.Editable
import android.text.TextWatcher

class AppEditTextChangedListener(private val mListener: OnEditTextChangedListener, private val appCompatEditText: AppCompatEditText) : TextWatcher {

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
        //mListener.onBeforeTextChanged(s.toString())
    }

    override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
        //mListener.onTextChanged(s.toString())
    }

    override fun afterTextChanged(s: Editable) {
        mListener.onAfterTextChanged(s.toString())
    }

    interface OnEditTextChangedListener {
        fun onAfterTextChanged(str: String)
        //fun onTextChanged(str: String)
        //fun onBeforeTextChanged(str: String)
    }
}
