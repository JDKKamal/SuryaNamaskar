package com.live.model.api

class Response(var code: Int? = null, var message: String? = null, var urlpath: String? = null)
