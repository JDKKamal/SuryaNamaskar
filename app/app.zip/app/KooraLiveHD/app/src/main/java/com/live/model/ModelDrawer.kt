package com.live.model

class ModelDrawer {
    var icon: Int = 0
    var title: Int? = null

    constructor(icon: Int, title: Int) {
        this.icon = icon
        this.title = title
    }
}