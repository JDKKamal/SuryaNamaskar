package com.live.customviews.recyclerview

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.support.v7.widget.RecyclerView
import android.view.View


abstract class BaseViewHolder<T>(itemView: View) : RecyclerView.ViewHolder(itemView) {
    abstract fun populateItem(t: T)
}
