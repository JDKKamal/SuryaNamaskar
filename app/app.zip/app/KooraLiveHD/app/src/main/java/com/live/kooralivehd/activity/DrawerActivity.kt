package com.live.kooralivehd.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.os.Bundle
import android.support.v4.app.FragmentManager
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.Toolbar
import android.view.View
import com.live.baseclass.BaseActivity
import com.live.kooralivehd.R
import com.live.kooralivehd.fragment.FragmentDrawer
import com.live.kooralivehd.fragment.TabFragment
import com.live.utils.AppUtils
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class DrawerActivity : BaseActivity(), View.OnClickListener, FragmentDrawer.FragmentDrawerListener {

    private var toolBar: Toolbar? = null
    private var drawer: DrawerLayout? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appIvNotification: AppCompatImageView? = null

    private var fm: FragmentManager? = null
    private var drawerFragment: FragmentDrawer? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawer)

        fm = supportFragmentManager

        drawer = findViewById(R.id.drawer_layout)

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        appIvNotification = toolBar!!.findViewById(R.id.appIvNotification)

        appTvTitle!!.text = getString(R.string.app_name)
        appIvDrawer!!.setImageResource(R.drawable.ic_drawer)

        drawerFragment = supportFragmentManager.findFragmentById(R.id.fragment_navigation_drawer) as FragmentDrawer
        drawerFragment!!.setUp(R.id.fragment_navigation_drawer, findViewById(R.id.drawer_layout))
        drawerFragment!!.setDrawerListener(this)

        val fragmentTransaction = fm!!.beginTransaction()
        fragmentTransaction.replace(R.id.fragment, TabFragment())
        fragmentTransaction.commit()

        appIvDrawer!!.setOnClickListener(this)
        appIvNotification!!.setOnClickListener(this)
    }

    override fun onBackPressed() {
        appExist()
    }

    private fun drawerClose() {
        drawer!!.closeDrawer(GravityCompat.START)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> drawer!!.openDrawer(GravityCompat.START)

            R.id.appIvNotification -> AppUtils.startActivity(activity, NotificationActivity::class.java)
        }
    }

    override fun onDrawerItemSelected(view: View, position: Int) {
        drawerMenuClick(position)
        drawerClose()
    }

    private fun drawerMenuClick(id: Int) {
        when (id) {
            0 -> {

            }

            1 -> {

            }

            2 -> {

            }
        }
    }
}
