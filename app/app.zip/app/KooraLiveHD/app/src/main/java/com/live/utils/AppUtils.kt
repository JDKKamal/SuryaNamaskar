package com.live.utils

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Parcelable
import android.provider.MediaStore
import android.support.annotation.IdRes
import android.support.v7.widget.AppCompatImageView
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.live.customviews.CircleImageView
import com.live.kooralivehd.R
import org.parceler.Parcels
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.NumberFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

object AppUtils {

    private val workingDirectory: File
        get() {
            val directory = File(Environment.getExternalStorageDirectory(), "Mowadcom")
            return createDirectory(directory)
        }

    fun showToast(activity: Activity, message: String?) {
        val toast = Toast.makeText(activity, message + "", Toast.LENGTH_SHORT)
        val textView = toast.view.findViewById<TextView>(android.R.id.message)
        if (textView != null) textView.gravity = Gravity.CENTER
        toast.show()
    }

    private fun getStringFromId(context: Context, id: Int): String? {
        var str: String? = null
        try {
            str = context.getString(id)
        } catch (e: Exception) {
        }

        return str
    }

    fun isInternet(activity: Activity): Boolean {
        val connectivityManager = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        @SuppressLint("MissingPermission") val networkInfo = connectivityManager.activeNetworkInfo
        if (!(networkInfo != null && networkInfo.isConnectedOrConnecting)) {
            showToast(activity, activity.getString(R.string.no_internet_message))
            return false
        }
        return true
    }

    private fun createDirectory(file: File): File {
        if (!file.exists()) {
            file.mkdir()
        }
        return file
    }

    fun startActivity(context: Context, className: Class<*>) {
        val intent = Intent(context, className)
        context.startActivity(intent)
    }

    //Parcel
    fun launchIsClearParcelable(activity: Activity, classType: Class<*>, bundle: Bundle, status: Int) {
        val intent = Intent(activity, classType)
        if (status == 0) {
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        intent.putExtra("bundle", bundle)
        activity.startActivity(intent)
    }

    fun sentParcelsLaunchClear(activity: Activity, classType: Class<*>, bundleName: String, alData: List<*>, status: Int) {
        val bundle = Bundle()
        bundle.putParcelable(bundleName, Parcels.wrap<Any>(alData))
        launchParcel(activity, classType, bundle, status)
    }

    fun launchParcel(activity: Activity, classType: Class<*>, data: Bundle, status: Int) {
        val intent = Intent(activity, classType)
        if (status == 0) {
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        intent.putExtras(data)
        activity.startActivity(intent)
    }

    fun shareLink(activity: Activity, link: String, subject: String, chooseName: String) {
        var intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_TEXT, link)
        intent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject)
        activity.startActivity(Intent.createChooser(intent, chooseName))
    }

    /* TODO LAUNCH ACTIVITY */
    fun <T> getParcelable(activity: Activity, bundleName: String): T? {
        return Parcels.unwrap<T>(activity.intent.getParcelableExtra<Parcelable>(bundleName))
    }

    @Throws(ParseException::class)
    fun getDateTimeInMilliseconds(date: String): Long {
        val sdf = SimpleDateFormat("EEE MMM dd yyyy")
        val mDate = sdf.parse(date)
        return mDate.time
    }

    fun getFormatNumber(`val`: String): String {
        var d = 0.0
        d = try {
            java.lang.Double.parseDouble(`val`)
        } catch (e: Exception) {
            0.00
        }

        // return String.format("%.2f",NumberFormat.getNumberInstance(Locale.UK).format(d));
        return NumberFormat.getNumberInstance(Locale.UK).format(d) + ""
    }

    fun readFile(fileName: String, extension: String, activity: Activity): String? {
        //TODO val readFile = AppUtils.readFile("json/address", "txt", this);
        return try {
            val inputStream: InputStream = activity.assets.open("$fileName.$extension")
            val inputString = inputStream.bufferedReader().use { it.readText() }
            inputString
        } catch (ex: Exception) {
            ex.toString()
        }
    }

    fun isPackageExist(context: Context, pckName: String): Boolean {
        try {
            val pckInfo = context.packageManager.getPackageInfo(pckName, 0)
            if (pckInfo != null) {
                return true
            }
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("", e.message)
        }

        return false
    }

    fun glideSetAppImageView(context: Context, imageUrl: String, circleImageView: CircleImageView) {
        Glide.with(context).load(imageUrl).into(circleImageView)
    }

    fun glideSetAppImageView(context: Context, imageUrl: String, appIv: AppCompatImageView) {
        Glide.with(context).load(imageUrl).into(appIv)
    }

    fun <T : View> Activity.bind(@IdRes idRes: Int): Lazy<T> {
        @Suppress("UNCHECKED_CAST")
        return unsafeLazy { findViewById<T>(idRes) }
    }

    fun <T : View> View.bind(@IdRes idRes: Int): Lazy<T> {
        @Suppress("UNCHECKED_CAST")
        return unsafeLazy { findViewById<T>(idRes) }
    }

    private fun <T> unsafeLazy(initializer: () -> T) = lazy(LazyThreadSafetyMode.NONE, initializer)
}
