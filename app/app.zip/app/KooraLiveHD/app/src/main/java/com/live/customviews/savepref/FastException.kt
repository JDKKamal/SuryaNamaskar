package com.live.customviews.savepref

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

class FastException(message: String) : RuntimeException(message)
