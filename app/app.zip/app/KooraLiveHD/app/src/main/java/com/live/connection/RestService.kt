package com.live.connection

import com.live.model.api.response.latestnews.LatestNewsResponse
import com.live.model.api.response.livechannels.LiveChannelsResponse
import com.live.model.api.response.todaymatch.TodayMatchResponse
import com.live.model.api.response.video.VideosResponse
import io.reactivex.Observable
import retrofit2.http.GET
import retrofit2.http.Url

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

interface RestService {
    @GET
    fun apiGetTodayMatch(@Url url: String): Observable<TodayMatchResponse>

    @GET
    fun apiGetLiveChannel(@Url url: String): Observable<LiveChannelsResponse>

    @GET
    fun apiGetVideo(@Url url: String): Observable<VideosResponse>

    @GET
    fun apiGetLatestNews(@Url url: String): Observable<LatestNewsResponse>

}


