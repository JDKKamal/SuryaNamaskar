package com.live.kooralivehd.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.*
import android.view.View
import android.widget.RelativeLayout
import com.live.baseclass.BaseActivity
import com.live.db.DBQuery
import com.live.kooralivehd.R
import com.live.kooralivehd.adapter.NotificationAdapter
import com.live.utils.AppUtils
import com.restaurant.model.db.NotificationList
import java.util.*

class NotificationActivity : BaseActivity(), View.OnClickListener {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var rvNotification: RelativeLayout? = null

    private var recyclerView: RecyclerView? = null
    private lateinit var notificationAdapter: NotificationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)
        activity!!.window.setBackgroundDrawableResource(R.drawable.background)

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        rvNotification = toolBar!!.findViewById(R.id.rvNotification)

        recyclerView = findViewById(R.id.recyclerView)

        appTvTitle!!.text = getString(R.string.app_name)
        appIvDrawer!!.setImageResource(R.drawable.ic_back)
        rvNotification!!.visibility = View.GONE

        setRecyclerView(recyclerView!!, recyclerViewLinearLayout, recyclerViewLinearLayout)

        appIvDrawer!!.setOnClickListener(this)

        DBQuery.with(this).realmInsert(NotificationList(UUID.randomUUID().toString(), "Title", "Description", "17-05-2018"))
        var notificationList = DBQuery.with(this).realmList()

        notificationAdapter = NotificationAdapter(this, notificationList as MutableList<NotificationList>)
        recyclerView!!.adapter = notificationAdapter


    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> finish()
            R.id.appBtnWatchNow -> AppUtils.startActivity(this, LiveStreamActivity::class.java)
        }
    }

    override fun onBackPressed() {
        finish()
    }
}
