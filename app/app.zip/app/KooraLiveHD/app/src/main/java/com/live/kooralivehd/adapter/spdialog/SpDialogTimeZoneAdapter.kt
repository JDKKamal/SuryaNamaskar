package com.live.kooralivehd.adapter.spdialog

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatRadioButton
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.kooralivehd.R
import com.live.model.api.response.TimeZoneResponse
import com.live.utils.PreferenceUtils
import java.util.ArrayList

class SpDialogTimeZoneAdapter(private val context: Context, alList: MutableList<TimeZoneResponse>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private val searchList = ArrayList<TimeZoneResponse>()

    private var alList = ArrayList<TimeZoneResponse>()
    private var listener: OnItemClick? = null
    private var lastCheckedPosition = 0

    init {
        this.alList = alList as ArrayList<TimeZoneResponse>
        this.searchList.addAll(alList)
        lastCheckedPosition = PreferenceUtils.preferenceInstance(context).timeZoneId
    }

    fun setOnListener(listener: OnItemClick) {
        this.listener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.itemview_sp_timezone, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ViewHolder).setData(position)
    }

    override fun getItemCount(): Int {
        return alList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        internal var appTvTitle: AppCompatTextView
        internal var appRbSelect: AppCompatRadioButton
        internal var position: Int = 0

        init {
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appRbSelect = itemView.findViewById(R.id.appRbSelect)

            appRbSelect.setOnClickListener {
                listener!!.selectedItem(alList[layoutPosition].id!!, alList[layoutPosition])
                lastCheckedPosition = alList[layoutPosition].id!!

                notifyItemRangeChanged(0, alList.size)
            }
        }

        fun setData(position: Int) {
            this.position = position

            appRbSelect.isChecked = alList[layoutPosition].id == lastCheckedPosition
            val timeZoneResponse = alList[position]
            appTvTitle.text = timeZoneResponse.text
        }
    }

    fun filter(text: String) {
        var text = text
        alList.clear()
        if (text.isEmpty()) {
            alList.addAll(searchList)
        } else {
            text = text.toLowerCase()

            if (searchList[0] is TimeZoneResponse) {
                for (i in searchList.indices) {
                    val timeZoneResponse = searchList[i]
                    if (timeZoneResponse.text!!.toLowerCase().contains(text)) {
                        alList.add(timeZoneResponse)
                    }
                }
            }
        }
        notifyDataSetChanged()
    }

    interface OnItemClick {
        fun selectedItem(id : Int, timeZoneResponse : TimeZoneResponse)
    }
}