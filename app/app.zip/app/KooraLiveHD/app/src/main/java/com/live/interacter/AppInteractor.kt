package com.live.interacter

/*
   Developed BY live Solution
   info@live.com
   +91 9601501313
*/

/*
 * TODO COMMON LOGIC API CALL, DATABASE ETC.
 */

import android.app.Activity
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Base64
import com.live.connection.RestClient
import com.live.constant.RestConstant
import com.live.interacter.operators.RxAPICallDisposingObserver
import com.live.model.ModelOSInfo
import com.live.model.api.response.latestnews.LatestNewsResponse
import com.live.model.api.response.livechannels.LiveChannelsResponse
import com.live.model.api.response.todaymatch.TodayMatchResponse
import com.live.model.api.response.video.VideosResponse
import com.live.utils.logInfo
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.security.MessageDigest

class AppInteractor : RestConstant {

    //TODO DEFAULT
    fun getDeviceInfo(activity: Activity): List<ModelOSInfo> {
        val packageInfo: PackageInfo
        val deviceUniqueId: String
        val deviceType: String
        val deviceName: String
        val osVersion: String
        var appVersion = ""
        val countryIso: String
        val networkOperatorName: String

        deviceUniqueId = Settings.Secure.getString(activity.contentResolver, Settings.Secure.ANDROID_ID)
        deviceType = "Android"
        deviceName = Build.BRAND + Build.MODEL
        osVersion = Build.VERSION.RELEASE

        try {
            packageInfo = activity.packageManager.getPackageInfo(activity.packageName, 0)
            appVersion = packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }

        val tm = activity.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        countryIso = tm.networkCountryIso
        networkOperatorName = tm.networkOperatorName

        val alModelOSInfo = ArrayList<ModelOSInfo>()
        alModelOSInfo.add(ModelOSInfo(deviceUniqueId, deviceType, deviceName, osVersion, appVersion, countryIso, networkOperatorName))

        return alModelOSInfo
    }

    //FACEBOOK KEY
    fun getFacebookHashKey(activity: Activity, packageName: String) {
        val info: PackageInfo
        try {
            info = activity.packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md: MessageDigest
                md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                val facebookKeyBase64 = String(Base64.encode(md.digest(), 0))
                logInfo("Facebook Key $facebookKeyBase64")
                //String facebookkeyBase64new = new String(Base64.encodeBytes(md.digest()));
            }
        } catch (e: Exception) {

        }
    }

    fun apiGetTodayMatch(context: Context, callback: InterActorCallback<TodayMatchResponse>) {
        RestClient(context).service.apiGetTodayMatch(RestConstant.BASE_URL + RestConstant.API_GET_TODAY_MATCH)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetLiveChannel(context: Context, callback: InterActorCallback<LiveChannelsResponse>) {
        RestClient(context).service.apiGetLiveChannel(RestConstant.BASE_URL + RestConstant.API_GET_LIVE_CHANNEL_LIST)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetVideos(context: Context, callback: InterActorCallback<VideosResponse>) {
        RestClient(context).service.apiGetVideo(RestConstant.BASE_URL + RestConstant.API_GET_VIDEOS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetLatestNews(context: Context, callback: InterActorCallback<LatestNewsResponse>) {
        RestClient(context).service.apiGetLatestNews(RestConstant.BASE_URL + RestConstant.API_GET_LATEST_NEWS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }
}