package com.live.view

import com.live.baseclass.BaseView
import com.live.model.api.response.video.VideosResponse

interface VideosView : BaseView {
    fun videoApiGet(response: VideosResponse)
}

