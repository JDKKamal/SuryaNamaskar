package com.live.baseclass

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Point
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.*
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.live.interacter.disposablemanager.DisposableManager
import com.live.kooralivehd.R
import com.live.utils.logError
import java.io.File
import java.io.FileReader
import java.util.*

abstract class BaseFragment : Fragment() {

    private var progressDialog: Dialog? = null
    private var params: HashMap<String, String>? = null
    private var calendar: Calendar? = null

    var layoutManager: LinearLayoutManager? = null
    val recyclerViewLinearLayout = 0
    val recyclerViewGridLayout = 1

    val SWIPEREFRESH = 1
    val SWIPEREFRESHNO = 0

    val defaultParameter: HashMap<String, String>
        get() {
            params = HashMap()
            return params!!
        }

    val defaultParamWithIdAndToken: HashMap<String, String>?
        get() {
            params = defaultParameter
            return params
        }

     val isInternet: Boolean
        get() {
            val connectivityManager = activity!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @SuppressLint("MissingPermission") val networkInfo = connectivityManager.activeNetworkInfo
            if (!(networkInfo != null && networkInfo.isConnectedOrConnecting)) {
                return false
            }
            return true
        }

     fun uuidRandom(): UUID {
        return UUID.randomUUID()
    }

     val currentDate: Date
        get() = Date()

    //For Get the screen dimensions
    private val screenSize: IntArray
        get() {
            val size = Point()
            activity!!.windowManager.defaultDisplay.getSize(size)
            return intArrayOf(size.x, size.y)
        }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        retainInstance = true
    }

    override fun onDestroyView() {
        DisposableManager.dispose()
        super.onDestroyView()
    }

    fun activity(): Activity {
        return this.activity!!
    }

     fun isData(llDataPresent: LinearLayout, llDataNo: LinearLayout, status: Int) {
        when (status) {
            0 -> {
                llDataPresent.visibility = View.GONE
                llDataNo.visibility = View.VISIBLE
            }

            1 -> {
                llDataPresent.visibility = View.VISIBLE
                llDataNo.visibility = View.GONE
            }
        }
    }

    fun getStringFromId(id: Int): String? {
        var str: String? = null
        try {
            str = this.getString(id)
        } catch (e: Exception) {
        }
        return str
    }

     fun hideSoftKeyboard() {
        try {
            activity!!.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            val imm = activity!!.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(activity!!.window.decorView.windowToken, InputMethodManager.HIDE_IMPLICIT_ONLY)
            imm.hideSoftInputFromWindow(activity!!.window.decorView.applicationWindowToken, InputMethodManager.HIDE_IMPLICIT_ONLY)
            imm.hideSoftInputFromWindow(activity!!.window.decorView.windowToken, 0)
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

     fun showKeyboard(appCompatEditText: AppCompatEditText) {
        try {
            if (activity != null) {
                val inputManager = activity!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                inputManager.showSoftInput(appCompatEditText, InputMethodManager.SHOW_IMPLICIT)
            }
        } catch (e: Exception) {
            logError("Exception on show " + e.toString())
        }

    }

    fun requestEditTextFocus(view: AppCompatEditText) {
        view.requestFocus()
        showKeyboard(view)
    }

    /*TODO PROGRESSBAR*/
    fun showProgressDialog(show: Boolean) {
        //Show Progress bar here
        if (show) {
            showProgressBar()
        } else {
            hideProgressDialog()
        }
    }

    //SHOW PROGRESSBAR
    private fun showProgressBar() {
        if (progressDialog == null) {
            progressDialog = Dialog(activity!!)
        }
        val view = LayoutInflater.from(activity).inflate(R.layout.progressbar_dialog, null, false)

        val imageView1 = view.findViewById<AppCompatImageView>(R.id.appIvProgressBar)
        val a1 = AnimationUtils.loadAnimation(activity, R.anim.progress_anim)
        a1.duration = 1500
        imageView1.startAnimation(a1)

        progressDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        progressDialog!!.setContentView(view)
        val window = progressDialog!!.window
        window?.setBackgroundDrawable(ContextCompat.getDrawable(activity!!, android.R.color.transparent))
        progressDialog!!.setCancelable(false)
        progressDialog!!.setCanceledOnTouchOutside(false)
        progressDialog!!.show()
    }

    //HIDE PROGRESSBAR
    private fun hideProgressDialog() {
        if (progressDialog != null) {
            progressDialog!!.dismiss()
            progressDialog = null
        }
    }

    //TODO RECYCLERVIEW
     fun setRecyclerView(recyclerView: RecyclerView, spanCount: Int, no: Int): LinearLayoutManager? {
        when (no) {
            0 -> {
                layoutManager = LinearLayoutManager(activity)
                recyclerView.layoutManager = layoutManager
                recyclerView.itemAnimator = DefaultItemAnimator()
                recyclerView.setHasFixedSize(true)
            }

            1 -> {
                layoutManager = GridLayoutManager(activity, spanCount)
                recyclerView.layoutManager = layoutManager
                recyclerView.itemAnimator = DefaultItemAnimator()
                recyclerView.setHasFixedSize(true)
            }
        }

        return layoutManager
    }

    //TODO GSON
     fun getToJson(alData: List<*>): String {
        return Gson().toJson(alData)
    }

     fun getToJsonClass(src: Any): String {
        return Gson().toJson(src)
    }

     fun <T> getFromJson(str: String, classType: Class<T>): T {
        return Gson().fromJson(str, classType)
    }

    @Throws(Exception::class)
     fun <T> fromJson(file: File, clazz: Class<T>): T {
        return Gson().fromJson(FileReader(file.absoluteFile), clazz)
    }

     fun switchGson(param: Int): Gson? {
        when (param) {
            1 -> return GsonBuilder().create()

            2 //FIRST CHARACTER UPPER CAMEL
            -> return GsonBuilder().disableHtmlEscaping().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).setPrettyPrinting().serializeNulls().create()
            else -> {
            }
        }
        return null
    }

    inline fun <reified T> Gson.fromJson(json: String) = this.fromJson<T>(json, object: TypeToken<T>() {}.type)!!

     fun intentOpenBrowser(url: String) {
        if (isInternet) {
            startActivity(Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)))
        } else {
        }
    }

     fun isHasSDCard(): Boolean {
        val status = Environment.getExternalStorageState()
        return status == Environment.MEDIA_MOUNTED
    }

    //DISABLE SCREEN CAPTURE
     fun disableScreenshotFunctionality() {
        activity!!.window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }

}