package com.live.model.api.response.todaymatch

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LiveMatchList {

    @SerializedName("id")
    @Expose
    var id: String? = null
    @SerializedName("leaguename")
    @Expose
    var leaguename: String? = null
    @SerializedName("img")
    @Expose
    var img: String? = null
    @SerializedName("team_list")
    @Expose
    var teamList: MutableList<TeamList>? = null

}