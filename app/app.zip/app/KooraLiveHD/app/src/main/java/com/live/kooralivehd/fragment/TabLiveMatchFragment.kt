package com.live.kooralivehd.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.baseclass.BaseFragment
import com.live.kooralivehd.R
import android.support.v4.view.ViewPager
import com.live.kooralivehd.adapter.viewpager.TabViewPagerAdapter

class TabLiveMatchFragment : BaseFragment() {
    private var tabLayout: TabLayout? = null
    private var viewPager: ViewPager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_tab_live_match, container, false)

        hideSoftKeyboard()

        tabLayout = view.findViewById(R.id.tabLayout)
        viewPager = view.findViewById(R.id.viewPager)
        setupViewPager(viewPager)

        tabLayout!!.setupWithViewPager(viewPager)
        return view
    }

    private fun setupViewPager(viewPager: ViewPager?) {
        val adapter = TabViewPagerAdapter(childFragmentManager)
        adapter.addFragment(LiveMatchFragment(), getString(R.string.tab_today_match))
        adapter.addFragment(LiveMatchFragment(), getString(R.string.tab_tomorrow_match))
        viewPager!!.adapter = adapter
    }
}
