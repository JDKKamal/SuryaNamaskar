package com.live.model.api.response.video

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class VideoList {

    @SerializedName("id")
    @Expose
    var id: String? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("img")
    @Expose
    var img: String? = null
    @SerializedName("content")
    @Expose
    var content: String? = null

}