package com.live.kooralivehd.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.os.Bundle
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import android.widget.LinearLayout
import com.google.gson.Gson
import com.live.baseclass.BaseFragment
import com.live.kooralivehd.R
import com.live.kooralivehd.adapter.DrawerAdapter
import com.live.kooralivehd.spdialog.SpDialogTimeZone
import com.live.model.ModelDrawer
import com.live.model.api.response.TimeZoneResponse
import com.live.utils.AppUtils
import com.live.utils.PreferenceUtils
import java.util.*

class FragmentDrawer : BaseFragment() {
    private var readFile: String? = null

    private var rvDrawer: RecyclerView? = null
    private var mDrawerLayout: DrawerLayout? = null
    private var adapter: DrawerAdapter? = null
    private var containerView: View? = null
    private var drawerListener: FragmentDrawerListener? = null

    companion object {
        fun listDrawer(): MutableList<ModelDrawer> {
            val alDrawer = ArrayList<ModelDrawer>()
            alDrawer.add(ModelDrawer(R.drawable.drawer_facebook, R.string.drawer_menu_facebook))
            alDrawer.add(ModelDrawer(R.drawable.drawer_instagram, R.string.drawer_menu_instagram))
            alDrawer.add(ModelDrawer(R.drawable.drawer_youtube, R.string.drawer_menu_youtube))
            alDrawer.add(ModelDrawer(R.drawable.drawer_about_us, R.string.drawer_menu_about_us))
            alDrawer.add(ModelDrawer(R.drawable.drawer_privacy_policy, R.string.drawer_menu_policy_privacy))
            alDrawer.add(ModelDrawer(R.drawable.drawer_more_apps, R.string.drawer_menu_more_apps))

            alDrawer.add(ModelDrawer(R.drawable.drawer_contact_us, R.string.drawer_menu_contact_us))
            alDrawer.add(ModelDrawer(R.drawable.drawer_share_app, R.string.drawer_menu_share_app))
            alDrawer.add(ModelDrawer(R.drawable.drawer_rate_app, R.string.drawer_menu_rate_app))
            return alDrawer
        }
    }

    fun setDrawerListener(listener: FragmentDrawerListener) {
        this.drawerListener = listener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val layout = inflater.inflate(R.layout.drawer_header, container, false)
        rvDrawer = layout.findViewById(R.id.rvDrawer)

        adapter = DrawerAdapter(activity(), listDrawer())
        rvDrawer!!.adapter = adapter
        rvDrawer!!.layoutManager = LinearLayoutManager(activity())
        rvDrawer!!.addOnItemTouchListener(RecyclerTouchListener(activity(), rvDrawer!!, object : ClickListener {
            override fun onClick(view: View, position: Int) {
                drawerListener!!.onDrawerItemSelected(view, position)
                mDrawerLayout!!.closeDrawer(containerView!!)
            }

            override fun onLongClick(view: View?, position: Int) {

            }
        }))

        //TODO LOGOUT
        layout.findViewById<LinearLayout>(R.id.llTimeZone).setOnClickListener(
                {
                    mDrawerLayout!!.closeDrawer(containerView!!)
                    readFile = AppUtils.readFile("json/timezones", "json", activity())

                    //val list: List<TimeZoneResponse> = Gson().fromJson(readFile, object : TypeToken<List<TimeZoneResponse>>() {}.type)
                    val list = Gson().fromJson<List<TimeZoneResponse>>(this.readFile!!)
                    val dialogCountry = SpDialogTimeZone(activity(), this.getStringFromId(R.string.sp_title_select_time_zone)!!, SpDialogTimeZone.OnItemClick { id, timeZoneResponse ->
                        PreferenceUtils.preferenceInstance(activity()).timeZoneId = id
                        var timeZoneResponse = timeZoneResponse as TimeZoneResponse

                        System.out.println("Tag${timeZoneResponse.text}")
                    }, list)
                    dialogCountry.show()
                })

        return layout
    }

    override fun onPause() {
        super.onPause()
    }

    fun setUp(fragmentId: Int, drawerLayout: DrawerLayout) {
        containerView = activity().findViewById(fragmentId)
        mDrawerLayout = drawerLayout

        /*AppCompatImageView appIvDrawerMenu = toolbar.findViewById(R.id.appIvDrawerMenu);
        appIvDrawerMenu.setOnClickListener(v -> mDrawerLayout.openDrawer(containerView));*/
    }

    interface ClickListener {
        fun onClick(view: View, position: Int)

        fun onLongClick(view: View?, position: Int)
    }

    internal class RecyclerTouchListener(context: Context, recyclerView: RecyclerView, private val clickListener: ClickListener?) : RecyclerView.OnItemTouchListener {
        private val gestureDetector: GestureDetector

        init {
            gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    val child = recyclerView.findChildViewUnder(e.x, e.y)
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildAdapterPosition(child))
                    }
                }
            })
        }

        override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {

            val child = rv.findChildViewUnder(e.x, e.y)
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildAdapterPosition(child))
            }
            return false
        }

        override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {}

        override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {

        }
    }

    interface FragmentDrawerListener {
        fun onDrawerItemSelected(view: View, position: Int)
    }
}