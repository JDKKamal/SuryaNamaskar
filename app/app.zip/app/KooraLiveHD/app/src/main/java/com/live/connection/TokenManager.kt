package com.live.connection

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

interface TokenManager {
    val token: String
    fun hasToken(): Boolean
    fun clearToken()
    fun refreshToken()
}
