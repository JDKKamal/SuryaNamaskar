package com.live.model.api.response.livechannels

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.live.model.api.Response

class LiveChannelsResponse {

    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("livechannel_list")
    @Expose
    var livechannelList: MutableList<LiveChannelList>? = null
}