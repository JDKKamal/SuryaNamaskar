package com.live.kooralivehd.activity;

public class ModelSection2Child
{
    private String cid, cname, cparentid;

    public String getCid()
    {
        return cid;
    }

    public void setCid(String cid)
    {
        this.cid = cid;
    }

    public String getCname()
    {
        return cname;
    }

    public void setCname(String cname)
    {
        this.cname = cname;
    }

    public String getCparentid()
    {
        return cparentid;
    }

    public void setCparentid(String cparentid)
    {
        this.cparentid = cparentid;
    }
}
