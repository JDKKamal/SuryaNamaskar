package com.live.db

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Activity
import android.app.Application
import com.restaurant.model.db.NotificationList
import io.realm.Realm
import io.realm.RealmModel

class DBQuery(application: Application) {
    val realm: Realm? = Realm.getDefaultInstance()

    internal fun closeRealm() {
        if (realm != null && !realm.isClosed) {
            realm.close()
        }
    }

    fun realmVersion(): Long {
        return realm!!.version
    }

    fun realmInsert(realmModel: RealmModel) {
        realm!!.beginTransaction()
        realm.insert(realmModel)
        realm.commitTransaction()
    }

    fun realmInsertList(list: Collection<RealmModel>) {
        realm!!.beginTransaction()
        realm.insert(list)
        realm.commitTransaction()
    }

    fun realmList(): List<NotificationList> {
        return realm!!.where(NotificationList::class.java).findAll()
    }

    companion object {
        fun with(activity: Activity): DBQuery {
            return DBQuery(activity.application)
        }

        fun with(application: Application): DBQuery {
            return DBQuery(application)
        }
    }
}