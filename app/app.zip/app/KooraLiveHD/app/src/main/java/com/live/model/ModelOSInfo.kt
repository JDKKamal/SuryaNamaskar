package com.live.model

class ModelOSInfo(var deviceuniqueid: String?, var devicetype: String?, var devicename: String?, var osversion: String?, var appversion: String?, var countryiso: String?, var networkoperatorname: String?)
