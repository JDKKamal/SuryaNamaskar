package com.live.model.api.response.todaymatch

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.live.model.api.Response

class TodayMatchResponse {

    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("live_match_list")
    @Expose
    var liveMatchList: MutableList<LiveMatchList>? = null
}