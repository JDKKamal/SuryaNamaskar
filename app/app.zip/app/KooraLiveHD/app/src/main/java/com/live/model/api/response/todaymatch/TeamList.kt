package com.live.model.api.response.todaymatch

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TeamList {

    @SerializedName("id")
    @Expose
    var id: String? = null
    @SerializedName("team1")
    @Expose
    var team1: String? = null
    @SerializedName("image1")
    @Expose
    var image1: String? = null
    @SerializedName("team2")
    @Expose
    var team2: String? = null
    @SerializedName("image2")
    @Expose
    var image2: String? = null
    @SerializedName("week_game_title")
    @Expose
    var weekGameTitle: String? = null
    @SerializedName("channel")
    @Expose
    var channel: String? = null
    @SerializedName("timematch")
    @Expose
    var timematch: String? = null
    @SerializedName("server1")
    @Expose
    var server1: String? = null
    @SerializedName("embeds1")
    @Expose
    var embeds1: String? = null
    @SerializedName("server2")
    @Expose
    var server2: String? = null
    @SerializedName("embeds2")
    @Expose
    var embeds2: String? = null
    @SerializedName("server3")
    @Expose
    var server3: String? = null
    @SerializedName("embeds3")
    @Expose
    var embeds3: String? = null
    @SerializedName("server4")
    @Expose
    var server4: String? = null
    @SerializedName("embeds4")
    @Expose
    var embeds4: String? = null
    @SerializedName("server5")
    @Expose
    var server5: String? = null
    @SerializedName("embeds5")
    @Expose
    var embeds5: String? = null

}