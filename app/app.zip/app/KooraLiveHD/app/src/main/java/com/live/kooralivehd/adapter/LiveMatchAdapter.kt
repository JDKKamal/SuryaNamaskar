package com.live.kooralivehd.adapter

import android.content.Context
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.live.constant.RestConstant

import com.live.kooralivehd.R
import com.live.customviews.recyclerview.SectionedRecyclerViewAdapter
import com.live.kooralivehd.MainActivity
import com.live.kooralivehd.activity.MatchInfoActivity
import com.live.kooralivehd.activity.ModelSection2Child
import com.live.kooralivehd.activity.ModelSection2Parent
import com.live.model.api.response.todaymatch.LiveMatchList
import com.live.model.api.response.todaymatch.TeamList
import com.live.utils.AppUtils

class LiveMatchAdapter(private val context: Context, private val alParent: MutableList<LiveMatchList>) : SectionedRecyclerViewAdapter<RecyclerView.ViewHolder>() {

    private lateinit var itemsInSection: MutableList<TeamList>

    override fun getSectionCount(): Int {
        return alParent.size
    }

    override fun getItemCount(section: Int): Int {
        return alParent[section].teamList!!.size
    }

    override fun onBindHeaderViewHolder(holder: RecyclerView.ViewHolder, section: Int) {

        val sectionViewHolder = holder as SectionViewHolder
        sectionViewHolder.appTvParentTitle.text = alParent[section].leaguename

        AppUtils.glideSetAppImageView(context, alParent[section].img!!, sectionViewHolder.appIvParentImage)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, section: Int, childPosition: Int, absolutePosition: Int) {
        itemsInSection = alParent[section].teamList!!

        val itemViewHolder = holder as ItemViewHolder
        itemViewHolder.appTvTeamAChild.text = itemsInSection[childPosition].team1
        itemViewHolder.appTvTeamBChild.text = itemsInSection[childPosition].team2

        AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + itemsInSection[childPosition].image1!!, itemViewHolder.appIvTeamAChild)
        AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + itemsInSection[childPosition].image2!!, itemViewHolder.appIvTeamBChild)

        itemViewHolder.appIvWatchNowLive.setOnClickListener { v ->
            val itemsInSection = alParent[section].id

            AppUtils.startActivity(v.context, MatchInfoActivity::class.java)
            //Toast.makeText(v.context, itemsInSection[relativePosition].cid.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, header: Boolean): RecyclerView.ViewHolder {
        var v: View? = null
        return when {
            header -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.itemview_live_match_parent, parent, false)
                SectionViewHolder(v)
            }
            else -> {
                v = LayoutInflater.from(parent.context).inflate(R.layout.itemview_live_match_child, parent, false)
                ItemViewHolder(v)
            }
        }
    }

    inner class SectionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        internal val appTvParentTitle: AppCompatTextView
        internal val appIvParentImage: AppCompatImageView

        init {
            appTvParentTitle = itemView.findViewById(R.id.appTvParentTitle)
            appIvParentImage = itemView.findViewById(R.id.appIvParentImage)
        }
    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val appTvTeamAChild: AppCompatTextView
        val appTvTeamBChild: AppCompatTextView
        val appIvTeamAChild: AppCompatImageView
        val appIvTeamBChild: AppCompatImageView
        val appIvWatchNowLive: AppCompatImageView

        init {
            appTvTeamAChild = itemView.findViewById(R.id.appTvTeamAChild)
            appTvTeamBChild = itemView.findViewById(R.id.appTvTeamBChild)
            appIvTeamAChild = itemView.findViewById(R.id.appIvTeamAChild)
            appIvTeamBChild = itemView.findViewById(R.id.appIvTeamBChild)
            appIvWatchNowLive = itemView.findViewById(R.id.appIvWatchNowLive)
        }
    }
}