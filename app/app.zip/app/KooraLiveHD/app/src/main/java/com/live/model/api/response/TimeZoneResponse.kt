package com.live.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TimeZoneResponse {
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("value")
    @Expose
    var value: String? = null
    @SerializedName("abbr")
    @Expose
    var abbr: String? = null
    @SerializedName("offset")
    @Expose
    var offset: Float? = null
    @SerializedName("isdst")
    @Expose
    var isdst: Boolean? = null
    @SerializedName("text")
    @Expose
    var text: String? = null
    @SerializedName("utc")
    @Expose
    var utc: List<String>? = null
    private val isSelected: Boolean = false
}