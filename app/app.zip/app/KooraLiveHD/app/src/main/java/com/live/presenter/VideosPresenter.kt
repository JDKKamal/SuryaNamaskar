package com.live.presenter

import com.live.baseclass.BasePresenter
import com.live.constant.RestConstant
import com.live.interacter.InterActorCallback
import com.live.model.api.response.livechannels.LiveChannelsResponse
import com.live.model.api.response.video.VideosResponse
import com.live.view.LiveChannelView
import com.live.view.VideosView

class VideosPresenter : BasePresenter<VideosView>() {
    private fun callVideosApiGet(swipeRefreshStatus: Int) {
        appInteractor.apiGetVideos(view!!.activity(), object : InterActorCallback<VideosResponse> {
            override fun onStart() {
                when (swipeRefreshStatus) {
                    0 -> view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: VideosResponse) {
                view!!.videoApiGet(response)
            }

            override fun onFinish() {
                when (swipeRefreshStatus) {
                    0 -> view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(swipeRefreshStatus: Int, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.NO_API_GET_VIDEOS -> callVideosApiGet(swipeRefreshStatus)
            }
        }
    }
}

