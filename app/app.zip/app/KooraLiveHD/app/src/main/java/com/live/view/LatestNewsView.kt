package com.live.view

import com.live.baseclass.BaseView
import com.live.model.api.response.latestnews.LatestNewsResponse

interface LatestNewsView : BaseView {
    fun latestNewsApiGet(response: LatestNewsResponse)
}

