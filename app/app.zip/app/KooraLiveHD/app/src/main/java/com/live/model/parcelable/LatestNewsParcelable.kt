package com.live.model.parcelable

import android.os.Parcel
import android.os.Parcelable

data class LatestNewsParcelable(val title: String, val image: String, val content: String) : Parcelable {

    constructor(source: Parcel) :
            this(
                    source.readString(),
                    source.readString(),
                    source.readString())

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(this.title)
        dest?.writeString(this.image)
        dest?.writeString(this.content)
    }

    companion object {
        @JvmField
        final val CREATOR: Parcelable.Creator<LatestNewsParcelable> = object : Parcelable.Creator<LatestNewsParcelable> {
            override fun createFromParcel(source: Parcel): LatestNewsParcelable {
                return LatestNewsParcelable(source)
            }

            override fun newArray(size: Int): Array<LatestNewsParcelable?> {
                return arrayOfNulls(size)
            }
        }
    }
}