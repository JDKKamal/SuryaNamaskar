package com.live.kooralivehd.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.baseclass.MVPFragment
import com.live.constant.RestConstant
import com.live.kooralivehd.R
import com.live.kooralivehd.adapter.LiveMatchAdapter
import com.live.model.api.response.todaymatch.TodayMatchResponse
import com.live.presenter.TodayMatchPresenter
import com.live.utils.AppUtils
import com.live.view.TodayMatchView
import kotlinx.android.synthetic.main.fragment_live_match.*

class LiveMatchFragment : MVPFragment<TodayMatchPresenter, TodayMatchView>(), TodayMatchView {
    private var recyclerView: RecyclerView? = null

    private var adapterSection: LiveMatchAdapter? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_live_match, container, false)
        activity!!.window.setBackgroundDrawableResource(R.drawable.background)

        hideSoftKeyboard()

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView!!.layoutManager = LinearLayoutManager(activity)

        presenter!!.apiCall(SWIPEREFRESHNO, RestConstant.NO_API_GET_LIVE_MATCH_TODAY)

        if (hasInternet()) {
            view.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    presenter!!.apiCall(SWIPEREFRESH, RestConstant.NO_API_GET_LIVE_MATCH_TODAY)
                }, 1000)
            }
        } else {
            swipeRefreshLayout.isRefreshing = false
        }

        return view
    }

    override fun createPresenter(): TodayMatchPresenter {
        return TodayMatchPresenter()
    }

    override fun attachView(): TodayMatchView {
        return this
    }

    override fun todayMatchApiGet(response: TodayMatchResponse) {
        swipeRefreshLayout.isRefreshing = false
        when {
            response.response!!.code == RestConstant.OK_200 -> {
                adapterSection = LiveMatchAdapter(activity(), response.liveMatchList!!)
                recyclerView!!.adapter = adapterSection
            }
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(activity(), message)
    }
}
