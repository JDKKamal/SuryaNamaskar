package com.live.kooralivehd.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.AppCompatEditText
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.baseclass.MVPFragment
import com.live.constant.RestConstant
import com.live.customviews.AppEditTextChangedListener
import com.live.kooralivehd.R
import com.live.kooralivehd.activity.LiveStreamActivity
import com.live.kooralivehd.adapter.LiveChannelsAdapter
import com.live.model.api.response.livechannels.LiveChannelList
import com.live.model.api.response.livechannels.LiveChannelsResponse
import com.live.presenter.LiveChannelPresenter
import com.live.utils.AppUtils
import com.live.view.LiveChannelView
import kotlinx.android.synthetic.main.fragment_live_channels.*

class LiveChannelsFragment : MVPFragment<LiveChannelPresenter, LiveChannelView>(), LiveChannelView, LiveChannelsAdapter.ItemListener, AppEditTextChangedListener.OnEditTextChangedListener {
    private var recyclerView: RecyclerView? = null
    private var appEdtSearch: AppCompatEditText? = null

    private lateinit var liveChannelsAdapter: LiveChannelsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_live_channels, container, false)
        activity!!.window.setBackgroundDrawableResource(R.drawable.background)

        hideSoftKeyboard()

        recyclerView = view.findViewById(R.id.recyclerView)
        appEdtSearch = view.findViewById(R.id.appEdtSearch)
        setRecyclerView(recyclerView!!, 3, recyclerViewGridLayout)

        presenter!!.apiCall(SWIPEREFRESHNO, RestConstant.NO_API_GET_LIVE_CHANNEL_LIST)
        appEdtSearch!!.addTextChangedListener(AppEditTextChangedListener(this, appEdtSearch!!))

        if (hasInternet()) {
            view.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
                override fun onRefresh() {
                    swipeRefreshLayout.isRefreshing = true
                    Handler().postDelayed({
                        presenter!!.apiCall(SWIPEREFRESH, RestConstant.NO_API_GET_LIVE_CHANNEL_LIST)
                    }, 1000)
                }
            })
        } else {
            swipeRefreshLayout.isRefreshing = false
        }

        return view
    }

    override fun createPresenter(): LiveChannelPresenter {
        return LiveChannelPresenter()
    }

    override fun attachView(): LiveChannelView {
        return this
    }

    override fun liveChannelApiGet(response: LiveChannelsResponse) {
        swipeRefreshLayout.isRefreshing = false
        when {
            response.response!!.code == RestConstant.OK_200 -> {
                liveChannelsAdapter = LiveChannelsAdapter(activity!!, response.livechannelList!!)
                liveChannelsAdapter.setOnListener(this)
                recyclerView!!.adapter = liveChannelsAdapter
            }
            else -> AppUtils.showToast(activity!!, response.response!!.message)
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(activity!!, message)
    }

    override fun onClickMenu(videos: LiveChannelList) {
        AppUtils.startActivity(activity(), LiveStreamActivity::class.java)
    }

    override fun onAfterTextChanged(str: String) {
        when {
            liveChannelsAdapter != null -> liveChannelsAdapter.filter(str)
        }
    }
}
