package com.live.kooralivehd

import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.view.View
import android.widget.LinearLayout
import com.live.baseclass.BaseActivity
import com.live.kooralivehd.activity.DrawerActivity
import com.live.utils.AppUtils

class MainActivity : BaseActivity(), View.OnClickListener {

    private val appBtnEnter by bind<AppCompatButton>(R.id.appBtnEnter)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        appBtnEnter.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appBtnEnter -> {
                AppUtils.startActivity(this, DrawerActivity::class.java)
                finish()
            }
        }
    }
}
