package com.live.kooralivehd.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.baseclass.MVPFragment
import com.live.constant.AppConstant
import com.live.constant.RestConstant
import com.live.kooralivehd.R
import com.live.kooralivehd.activity.LatestNewsNextPreviousActivity
import com.live.kooralivehd.adapter.LatestNewsAdapter
import com.live.model.api.response.latestnews.LatestNewsList
import com.live.model.api.response.latestnews.LatestNewsResponse
import com.live.model.parcelable.LatestNewsParcelable
import com.live.presenter.LatestNewsPresenter
import com.live.utils.AppUtils
import com.live.view.LatestNewsView
import java.util.ArrayList
import kotlinx.android.synthetic.main.fragment_latest_news.*

class LatestNewsFragment : MVPFragment<LatestNewsPresenter, LatestNewsView>(), LatestNewsView, LatestNewsAdapter.ItemListener {
    private var recyclerView: RecyclerView? = null
    private lateinit var latestNewsAdapter: LatestNewsAdapter

    companion object {
        var firstNavigation: Int? = null
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_latest_news, container, false)
        activity().window.setBackgroundDrawableResource(R.drawable.background)

        hideSoftKeyboard()

        recyclerView = view.findViewById(R.id.recyclerView)
        setRecyclerView(recyclerView!!, 0, 0)

        presenter!!.apiCall(SWIPEREFRESHNO, RestConstant.NO_API_GET_LATEST_NEWS)

        if (hasInternet()) {
            view.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
                override fun onRefresh() {
                    swipeRefreshLayout.isRefreshing = true
                    Handler().postDelayed({
                        presenter!!.apiCall(SWIPEREFRESH, RestConstant.NO_API_GET_LATEST_NEWS)
                    }, 1000)
                }
            })
        } else {
            swipeRefreshLayout.isRefreshing = false
        }

        return view
    }

    override fun createPresenter(): LatestNewsPresenter {
        return LatestNewsPresenter()
    }

    override fun attachView(): LatestNewsView {
        return this
    }

    override fun latestNewsApiGet(response: LatestNewsResponse) {
        swipeRefreshLayout.isRefreshing = false
        when {
            response.response!!.code == RestConstant.OK_200 -> {
                latestNewsAdapter = LatestNewsAdapter(activity(), response.latestNewsList!!)
                latestNewsAdapter.setOnListener(this)
                recyclerView!!.adapter = latestNewsAdapter
            }
            else -> AppUtils.showToast(activity!!, response.response!!.message)
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(activity(), message)
    }

    override fun onClickLatestNews(position: Int, latestNews: MutableList<LatestNewsList>) {
        firstNavigation = position
        val alPassDataQuestion = ArrayList<LatestNewsParcelable>()
        latestNews.forEach({ latestnews ->
            alPassDataQuestion.add(LatestNewsParcelable(latestnews.newsTilte!!, latestnews.image!!, latestnews.content!!))
        })

        AppUtils.sentParcelsLaunchClear(this!!.activity(), LatestNewsNextPreviousActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
    }
}
