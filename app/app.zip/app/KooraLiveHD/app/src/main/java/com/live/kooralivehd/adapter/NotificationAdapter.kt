package com.live.kooralivehd.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.live.customviews.recyclerview.BaseRecyclerView
import com.live.customviews.recyclerview.BaseViewHolder
import com.live.kooralivehd.R
import com.restaurant.model.db.NotificationList

class NotificationAdapter(private val context: Context, private val menuList: MutableList<NotificationList>) : BaseRecyclerView<NotificationList>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): NotificationList {
        return menuList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<NotificationList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_notification, parent, false))
    }

    override fun getItemCount(): Int {
        return menuList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<NotificationList>(itemView) {
        var appTvNo: AppCompatTextView? = null
        var appTvTitle: AppCompatTextView? = null
        var appTvDescription: AppCompatTextView? = null
        var appTvDate: AppCompatTextView? = null

        init {
            appTvTitle= itemView.findViewById(R.id.appTvTitle)
            appTvDescription = itemView.findViewById(R.id.appTvDescription)
            appTvDate = itemView.findViewById(R.id.appTvDate)
            appTvNo = itemView.findViewById(R.id.appTvNo)
        }

        override fun populateItem(t: NotificationList) {
            appTvNo!!.text  = (layoutPosition + 1).toString()
            appTvTitle!!.text = t.title
            appTvDescription!!.text = t.description
            appTvDate!!.text = t.date
        }
    }

    interface ItemListener {
        fun onClickMenu(notification: NotificationList)
    }
}
