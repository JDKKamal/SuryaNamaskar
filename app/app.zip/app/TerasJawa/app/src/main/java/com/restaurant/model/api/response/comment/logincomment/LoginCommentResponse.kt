package com.restaurant.model.api.response.comment.logincomment

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LoginCommentResponse{
    @SerializedName("response")
    @Expose
    var response: Response? = null
}

