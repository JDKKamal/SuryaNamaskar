package com.restaurant.model.api.request

class DistrictRequest(var countryid: String) {
}
