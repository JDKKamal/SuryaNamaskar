package com.restaurant.model.api.response.forgotpassword

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.restaurant.model.api.Response

class ForgotPasswordResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
}