package com.restaurant.model.parcelable

import android.os.Parcel
import android.os.Parcelable

data class CategoryParcelable(
        val idMenu: String,
        val nameMenu: String,
        val idCategory: String,
        val nameCategory: String,
        val descriptionCategory: String,
        val imageCategory: String,
        val totalRateCategory: String,
        val totalRateAvgCategory: String,
        val priceCategory: String

) : Parcelable {
    constructor(source: Parcel) :
            this(
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString())

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(this.idMenu)
        dest?.writeString(this.nameMenu)
        dest?.writeString(this.idCategory)
        dest?.writeString(this.nameCategory)
        dest?.writeString(this.descriptionCategory)
        dest?.writeString(this.imageCategory)
        dest?.writeString(this.totalRateCategory)
        dest?.writeString(this.totalRateAvgCategory)
        dest?.writeString(this.priceCategory)
    }

    companion object {
        @JvmField
        final val CREATOR: Parcelable.Creator<CategoryParcelable> = object : Parcelable.Creator<CategoryParcelable> {
            override fun createFromParcel(source: Parcel): CategoryParcelable {
                return CategoryParcelable(source)
            }

            override fun newArray(size: Int): Array<CategoryParcelable?> {
                return arrayOfNulls(size)
            }
        }
    }
}