package com.bytotech.model.event

class PromoEvent(val promoCount: String)
