package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.constant.RestConstant
import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.terasjawa.R
import com.restaurant.model.api.response.addtocart.cartlist.CartList
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView

class RincianPesananAndaAdapter(private val context: Context, private val cartList: ArrayList<CartList>) : BaseRecyclerView<CartList>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): CartList {
        return cartList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<CartList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_rincian_pesanan_anda, parent, false))
    }

    override fun getItemCount(): Int {
        return cartList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<CartList>(itemView), View.OnClickListener {
        var appIvMenuIcon: CircleImageView? = null
        var appTvTitle: AppCompatTextView? = null
        var appTvPrice: AppCompatTextView? = null
        var appBtnQty: AppCompatButton? = null
        var appTvDelete: AppCompatTextView? = null

        var appBtnMinus: AppCompatButton? = null
        var appBtnAdd: AppCompatButton? = null

        init {
            appIvMenuIcon = itemView.findViewById(R.id.appIvMenuIcon)
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appTvPrice = itemView.findViewById(R.id.appTvPrice)
            appBtnQty = itemView.findViewById(R.id.appBtnQty)
            appTvDelete = itemView.findViewById(R.id.appTvDelete)
            appBtnAdd = itemView.findViewById(R.id.appBtnAdd)
            appBtnMinus = itemView.findViewById(R.id.appBtnMinus)

            appTvDelete!!.setOnClickListener(this)
            appBtnAdd!!.setOnClickListener(this)
            appBtnMinus!!.setOnClickListener(this)
        }

        override fun populateItem(cartItem: CartList) {
            AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + cartItem.menuImage, appIvMenuIcon!!)
            appTvTitle!!.text = cartItem.menuName.toString()
            appTvPrice!!.text = (java.lang.Float.valueOf(cartItem.menuPrice) * java.lang.Float.valueOf(cartItem.menuQty)).toString()
            appBtnQty!!.text = cartItem.menuQty

            val qtyCal = cartList[layoutPosition].menuQty!!.toDouble()
            val priceCal = cartList[layoutPosition].menuPrice!!.toDouble()
            appTvPrice!!.text = (qtyCal * priceCal).toString()

            updateTotal(layoutPosition, 0)
        }

        override fun onClick(v: View?) {
            when (v!!.id) {
                R.id.appTvDelete -> {
                    listener!!.onClickDeleteCartItem(layoutPosition, cartList[layoutPosition].cartId!!.toInt(), cartList[layoutPosition].menuId.toString(), cartList[layoutPosition].menuName!!)
                }
                R.id.appBtnAdd -> {
                    val strQty = appBtnQty!!.text.toString()
                    var qty = 0
                    try {
                        qty = Integer.parseInt(strQty)
                    } catch (e: Exception) {
                    }

                    qty++

                    appBtnQty!!.text = qty.toString() + ""
                    cartList[layoutPosition].menuQty = qty.toString()
                    val qtyCal = cartList[layoutPosition].menuQty!!.toDouble()
                    val priceCal = cartList[layoutPosition].menuPrice!!.toDouble()
                    appTvPrice!!.text = (qtyCal * priceCal).toString()

                    updateTotal(layoutPosition, 1)
                }

                R.id.appBtnMinus -> {
                    val strQty = appBtnQty!!.text.toString()
                    var qty = 1
                    try {
                        qty = Integer.parseInt(strQty)
                        if (qty > 1)
                            qty--
                    } catch (e: Exception) {
                    }

                    cartList[layoutPosition].menuQty = qty.toString()
                    appBtnQty!!.text = qty.toString() + ""

                    val qtyCal = cartList[layoutPosition].menuQty!!.toDouble()
                    val priceCal = cartList[layoutPosition].menuPrice!!.toDouble()
                    appTvPrice!!.text = (qtyCal * priceCal).toString()

                    updateTotal(layoutPosition, 1)
                }
            }
        }
    }

    fun updateTotal(position: Int, status: Int) {
        var grandTotal = 0.00

        cartList.forEach { product ->
            val qty = product.menuQty!!.toDouble()
            val price = product.menuPrice!!.toDouble()
            grandTotal += qty * price
        }
        listener!!.onCartChange(grandTotal, cartList[position], status)
    }

    fun grandTotal(cartItem : String) {
        var grandTotal = 0.00

        cartList.forEach { product ->
            val qty = product.menuQty!!.toDouble()
            val price = product.menuPrice!!.toDouble()
            grandTotal += qty * price
        }
        listener!!.onCartChange(grandTotal, cartItem)
    }

    fun remove(position: Int) {
        cartList.removeAt(position)
        notifyItemRemoved(position)

        grandTotal(cartList.size.toString());
    }


    interface ItemListener {
        fun onClickDeleteCartItem(position: Int, cartId: Int, menuId: String, cartName: String)
        fun onCartChange(grandTotal: Double, cartItems: CartList, status: Int)
        fun onCartChange(grandTotal: Double, cartItem : String)
    }
}

