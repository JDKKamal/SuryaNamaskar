package com.restaurant.view

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView

interface SplashScreenView : BaseView {
    fun setSplashScreenWait()
}

