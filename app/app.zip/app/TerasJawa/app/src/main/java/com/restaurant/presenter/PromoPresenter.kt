package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.view.PromoView
import com.restaurant.model.api.response.promo.PromoResponse
import com.restaurant.utils.PreferenceUtils

class PromoPresenter : BasePresenter<PromoView>() {
    private fun callApiGetPromo(swipeRefreshStatus: Int) {
        val params : HashMap<String, String> = hashMapOf(RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(view!!.activity()).userId)
        appInteractor.apiGetPromo(view!!.activity(), params, object : InterActorCallback<PromoResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: PromoResponse) {
                view!!.apiPostPromoResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(swipeRefreshStatus: Int, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                 RestConstant.CALL_API_PROMO -> callApiGetPromo(swipeRefreshStatus)
            }
        }
    }
}
