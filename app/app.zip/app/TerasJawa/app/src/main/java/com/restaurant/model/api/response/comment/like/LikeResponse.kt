package com.restaurant.model.api.response.comment.like

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LikeResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("like_list")
    @Expose
    var likeList: LikeList? = null

}