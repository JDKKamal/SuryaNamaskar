package com.restaurant.model.api.response.shipping.country

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CountryList {
    @SerializedName("country_id")
    @Expose
    var countryId: String? = null
    @SerializedName("country_name")
    @Expose
    var countryName: String? = null

}