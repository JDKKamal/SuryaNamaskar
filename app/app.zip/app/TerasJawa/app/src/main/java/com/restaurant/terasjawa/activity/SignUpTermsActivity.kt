package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.LinearLayout
import com.restaurant.baseclass.BaseActivity
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R

class SignUpTermsActivity : BaseActivity(), View.OnClickListener {

    private val llBack by bind<LinearLayout>(R.id.llBack)
    private val wvSignUpTerms by bind<WebView>(R.id.wvSignUpTerms)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup_terms)

        hideSoftKeyboard()

        wvSignUpTerms.settings.javaScriptEnabled = true
        wvSignUpTerms.loadUrl(RestConstant.PRIVACY_POLICY_SIGN_UP)

        llBack.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.llBack -> finish()
        }
    }

    override fun onBackPressed() {
        finish()
    }
}
