package com.restaurant.model.api.request

class OrderDeliveryRequest
(internal  var userid: String,
 internal  var title: String,
 internal  var fullname: String,
 internal  var mobile: String,
 internal  var address: String,
 internal  var countryid: String,
 internal  var stateid: String)
