package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.view.View
import android.widget.LinearLayout
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.RestConstant
import com.restaurant.model.api.response.forgotpassword.ForgotPasswordResponse
import com.restaurant.presenter.ForgotPasswordPresenter
import com.restaurant.terasjawa.Finish
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.execute
import com.restaurant.utils.AppUtils.showToast
import com.restaurant.view.ForgotPasswordView
import kotlinx.android.synthetic.main.activity_forgot_password.*

class ForgotPasswordActivity : SimpleMVPActivity<ForgotPasswordPresenter, ForgotPasswordView>(), ForgotPasswordView, View.OnClickListener {

    private val llBack by bind<LinearLayout>(R.id.llBack)
    private val appBtnForgotPassword by bind<AppCompatButton>(R.id.appBtnForgotPassword)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        hideSoftKeyboard()

        llBack.setOnClickListener(this)
        appBtnForgotPassword.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.llBack -> {
                var intentOperation = Finish(activity)
                execute(intentOperation)
            }

            R.id.appBtnForgotPassword -> {
                val email = appEdtEmail.text.toString()
                presenter!!.validation(email)
            }
        }
    }

    override fun createPresenter(): ForgotPasswordPresenter {
        return ForgotPasswordPresenter()
    }

    override fun attachView(): ForgotPasswordView {
        return this
    }

    override fun apiPostForgotPasswordResponse(response: ForgotPasswordResponse) {
        showToast(this, response.response!!.message.toString())

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                var intentOperation = Finish(activity)
                execute(intentOperation)
            }
            else -> appEdiTextNullSet(R.id.appEdtEmail)
        }
    }

    override fun onFailure(message: String) {
        showToast(this, message + "")
    }

    override fun onBackPressed() {
        var intentOperation = Finish(activity)
        execute(intentOperation)
    }
}
