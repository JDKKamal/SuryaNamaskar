package com.restaurant.terasjawa.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.os.Bundle
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.*
import android.widget.LinearLayout
import com.restaurant.baseclass.BaseFragment
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.activity.ProfileActivity
import com.restaurant.terasjawa.adapter.DrawerAdapter
import com.restaurant.model.ModelDrawer
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import de.hdodenhof.circleimageview.CircleImageView
import org.greenrobot.eventbus.EventBus
import java.util.*

class FragmentDrawer : BaseFragment() {
    private var recyclerView: RecyclerView? = null
    private var mDrawerLayout: DrawerLayout? = null
    private var adapter: DrawerAdapter? = null
    private var containerView: View? = null
    private var drawerListener: FragmentDrawerListener? = null

    companion object {
        var appIvProfile: CircleImageView? = null

        fun listDrawer(): MutableList<ModelDrawer> {
            val alDrawer = ArrayList<ModelDrawer>()
            alDrawer.add(ModelDrawer(R.drawable.drawer_menu, "Menu"))
            alDrawer.add(ModelDrawer(R.drawable.drawer_pesanan, "Pesanan"))
            alDrawer.add(ModelDrawer(R.drawable.drawer_promo, "Promo"))
            //alDrawer.add(ModelDrawer(R.drawable.drawer_keranjang, "Keranjang"))

            return alDrawer
        }
    }

    fun setDrawerListener(listener: FragmentDrawerListener) {
        this.drawerListener = listener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val layout = inflater.inflate(R.layout.drawer_header, container, false)
        recyclerView = layout.findViewById(R.id.drawerList)
        appIvProfile = layout.findViewById(R.id.appIvProfile)

        if (PreferenceUtils.preferenceInstance(activity!!).profilepicture.isNotEmpty()) {
            AppUtils.glideSetAppImageView(activity!!, PreferenceUtils.preferenceInstance(this.activity!!).profilepicture, appIvProfile!!)
        }

        adapter = DrawerAdapter(activity!!, listDrawer())
        recyclerView!!.adapter = adapter
        recyclerView!!.layoutManager = LinearLayoutManager(activity)
        recyclerView!!.addOnItemTouchListener(RecyclerTouchListener(activity!!, recyclerView!!, object : ClickListener {
            override fun onClick(view: View, position: Int) {
                drawerListener!!.onDrawerItemSelected(view, position)
                mDrawerLayout!!.closeDrawer(containerView!!)
            }

            override fun onLongClick(view: View?, position: Int) {

            }
        }))

        //TODO LOGOUT
        layout.findViewById<LinearLayout>(R.id.llProfile).setOnClickListener(
                {
                    mDrawerLayout!!.closeDrawer(containerView!!)
                    AppUtils.startActivity(activity!!, ProfileActivity::class.java)
                })

        return layout
    }

    override fun onPause() {
        EventBus.getDefault().unregister(this)
        super.onPause()
    }

    fun setUp(fragmentId: Int, drawerLayout: DrawerLayout) {
        containerView = activity!!.findViewById(fragmentId)
        mDrawerLayout = drawerLayout

        /*AppCompatImageView appIvDrawerMenu = toolbar.findViewById(R.id.appIvDrawerMenu);
        appIvDrawerMenu.setOnClickListener(v -> mDrawerLayout.openDrawer(containerView));*/
    }

    interface ClickListener {
        fun onClick(view: View, position: Int)

        fun onLongClick(view: View?, position: Int)
    }

    internal class RecyclerTouchListener(context: Context, recyclerView: RecyclerView, private val clickListener: ClickListener?) : RecyclerView.OnItemTouchListener {
        private val gestureDetector: GestureDetector

        init {
            gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    val child = recyclerView.findChildViewUnder(e.x, e.y)
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildAdapterPosition(child))
                    }
                }
            })
        }

        override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {

            val child = rv.findChildViewUnder(e.x, e.y)
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildAdapterPosition(child))
            }
            return false
        }

        override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {}

        override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {

        }
    }

    interface FragmentDrawerListener {
        fun onDrawerItemSelected(view: View, position: Int)
    }
}