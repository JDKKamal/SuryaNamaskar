package com.restaurant.model.api.response.login

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LoginResponse{
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("login_detail")
    @Expose
    var loginDetail: LoginDetail? = null

}