package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.AsyncTask
import android.os.Bundle
import android.support.v7.widget.*
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.AppConstant
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.OrderDeliveryAdapter
import com.restaurant.interacter.AppInteractor
import com.restaurant.model.api.response.addtocart.cartlist.CartList
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.model.parcelable.DeliveryParcelable
import com.restaurant.presenter.OrderSummaryPresenter
import com.restaurant.view.OrderSummaryView
import com.doku.sdkocov2.DirectSDK
import com.doku.sdkocov2.interfaces.iPaymentCallback
import com.doku.sdkocov2.model.LayoutItems
import com.doku.sdkocov2.model.PaymentItems
import kotlinx.android.synthetic.main.activity_order_delivery.*
import org.apache.http.NameValuePair
import org.apache.http.message.BasicNameValuePair
import org.json.JSONException
import org.json.JSONObject
import java.util.ArrayList
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.appindexing.AppIndex
import com.google.android.gms.appindexing.Action
import android.net.Uri
import com.restaurant.utils.*

class OrderDeliveryActivity : SimpleMVPActivity<OrderSummaryPresenter, OrderSummaryView>(), OrderSummaryView, OrderDeliveryAdapter.ItemListener {
    private var recyclerView: RecyclerView? = null

    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null

    private val appTvTitleOrder by bind<AppCompatTextView>(R.id.appTvTitleOrder)
    private val appTvAddress by bind<AppCompatTextView>(R.id.appTvAddress)
    private val appTvEmail by bind<AppCompatTextView>(R.id.appTvEmail)
    private val appTvMobile by bind<AppCompatTextView>(R.id.appTvMobile)
    private val appTvDeliveryService by bind<AppCompatTextView>(R.id.appTvDeliveryService)
    private val appTvGradTotal by bind<AppCompatTextView>(R.id.appTvGradTotal)

    private val llTime by bind<LinearLayout>(R.id.llTime)
    private val appTvStatus by bind<AppCompatTextView>(R.id.appTvStatus)
    private val appTvTime by bind<AppCompatTextView>(R.id.appTvTime)

    private val appTvTotal by bind<AppCompatTextView>(R.id.appTvTotal)
    private val appTvTax by bind<AppCompatTextView>(R.id.appTvTax)
    private val appIvOrder by bind<AppCompatImageView>(R.id.appIvOrder)

    private var parcelableDelivery: List<DeliveryParcelable>? = null
    private lateinit var orderDeliveryAdapter: OrderDeliveryAdapter

    internal var directSDK: DirectSDK? = null
    internal var invoiceNumber: String? = null
    internal var respongetTokenSDK: JSONObject? = null
    internal var jsonRespon: String? = null
    private var client: GoogleApiClient? = null
    private var appInteractor: AppInteractor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_delivery)

        hideSoftKeyboard()
        appInteractor = AppInteractor()
        appInteractor!!.getDeviceInfo(activity)

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)

        recyclerView = findViewById(R.id.recyclerView)
        setRecyclerView(recyclerView!!, 0, recyclerViewLinearLayout);

        appTvTitle!!.text = "Ringkasan Pesanan".toUpperCase()

        val param = HashMap<String, String>()
        param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
        presenter!!.apiCall(1, param, RestConstant.CALL_API_ADD_TO_CART_LIST)

        findViewById<AppCompatButton>(R.id.appBtnPembayaran).setOnClickListener(
                {
                    connectSDK(1)
                })

        /*findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
            override fun onRefresh() {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    presenter!!.apiCall(activity, 0, param, RestConstant.CALL_API_ADD_TO_CART_LIST)
                }, 1000)
            }
        });*/

        parcelableDelivery = AppUtils.getParcelable(activity, AppConstant.BUNDLE_PARCELABLE)
        when {
            parcelableDelivery != null -> when {
                parcelableDelivery!![0].status == 0 -> {
                    llTime.visibility = View.VISIBLE
                    appIvOrder.setImageResource(R.drawable.order_bag)

                    appTvStatus.text = "Waktu Pengambilan"
                    appTvTitleOrder.text = parcelableDelivery!![0].title
                    appTvEmail.text = PreferenceUtils.preferenceInstance(this).email
                    appTvMobile.text = parcelableDelivery!![0].mobile
                    appTvTime.text = parcelableDelivery!![0].address

                    appTvAddress.text = "Untuk menjamin citarasa dan kualitas masakan, Mohon diambil pada jam yang sudah di tentukan."

                }
                else -> {
                    llTime.visibility = View.GONE
                    appTvTitleOrder.text = parcelableDelivery!![0].title
                    appTvAddress.text = parcelableDelivery!![0].address + "\n" + parcelableDelivery!![0].countryName.toLowerCase() + ", " + parcelableDelivery!![0].districtName.toLowerCase()
                    appTvEmail.text = PreferenceUtils.preferenceInstance(this).email
                    appTvMobile.text = parcelableDelivery!![0].mobile
                    appTvDeliveryService.text = java.lang.Double.valueOf(parcelableDelivery!![0].deliveryService).toString()
                }
            }
        }

        client = GoogleApiClient.Builder(this).addApi(AppIndex.API).build()
        appIvDrawer!!.setOnClickListener { activity.finish() }
    }

    public override fun onStart() {
        super.onStart()

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client!!.connect()
        val viewAction = Action.newAction(
                Action.TYPE_VIEW,
                "Main Page",
                Uri.parse("http://host/path"),
                Uri.parse("android-app://com.bytotech.eresto/http/host/path")
        )
        AppIndex.AppIndexApi.start(client, viewAction)
    }

    override fun createPresenter(): OrderSummaryPresenter {
        return OrderSummaryPresenter()
    }

    override fun attachView(): OrderSummaryView {
        return this
    }

    override fun apiGetAddToCartListResponse(response: CartListResponse) {
        orderDeliveryAdapter = OrderDeliveryAdapter(activity!!, response.cartList!!)
        orderDeliveryAdapter!!.setOnListener(this)
        recyclerView!!.adapter = orderDeliveryAdapter
    }

    override fun onCartChange(grandTotal: Double, cartItems: CartList) {
        appTvTotal.text = grandTotal.toString()

        var tax: Double = java.lang.Double.valueOf(grandTotal) * 10 / 100

        appTvTax.text = tax.toString()
        val grandTotal = java.lang.Double.valueOf(grandTotal) + java.lang.Double.valueOf(tax) + java.lang.Double.valueOf(appTvDeliveryService.text.toString())
        appTvGradTotal.text = grandTotal.toString()
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }

    override fun onBackPressed() {
        finish()
    } //AppUtils.startActivity(this, PesananSelesaiActivity.class);

    private fun connectSDK(menuPaymentChannel: Int) {
        //set payment parameter
        invoiceNumber = AppUtilsPayment.nDigitRandomNo(10).toString()

        directSDK = DirectSDK()

        var cardDetails: PaymentItems? = null
        cardDetails = InputCard()
        directSDK!!.setCart_details(cardDetails)

        var layoutItems: LayoutItems? = null
        layoutItems = setLayout()
        directSDK!!.setLayout(layoutItems)

        directSDK!!.setPaymentChannel(menuPaymentChannel)
        directSDK!!.getResponse(object : iPaymentCallback {
            override fun onSuccess(text: String) {
                Log.d("RESPONSE", text)
                try {
                    respongetTokenSDK = JSONObject(text)
                    if (respongetTokenSDK!!.getString("res_response_code").equals("0000", ignoreCase = true)) {
                        jsonRespon = text
                        RequestPayment().execute()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }

            override fun onError(text: String) {
                Log.d("onError", text)
                Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show()
            }

            override fun onException(eSDK: Exception) {
                eSDK.printStackTrace()
            }
        }, applicationContext)
    }

    private fun InputCard(): PaymentItems {
        logInfo("Tag" + AppUtilsPayment.SHA1(AppUtilsPayment.generateMoneyFormat("15000") + "2074" + "eaM6i1JjS19J" + invoiceNumber + 360 + appInteractor!!.getDeviceInfo(activity())[0].deviceuniqueid))
        val paymentItems = PaymentItems()
        paymentItems.dataAmount = AppUtilsPayment.generateMoneyFormat("15000")
        paymentItems.dataBasket = "[{\"name\":\"sayur\",\"amount\":\"10000.00\",\"quantity\":\"1\",\"subtotal\":\"10000.00\"},{\"name\":\"buah\",\"amount\":\"10000.00\",\"quantity\":\"1\",\"subtotal\":\"10000.00\"}]"
        paymentItems.dataCurrency = "360"
        paymentItems.dataWords = AppUtilsPayment.SHA1(AppUtilsPayment.generateMoneyFormat("15000") + "2074" + "eaM6i1JjS19J" + invoiceNumber + 360 + appInteractor!!.getDeviceInfo(activity())[0].deviceuniqueid)
        paymentItems.dataMerchantChain = "NA"
        paymentItems.dataSessionID = AppUtilsPayment.nDigitRandomNo(9).toString()
        paymentItems.dataTransactionID = invoiceNumber
        paymentItems.dataMerchantCode = "2074"
        paymentItems.dataImei = appInteractor!!.getDeviceInfo(activity())[0].deviceuniqueid
        paymentItems.mobilePhone = "08123123112"
        paymentItems.publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsBkd2EipFMMn3hy/rgQ3UBYs0WFPiei2RFSU0r/ClJXgyh88Eq+BpKtSCivbCjCZE7YOhcdbtYonFIi+isheNv00zqo5msQNCvhT45uYZ2Arvh8+F9xGE+y1KTS7ruYnzsDHYTBv+MHOJxs0Yn1mi3+y0KSMIBhz5iSIPzQgnLdNww0VnhwNdCwlm1EeBBE4ijWAm7IWxrFAsmMynUVCZRzZ5tTU4mb8BEDc854Pu94m1YAugw74f7JzMol7tPf5MO79moXdvDmPKVzNrEvMVFDLk+KnvI/yYe4uReQA4H2glNB+hGRPjqDXztY/6EJBHDo79cjKSBmuU5WGYReRiwIDAQAB"
        paymentItems.isProduction(false)
        return paymentItems
    }

    private inner class RequestPayment : AsyncTask<String, String, JSONObject>() {
        override fun onPreExecute() {
            super.onPreExecute()
            showProgressDialog()
        }

        override fun doInBackground(vararg args: String): JSONObject? {
            var defResp: JSONObject? = null
            try {
                val data = ArrayList<NameValuePair>(3)
                data.add(BasicNameValuePair("data", jsonRespon))
                System.out.println("Tag" + jsonRespon)

                // Getting JSON from URL
                val conResult = ApiConnection.httpsConnection(activity(), RestConstant.URL_CHARGING_DOKU_DAN_CC, data)
                Log.d("CHARGING PAYMENT", conResult)
                defResp = JSONObject(conResult)

            } catch (e: JSONException) {
                e.printStackTrace()
            }
            return defResp
        }

        override fun onPostExecute(json: JSONObject?) {
            hideProgressDialog()
            if (json != null) {
                try {
                    if (json.getString("res_response_code").equals("0000", ignoreCase = true)) {
                        Toast.makeText(applicationContext, " PAYMENT SUKSES", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(applicationContext, "PAYMENT ERROR", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun setLayout(): LayoutItems {
        val layoutItems = LayoutItems()
        layoutItems.toolbarColor = "#F79E1C"
        layoutItems.toolbarTextColor = "#FFFFFF"
        layoutItems.fontColor = "#121212"
        layoutItems.backgroundColor = "#eaeaea"
        layoutItems.labelTextColor = "#9a9a9a"
        layoutItems.buttonBackground = resources.getDrawable(R.color.colorAccent)
        layoutItems.buttonTextColor = "#FFFFFF"

        return layoutItems
    }
}
