package com.restaurant.view

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.shipping.country.CountryResponse
import com.restaurant.model.api.response.shipping.district.DistrictResponse
import com.restaurant.model.api.response.shipping.orderdelivery.OrderDeliveryResponse

interface OpsiPengirimanView : BaseView {
    fun apiGetCountryResponse(response: CountryResponse)
    fun apiGetDistrictResponse(response: DistrictResponse)
    fun apiPostOrderDeliveryResponse(response: OrderDeliveryResponse)
}

