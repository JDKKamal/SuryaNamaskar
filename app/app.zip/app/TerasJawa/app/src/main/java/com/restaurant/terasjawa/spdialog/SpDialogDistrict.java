package com.restaurant.terasjawa.spdialog;

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;

import com.restaurant.terasjawa.R;
import com.restaurant.terasjawa.adapter.spinner.DistrictSpAdapter;

import java.util.ArrayList;
import java.util.List;

public class SpDialogDistrict extends Dialog {
    private AppCompatEditText appEdtSearch;
    private RelativeLayout rlSearch;
    private AppCompatTextView appTvCancel;
    private AppCompatTextView appTvTitle;
    private RecyclerView recyclerView;

    private Activity activity;
    private WindowManager.LayoutParams lp;
    private OnItemClick itemSelect;
    private String dialogTitle = "";

    private DistrictSpAdapter districtSpAdapter;
    private List alList = new ArrayList<>();

    public SpDialogDistrict(Activity activity, String title, OnItemClick itemSelect, List<?> alList) {
        super(activity);
        this.activity = activity;
        this.dialogTitle = title;
        this.itemSelect = itemSelect;
        this.alList.addAll(alList);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getWindow();
        window.setBackgroundDrawable(new ColorDrawable(Color.WHITE));

        setContentView(R.layout.custom_spinner_dialog);

        appTvTitle = findViewById(R.id.appTvTitle);
        appEdtSearch = findViewById(R.id.appEdtSearch);
        recyclerView = findViewById(R.id.recyclerView);
        appTvCancel = findViewById(R.id.appTvCancel);
        rlSearch = findViewById(R.id.rlSearch);

        recyclerView.setLayoutManager(new LinearLayoutManager(activity));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        appTvCancel.setOnClickListener(v -> dismiss());

        if (alList.size() <= 5) {
            rlSearch.setVisibility(View.GONE);
        }

        appTvTitle.setText(dialogTitle);

        districtSpAdapter = new DistrictSpAdapter(activity, alList, object -> {
            dismiss();
            if (itemSelect != null)
                itemSelect.selectedItem(object);
        });
        recyclerView.setAdapter(districtSpAdapter);

        //TODO FILTER
        filterCountry();

        Display display = activity.getWindowManager().getDefaultDisplay();
        int width = display.getWidth();

        final int height = display.getHeight();
        lp = new WindowManager.LayoutParams();
        lp.copyFrom(getWindow().getAttributes());

        lp.width = (int) (width - (width * 0.15));
        this.recyclerView.postDelayed(() -> {
            if (recyclerView.getHeight() >= ((int) (height - (height * 0.20))))
                lp.height = (int) (height - (height * 0.20));
            else
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

            getWindow().setAttributes(lp);
        }, 10);
    }

    private void filterCountry() {
        appEdtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (districtSpAdapter != null) {
                    districtSpAdapter.filter(charSequence.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public interface OnItemClick {
        void selectedItem(Object object);
    }
}
