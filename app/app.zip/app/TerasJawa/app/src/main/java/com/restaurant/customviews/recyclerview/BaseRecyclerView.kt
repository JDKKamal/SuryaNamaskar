package com.restaurant.customviews.recyclerview

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.support.v7.widget.RecyclerView

abstract class BaseRecyclerView<T> : RecyclerView.Adapter<BaseViewHolder<T>>() {

    protected abstract fun getItem(position: Int): T

    override fun onBindViewHolder(holder: BaseViewHolder<T>, position: Int) {
        holder.populateItem(getItem(position))
    }
}
