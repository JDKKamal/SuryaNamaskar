package com.restaurant.customviews.savepref

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager

import com.google.common.reflect.TypeParameter
import com.google.gson.Gson

open class FastSave {

    companion object {
         var mSharedPreferences: SharedPreferences? = null
          internal var instance: FastSave? = null

        @JvmStatic
        fun init(context: Context) {
            mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        }

        fun getInstance(): FastSave? {
            validateInitialization()
            if (instance == null) {
                synchronized(FastSave::class.java) {
                    instance = FastSave()
                }
            }
            return instance
        }

        private fun validateInitialization() {
            if (mSharedPreferences == null)
                throw FastException("FastSave Library must be initialized inside your application class by calling FastSave.init(getApplicationContext)")
        }
    }

    fun saveInt(key: String, value: Int) {
        val editor = mSharedPreferences!!.edit()
        editor.putInt(key, value)
        editor.apply()
    }

    fun getInt(key: String): Int {
        return mSharedPreferences!!.getInt(key, 0)
    }

    fun saveBoolean(key: String, value: Boolean) {
        val editor = mSharedPreferences!!.edit()
        editor.putBoolean(key, value)
        editor.apply()
    }

    fun getBoolean(key: String): Boolean {
        return mSharedPreferences!!.getBoolean(key, false)
    }

    fun saveFloat(key: String, value: Float) {
        val editor = mSharedPreferences!!.edit()
        editor.putFloat(key, value)
        editor.apply()
    }

    fun getFloat(key: String): Float {
        return mSharedPreferences!!.getFloat(key, 0.0f)
    }

    fun saveLong(key: String, value: Long) {
        val editor = mSharedPreferences!!.edit()
        editor.putLong(key, value)
        editor.apply()
    }

    fun getLong(key: String): Long {
        return mSharedPreferences!!.getLong(key, 0)
    }

    fun saveString(key: String, value: String) {
        val editor = mSharedPreferences!!.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun getString(key: String): String {
        return mSharedPreferences!!.getString(key, "")
    }

    fun <T> saveObject(key: String, `object`: T) {
        val objectString = Gson().toJson(`object`)
        val editor = mSharedPreferences!!.edit()
        editor.putString(key, objectString)
        editor.apply()
    }

    fun <T> getObject(key: String, classType: Class<T>): T? {
        val objectString = mSharedPreferences!!.getString(key, null)
        return if (objectString != null) {
            Gson().fromJson(objectString, classType)
        } else null
    }


    fun <T> saveObjectList(key: String, objectList: List<T>) {
        val objectString = Gson().toJson(objectList)
        val editor = mSharedPreferences!!.edit()
        editor.putString(key, objectString)
        editor.apply()
    }

    fun <T> getObjectList(key: String, classType: Class<T>): List<T>? {

        val objectString = mSharedPreferences!!.getString(key, null)
        return if (objectString != null) {
            Gson().fromJson<List<T>>(objectString, object : com.google.common.reflect.TypeToken<List<T>>() {
            }.where(object : TypeParameter<T>() {}, classType).type)
        } else null
    }

    fun clearSession() {
        val editor = mSharedPreferences!!.edit()
        editor.clear()
        editor.apply()
    }
}
