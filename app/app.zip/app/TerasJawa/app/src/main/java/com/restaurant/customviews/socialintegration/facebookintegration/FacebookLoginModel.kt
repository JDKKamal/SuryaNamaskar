package com.jdkgroup.customview.socialintegration.facebookintegration

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

class FacebookLoginModel(var authtoken: String?, var id: String?, var name: String?, var firstname: String?, var lastname: String?, var gender: String?, var email: String?, var profilePicture: String?, var cellno: String?)
