package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.comment.commentview.CommentViewResponse
import com.restaurant.view.CommentView
import kotlin.collections.HashMap

class CommentViewPresenter : BasePresenter<CommentView>() {
    private fun callApiGetCommentView(params: HashMap<String, String>) {
        appInteractor.apiGetCommentView(view!!.activity(), params, object : InterActorCallback<CommentViewResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: CommentViewResponse) {
                view!!.apiGetCommentViewResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    internal fun apiCall(params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() ->
                when (apiNo) {
                    RestConstant.CALL_API_COMMENT_VIEW -> callApiGetCommentView(params)
                }
        }
    }
}
