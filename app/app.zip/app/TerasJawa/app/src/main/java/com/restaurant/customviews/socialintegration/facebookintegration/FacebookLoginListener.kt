package com.jdkgroup.customview.socialintegration.facebookintegration

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

interface FacebookLoginListener {
    fun onFbSignInFail(errorMessage: String)
    fun onFbSignInSuccess(facebookLoginModel: FacebookLoginModel)
    fun onFBSignOut()
}
