package com.restaurant.model.api.response.signup.facebook

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FacebookResponse{
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("facebook_register")
    @Expose
    var facebookRegister: FacebookRegister? = null
}