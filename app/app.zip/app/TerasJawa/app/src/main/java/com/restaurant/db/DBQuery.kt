package com.restaurant.db

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Activity
import android.app.Application
import com.restaurant.model.db.CategoryListRealm
import io.realm.Realm
import io.realm.RealmModel

class DBQuery(application: Application) {
    val realm: Realm? = Realm.getDefaultInstance()

    internal fun closeRealm() {
        if (realm != null && !realm.isClosed) {
            realm.close()
        }
    }

    fun realmVersion(): Long {
        return realm!!.version
    }

    fun realmInsert(realmModel: RealmModel) {
        realm!!.beginTransaction()
        realm.insert(realmModel)
        realm.commitTransaction()
    }

    fun realmInsertList(list: Collection<RealmModel>) {
        realm!!.beginTransaction()
        realm.insert(list)
        realm.commitTransaction()
    }

    fun realmList(id: String): List<CategoryListRealm> {
        return realm!!.where(CategoryListRealm::class.java).equalTo("id", id).findAll()
    }

    fun realmDeleteCategoryId(id: String) {
        realm!!.beginTransaction()
        val result = realm.where(CategoryListRealm::class.java).equalTo("id", id).findAll()
        result.deleteAllFromRealm()
        realm.commitTransaction()
    }

    fun realmDeleteTable() {
        realm!!.beginTransaction()
        realm.delete(CategoryListRealm::class.java)
        realm.commitTransaction()
    }

    companion object {
        fun with(activity: Activity): DBQuery {
            return DBQuery(activity.application)
        }

        fun with(application: Application): DBQuery {
            return DBQuery(application)
        }
    }
}