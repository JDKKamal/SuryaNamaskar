package com.restaurant.model.db

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

@RealmClass
open class CategoryListRealm : RealmObject {
    @PrimaryKey
    var uuid: String? = null
    var id: String? = null

    constructor() {}

    constructor(uuid: String, id: String) {
        this.uuid = uuid
        this.id = id
    }
}
