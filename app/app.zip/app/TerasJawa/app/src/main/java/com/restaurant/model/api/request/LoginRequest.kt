package com.restaurant.model.api.request

class LoginRequest(var email: String? = null, var password: String? = null) {
}
