package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.View
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.AppConstant
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.CommentViewAdapter
import com.restaurant.model.api.response.comment.commentview.CommentViewResponse
import com.restaurant.model.parcelable.CommentParcelable
import com.restaurant.presenter.CommentViewPresenter
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.view.CommentView
import java.util.*

class CommentViewActivity : SimpleMVPActivity<CommentViewPresenter, CommentView>(), CommentView {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appTvBadge: AppCompatTextView? = null
    internal var recyclerView: RecyclerView? = null

    private var parcelableComment: List<CommentParcelable>? = null
    private lateinit var commentViewAdapter: CommentViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment_view)

        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)
        appTvBadge = toolBar!!.findViewById(R.id.appTvBadge)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        recyclerView = findViewById(R.id.recyclerView)

        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem
        setRecyclerView(recyclerView!!, 0, recyclerViewLinearLayout);

        parcelableComment = AppUtils.getParcelable(activity, AppConstant.BUNDLE_PARCELABLE)
        when {
            parcelableComment != null -> {
                appTvTitle!!.text = parcelableComment!![0].categoryName

                val param: HashMap<String, String> = hashMapOf(RestConstant.PARAM_VIEW_MORE_COMMENT to  parcelableComment!![0].mId)
                presenter!!.apiCall(param, RestConstant.CALL_API_COMMENT_VIEW)
            }
        }

        appIvDrawer!!.setOnClickListener { activity.finish() }
    }

    override fun onResume() {
        super.onResume()
        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun createPresenter(): CommentViewPresenter {
        return CommentViewPresenter()
    }

    override fun attachView(): CommentView {
        return this
    }

    override fun apiGetCommentViewResponse(response: CommentViewResponse) {
        when {
            response.response!!.code == RestConstant.OK_200 -> {
                commentViewAdapter = CommentViewAdapter(this, response.viewMoreCommentList!!)
                recyclerView!!.adapter = commentViewAdapter
            }
            else -> AppUtils.showToast(this, response.response!!.message + "")
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }
}
