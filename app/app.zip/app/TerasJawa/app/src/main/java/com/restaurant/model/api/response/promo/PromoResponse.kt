package com.restaurant.model.api.response.promo

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.restaurant.model.api.response.menucategory.MenuCartList

class PromoResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("menu_list_cat")
    @Expose
    var menuListCat: MutableList<PromoListCat>? = null
    @SerializedName("menu_cart")
    @Expose
    var menuCart: MutableList<MenuCartList>? = null
}
