package com.restaurant.view

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.menucategory.MenuCategoryResponse

interface MenuCategoryView : BaseView {
    fun apiPostMenuCategoryResponse(response: MenuCategoryResponse)
}