package com.restaurant.model.api.response.shipping.orderdelivery

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class OrderDeliveryDetail {

    @SerializedName("user_id")
    @Expose
    var userId: String? = null
    @SerializedName("title_name")
    @Expose
    var titleName: String? = null
    @SerializedName("full_name")
    @Expose
    var fullName: String? = null
    @SerializedName("mobile_number")
    @Expose
    var mobileNumber: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("state_id")
    @Expose
    var stateId: String? = null
    @SerializedName("country_id")
    @Expose
    var countryId: String? = null
}