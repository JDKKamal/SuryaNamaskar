package com.restaurant.terasjawa

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.restaurant.interacter.AppInteractor

class PromoCountService : Service() {
    private var appInteractor: AppInteractor? = null
    override fun onBind(intent: Intent): IBinder? {
        // TODO Auto-generated method stub
        return null
    }

    override fun onCreate() {
        //Toast.makeText(this, " MyService Created ", Toast.LENGTH_LONG).show();
    }

    override fun onStart(intent: Intent, startId: Int) {

    }

    override fun onDestroy() {
        super.onDestroy()
    }

}