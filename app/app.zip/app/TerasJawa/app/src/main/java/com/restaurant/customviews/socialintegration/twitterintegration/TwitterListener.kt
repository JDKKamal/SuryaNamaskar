package com.restaurant.customviews.socialintegration.twitterintegration

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

interface TwitterListener {
    fun onTwitterError()
    fun onTwitterSignIn(userId: String, userName: String)
    fun onTwitterProfileReceived(user: TwitterUser)
}