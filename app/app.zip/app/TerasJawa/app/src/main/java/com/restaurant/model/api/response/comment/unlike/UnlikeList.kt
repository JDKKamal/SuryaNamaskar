package com.restaurant.model.api.response.comment.unlike

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UnlikeList {

    @SerializedName("count(*)")
    @Expose
    var count: String? = null

}