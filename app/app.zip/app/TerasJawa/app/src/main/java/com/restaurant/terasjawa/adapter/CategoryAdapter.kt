package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.app.Activity
import android.support.v4.content.ContextCompat
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatRatingBar
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.constant.RestConstant
import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.db.DBQuery
import com.restaurant.model.api.response.menucategory.MenuCategoryList
import com.restaurant.terasjawa.R
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView

class CategoryAdapter(private val activity: Activity, private val menuName: String, private val menuCategoryList: MutableList<MenuCategoryList>) : BaseRecyclerView<MenuCategoryList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): MenuCategoryList {
        return menuCategoryList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<MenuCategoryList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_category, parent, false))
    }

    override fun getItemCount(): Int {
        return menuCategoryList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<MenuCategoryList>(itemView) {
        var appBtnMenu: AppCompatButton? = null
        var appIvMenu: CircleImageView? = null
        var appTvTitle: AppCompatTextView? = null
        var appTvPrice: AppCompatTextView? = null
        var appRbMenu: AppCompatRatingBar? = null

        init {
            appBtnMenu = itemView.findViewById(R.id.appBtnMenu)
            appIvMenu = itemView.findViewById(R.id.appIvMenu)
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appTvPrice = itemView.findViewById(R.id.appTvPrice)
            appRbMenu = itemView.findViewById(R.id.appRbMenu)
        }

        override fun populateItem(t: MenuCategoryList) {
            appBtnMenu!!.text = menuName;
            appTvPrice!!.text = t.menuPrice
            appTvTitle!!.text = t.menuName
            appRbMenu!!.rating = t.totalRate!!.toFloat()

            val categoryList = DBQuery.with(activity).realmList(t.mid!!)

            when {
                categoryList.isNotEmpty() -> {
                    appBtnMenu!!.setTextColor(ContextCompat.getColor(activity, R.color.colorWhite))
                    appBtnMenu!!.setBackgroundResource(R.mipmap.btn_bg)
                    appBtnMenu!!.text = "Pesan Menu";
                }
                else -> {
                    appBtnMenu!!.setTextColor(ContextCompat.getColor(activity, R.color.colorPesanMenu))
                    appBtnMenu!!.setBackgroundResource(R.mipmap.btn_bg_unselect)
                    appBtnMenu!!.text = "Telah Dipesan";
                }
            }

            AppUtils.glideSetAppImageView(activity, RestConstant.IMAGE_URL + t.menuImage, this!!.appIvMenu!!)

            itemView.setOnClickListener { listener!!.onClickCategory(menuCategoryList[layoutPosition]) }
        }
    }

    fun categoryAddAll(listAdd: MutableList<MenuCategoryList>) {
        menuCategoryList.clear()
        menuCategoryList.addAll(listAdd)
        notifyDataSetChanged()
    }

    interface ItemListener {
        fun onClickCategory(menuCategoryList: MenuCategoryList)
    }
}
