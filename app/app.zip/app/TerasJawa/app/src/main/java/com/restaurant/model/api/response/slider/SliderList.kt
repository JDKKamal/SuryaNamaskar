package com.restaurant.model.api.response.slider

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SliderList {

    @SerializedName("banner_name")
    @Expose
    var bannerName: String? = null
    @SerializedName("banner_desc")
    @Expose
    var bannerDesc: String? = null
    @SerializedName("banner_name_imagepath")
    @Expose
    var bannerNameImagepath: String? = null
    @SerializedName("banner_image")
    @Expose
    var bannerImage: String? = null
}

