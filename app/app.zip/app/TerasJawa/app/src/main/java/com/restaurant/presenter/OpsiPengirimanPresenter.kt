package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.request.DistrictRequest
import com.restaurant.model.api.request.OrderDeliveryRequest
import com.restaurant.model.api.response.shipping.country.CountryResponse
import com.restaurant.model.api.response.shipping.district.DistrictResponse
import com.restaurant.model.api.response.shipping.orderdelivery.OrderDeliveryResponse
import com.restaurant.utils.AppUtils
import com.restaurant.view.OpsiPengirimanView
import com.restaurant.utils.Validator
import kotlin.collections.HashMap

class OpsiPengirimanPresenter : BasePresenter<OpsiPengirimanView>() {
    private fun callApiGetCountry() {
        appInteractor.apiGetCountry(view!!.activity(), object : InterActorCallback<CountryResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: CountryResponse) {
                view!!.apiGetCountryResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    private fun callApiGetDistrict(params: HashMap<String, String>) {
        appInteractor.apiGetDistrict(view!!.activity(), params, object : InterActorCallback<DistrictResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: DistrictResponse) {
                view!!.apiGetDistrictResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    private fun callApiPostOrderDelivery( params: HashMap<String, String>) {
        appInteractor.apiPostOrderDelivery(view!!.activity(), params, object : InterActorCallback<OrderDeliveryResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: OrderDeliveryResponse) {
                view!!.apiPostOrderDeliveryResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    fun apiCall(apiNo: Int, districtRequest: DistrictRequest?, orderDeliveryRequest: OrderDeliveryRequest?) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_COUNTRY -> callApiGetCountry()
                RestConstant.CALL_API_DISTRICT -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_DISTRICT_CAT] = districtRequest!!.countryid
                    callApiGetDistrict(param)
                }
                RestConstant.CALL_API_ORDER_DELIVERY -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_USER_ID] = orderDeliveryRequest!!.userid
                    param[RestConstant.PARAM_TITLE_NAME] = orderDeliveryRequest.title
                    param[RestConstant.PARAM_FULL_NAME] = orderDeliveryRequest.fullname
                    param[RestConstant.PARAM_MOBILE_NUMBER] = orderDeliveryRequest.mobile
                    param[RestConstant.PARAM_ADDRESS] = orderDeliveryRequest.address
                    param[RestConstant.PARAM_COUNTRY_ID] = orderDeliveryRequest.countryid
                    param[RestConstant.PARAM_STATE_ID] = orderDeliveryRequest.stateid

                    callApiPostOrderDelivery(param)
                }
            }
        }
    }

    fun validation(title: String, fullName: String, address: String, country: String, district: String, districtDeliveryService: String, mobile: String): Boolean {
        return when {
            Validator.isEmpty(title) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_title_order))
                false
            }
            Validator.isEmpty(fullName) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_full_name_order))
                false
            }
            Validator.isEmpty(address) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_address))
                false
            }
            Validator.isEmpty(country) -> {
                AppUtils.showToast(view!!.activity(), "Pilih Kecamatan")
                false
            }
            Validator.isEmpty(district) || Validator.isEmpty(districtDeliveryService) -> {
                AppUtils.showToast(view!!.activity(), "Pilih Kelurahan")
                false
            }
            Validator.isEmpty(mobile) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_mobile))
                false
            }
            else -> true
        }
    }

}
