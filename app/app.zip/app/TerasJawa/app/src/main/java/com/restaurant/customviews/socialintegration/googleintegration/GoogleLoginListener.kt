package com.jdkgroup.customview.socialintegration.googleintegration

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

interface GoogleLoginListener {
    fun onGoogleAuthSignIn(googleLoginModel: GoogleLoginModel)
    fun onGoogleAuthSignInFailed(errorMessage: String)
    fun onGoogleAuthSignOut()
}
