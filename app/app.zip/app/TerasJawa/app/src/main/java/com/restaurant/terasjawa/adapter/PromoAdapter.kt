package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.app.Activity
import android.support.v4.content.ContextCompat
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatRatingBar
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.constant.RestConstant
import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.db.DBQuery
import com.restaurant.terasjawa.R
import com.restaurant.model.api.response.promo.PromoListCat
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView

class PromoAdapter(private val activity: Activity, private val menuCategoryList: MutableList<PromoListCat>) : BaseRecyclerView<PromoListCat>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): PromoListCat {
        return menuCategoryList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<PromoListCat> {
        return ViewHolder(inflater.inflate(R.layout.itemview_promo, parent, false))
    }

    override fun getItemCount(): Int {
        return menuCategoryList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<PromoListCat>(itemView) {
        var appBtnMenu: AppCompatButton? = null
        var appIvMenu: CircleImageView? = null
        var appTvTitle: AppCompatTextView? = null
        var appTvPromo: AppCompatTextView? = null
        var appTvPrice: AppCompatTextView? = null
        var appRbMenu: AppCompatRatingBar? = null

        init {
            appBtnMenu = itemView.findViewById(R.id.appBtnMenu)
            appIvMenu = itemView.findViewById(R.id.appIvMenu)
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appTvPromo = itemView.findViewById(R.id.appTvPromo)
            appTvPrice = itemView.findViewById(R.id.appTvPrice)
            appRbMenu = itemView.findViewById(R.id.appRbMenu)
        }

        override fun populateItem(t: PromoListCat) {
            appBtnMenu!!.text = "Pesana Menu";
            appTvPrice!!.text = t.specialPrice
            appTvTitle!!.text = t.menuName
            appRbMenu!!.rating = java.lang.Float.valueOf(t.totalRate)

            val categoryList = DBQuery.with(activity).realmList(t.mid!!)

            when {
                categoryList.isNotEmpty() -> {
                    appBtnMenu!!.setTextColor(ContextCompat.getColor(activity, R.color.colorWhite))
                    appBtnMenu!!.setBackgroundResource(R.mipmap.btn_bg)
                    appBtnMenu!!.text = "Pesan Menu";
                }
                else -> {
                    appBtnMenu!!.setTextColor(ContextCompat.getColor(activity, R.color.colorPesanMenu))
                    appBtnMenu!!.setBackgroundResource(R.mipmap.btn_bg_unselect)
                    appBtnMenu!!.text = "Telah Dipesan";
                }
            }

            AppUtils.glideSetAppImageView(activity, RestConstant.IMAGE_URL + t.menuImage, appIvMenu!!)

            appTvPromo!!.text = t.menuPrice

            itemView.setOnClickListener { listener!!.onClickPromo(menuCategoryList[layoutPosition]) }
        }
    }

    fun promoAddAll(listAdd: MutableList<PromoListCat>) {
        menuCategoryList.clear()
        menuCategoryList.addAll(listAdd)
        notifyDataSetChanged()
    }

    interface ItemListener {
        fun onClickPromo(promoListCat: PromoListCat)
    }
}
