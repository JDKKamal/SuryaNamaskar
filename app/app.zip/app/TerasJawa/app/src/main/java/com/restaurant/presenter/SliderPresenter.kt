package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.slider.SliderResponse
import com.restaurant.view.SliderView

class SliderPresenter : BasePresenter<SliderView>() {
    private fun callApiGetSlider() {
        appInteractor.apiGetSlider(view!!.activity(), object : InterActorCallback<SliderResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: SliderResponse) {
                view!!.apiGetSliderResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_SLIDER -> callApiGetSlider()
            }
        }
    }
}
