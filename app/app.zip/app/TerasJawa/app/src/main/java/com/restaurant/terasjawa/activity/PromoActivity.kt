package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.View
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.constant.AppConstant
import com.restaurant.db.DBQuery
import com.restaurant.terasjawa.adapter.PromoAdapter
import com.restaurant.model.api.response.promo.PromoListCat
import com.restaurant.model.api.response.promo.PromoResponse
import com.restaurant.model.db.CategoryListRealm
import com.restaurant.model.parcelable.CategoryParcelable
import com.restaurant.presenter.PromoPresenter
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.view.PromoView
import kotlinx.android.synthetic.main.activity_promo.*
import java.util.*

class PromoActivity : SimpleMVPActivity<PromoPresenter, PromoView>(), PromoView, PromoAdapter.ItemListener {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appTvBadge: AppCompatTextView? = null
    internal var recyclerView: RecyclerView? = null

    private lateinit var promoAdapter: PromoAdapter
    private var listPromo : MutableList<PromoListCat>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_promo)

        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)
        appTvBadge = toolBar!!.findViewById(R.id.appTvBadge)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        recyclerView = findViewById(R.id.recyclerView)

        appTvTitle!!.text = getString(R.string.toolbar_title_promo).toUpperCase()
        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem

        setRecyclerView(recyclerView!!, 2, recyclerViewGridLayout);

        listPromo = mutableListOf()
        presenter!!.apiCall(1, RestConstant.CALL_API_PROMO)
        promoAdapter = PromoAdapter(this, listPromo!!)
        promoAdapter.setOnListener(this)
        recyclerView!!.adapter = promoAdapter

        if (hasInternet()) {
            findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    presenter!!.apiCall(0, RestConstant.CALL_API_PROMO)
                }, 1000)
            }
        }

        findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)

        appIvDrawer!!.setOnClickListener { activity.finish() }
    }

    override fun onResume() {
        super.onResume()
        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem

        promoAdapter.notifyDataSetChanged()
    }

    override fun createPresenter(): PromoPresenter {
        return PromoPresenter()
    }

    override fun attachView(): PromoView {
        return this
    }

    override fun apiPostPromoResponse(response: PromoResponse) {
        swipeRefreshLayout.isRefreshing = false

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                when {
                    response.menuCart!!.isNotEmpty() -> {
                        DBQuery.with(this).realmDeleteTable()
                        response.menuCart!!.forEach { cartList -> DBQuery.with(this).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), cartList.menuId!!)) }
                    }
                    else -> DBQuery.with(this).realmDeleteTable()
                }

                promoAdapter.promoAddAll(response.menuListCat!!)
            }
            else -> AppUtils.showToast(this, response.response!!.message + "")
        }
    }

    override fun onClickPromo(promoListCat: PromoListCat) {
        val listCategoryPassData = ArrayList<CategoryParcelable>()
        listCategoryPassData.add(
                CategoryParcelable("",
                        promoListCat.menuName!!, //parcelableTopic!![0].categoryName
                        promoListCat.mid!!,
                        promoListCat.menuName!!,
                        promoListCat.menuInfo!!,
                        promoListCat.menuImage!!,
                        promoListCat.totalRate!!,
                        promoListCat.rateAvg!!,
                        promoListCat.specialPrice!!
                ))
        AppUtils.sentParcelsLaunchClear(activity, DetailActivity::class.java, AppConstant.BUNDLE_PARCELABLE, listCategoryPassData, 1)
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }
}
