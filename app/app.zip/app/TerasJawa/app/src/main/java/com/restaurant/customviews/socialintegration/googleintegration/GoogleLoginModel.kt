package com.jdkgroup.customview.socialintegration.googleintegration

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.net.Uri

class GoogleLoginModel(var authtoken: String?, var id: String?, var name: String?, var email: String?, var profilePicture: Uri?)
