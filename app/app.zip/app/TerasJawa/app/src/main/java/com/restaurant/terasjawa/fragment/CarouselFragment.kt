package com.restaurant.terasjawa.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import com.restaurant.baseclass.BaseFragment
import com.restaurant.customviews.carousel.CarouselLinearLayout
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.activity.SliderActivity

class CarouselFragment : BaseFragment() {
    private var screenWidth: Int = 0
    private var screenHeight: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getWidthAndHeight()

    }

    @SuppressLint("SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if (container == null) {
            return null
        }

        val position = this.arguments!!.getInt(POSITON)
        val scale = this.arguments!!.getFloat(SCALE)

        val layoutParams = LinearLayout.LayoutParams(screenWidth / 2, screenHeight / 3)
        val linearLayout = inflater.inflate(R.layout.fragment_carousel, container, false) as LinearLayout

        val appTvDescription = linearLayout.findViewById<AppCompatTextView>(R.id.appTvDescription)
        val appTvTitle = linearLayout.findViewById<AppCompatTextView>(R.id.appTvTitle)
        val root = linearLayout.findViewById<CarouselLinearLayout>(R.id.root_container)
        val imageView = linearLayout.findViewById(R.id.pagerImg) as AppCompatImageView

        appTvTitle.text = SliderActivity.listSlider!![position].bannerName
        appTvDescription.text = SliderActivity.listSlider!![position].bannerDesc
        imageView.layoutParams = layoutParams
        Glide.with(activity!!).load(SliderActivity.listSlider!![position].bannerNameImagepath).into(imageView);

        //HANDLING CLICK EVENT
        imageView.setOnClickListener { }
        root.setScaleBoth(scale)
        return linearLayout
    }

    /**
     * GET DEVICE SCREEN WIDTH AND HEIGHT
     */
    private fun getWidthAndHeight() {
        val displayMetrics = DisplayMetrics()
        activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)
        screenHeight = displayMetrics.heightPixels
        screenWidth = displayMetrics.widthPixels
    }

    companion object {
        private val POSITON = "position"
        private val SCALE = "scale"

        fun newInstance(context: SliderActivity, pos: Int, scale: Float): Fragment {
            val b = Bundle()
            b.putInt(POSITON, pos)
            b.putFloat(SCALE, scale)

            return Fragment.instantiate(context, CarouselFragment::class.java.name, b)
        }
    }
}