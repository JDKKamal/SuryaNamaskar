package com.restaurant.model.api.response.signup.twitter

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TwitterSignUpResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("twiter_register")
    @Expose
    var twiterRegister: TwiterRegister? = null
}