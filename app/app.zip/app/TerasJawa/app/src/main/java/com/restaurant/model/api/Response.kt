package com.restaurant.model.api

open class Response {
    var code: Int? = null
    var message: String? = null
    var urlpath: String? = null
}

