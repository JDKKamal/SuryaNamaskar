package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/
import com.restaurant.baseclass.BasePresenter
import com.restaurant.terasjawa.R
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.profile.ProfileResponse
import com.restaurant.utils.AppUtils
import com.restaurant.view.ProfileView
import com.restaurant.utils.Validator
import okhttp3.MultipartBody
import okhttp3.RequestBody

class ProfilePresenter : BasePresenter<ProfileView>() {
    fun callApiProfile(image: MultipartBody.Part, userId: RequestBody, name: RequestBody, email: RequestBody, password: RequestBody, mobile: RequestBody, address: RequestBody) {
        when {
            hasInternet() -> appInteractor.apiPostProfile(view!!.activity(), image, userId, name, email, password, mobile,  address, object : InterActorCallback<ProfileResponse> {
                override fun onStart() {
                    view!!.showProgressDialog(true)
                }

                override fun onResponse(response: ProfileResponse) {
                    view!!.apiPostProfileResponse(response)
                }

                override fun onFinish() {
                    view!!.showProgressDialog(false)
                }

                override fun onError(message: String) {
                    view!!.onFailure(message)
                }

            })
        }
    }

    fun validation(name: String, email: String, mobile: String, password: String): Boolean {
        return when {
            Validator.isEmpty(name) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_name))
                false
            }
            Validator.isEmpty(email) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_email))
                false
            }
            !Validator.isRegexValidator(email, Validator.patternEmail) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_valid_email))
                false
            }
            !Validator.isEmpty(mobile) && !Validator.isRegexValidator(mobile, Validator.patternMobile) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_valid_mobile))
                false
            }
            else -> true
        }
    }
}