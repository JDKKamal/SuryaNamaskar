package com.restaurant.constant

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

class AppConstant {
    companion object {

        const val DEFAULT_PRICE = "00"

        // extension
        const val EXTENSION_JSON = "json"
        const val EXTENSION_JPG = ".jpg"
        const val FOLDER_NAME = "/.eResto/bytotech"

        //BUNDlE
        const val BUNDLE = "bundle"
        const val BUNDLE_PARCELABLE = "parcelable"

        //FONT
        const val FONT_AILERON_SEMIBOLD = "fonts/aileron_semi_bold.otf"
        const val FONT_AILERON_REGULAR = "fonts/aileron_regular.otf"

        //LOCAL READ FILE


        //LAUNCH ACTIVITY OR FRAGMENT

        /* BASIC */
        const val SP_IS_LOGIN = "is_login"
        const val SP_IS_TOKEN = "is_token"
        const val SP_DEVICE_TOKEN = "device_token"
        const val SP_AUTH_TOKEN = "auth_token"
        const val SP_FCM_TOKEN = "fcm_token"
        const val SP_CART_ITEM = "cart_item"
        const val SP_PROMO_ITEM = "promo_item"
        const val SP_USERNAME = "name"
        const val SP_EMAIL = "email"
        const val SP_PROFILE_PICTURE = "profile_picture"
        const val SP_MOBILE = "mobile"
        const val SP_SOCIAL_ID = "social_id"
        const val SP_DEVICE_ID = "device_id"
        const val SP_IS_LOGOUT= "is_logout"
        const val SP_USER_ID = "user_id"
        const val SP_LOGIN_STATUS = "login_status"

        const val SP_SETTING_SIGNUP = "setting_sign_up"
        const  val SP_SETTING_LOGIN = "setting_login"
        const val SP_SETTING_USERNAME = "setting_username"
        const val SP_SETTING_EMAIL = "setting_email"

        const val SP_SETTING_MOBILE = "setting_mobile"
        const  val SP_SETTING_PROFILE_PICTURE = "setting_profile_picture"
        const val SP_SETTING_PASSWORD = "setting_password"

        const val SP_APP_LOAD = "app_load"
    }
}

