package com.restaurant.model.api.response.shipping.district

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DistrictList {

    @SerializedName("state_id")
    @Expose
    var stateId: String? = null
    @SerializedName("state_name")
    @Expose
    var stateName: String? = null
    @SerializedName("service_charge")
    @Expose
    var serviceCharge: String? = null
}