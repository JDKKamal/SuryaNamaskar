package com.restaurant.model;

public class ModelOrderStatus {
}
