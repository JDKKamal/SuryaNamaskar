package com.restaurant.model.api.response.menu

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("menucategory_list")
    @Expose
    var menucategoryList: MutableList<MenuList>? = null
}
