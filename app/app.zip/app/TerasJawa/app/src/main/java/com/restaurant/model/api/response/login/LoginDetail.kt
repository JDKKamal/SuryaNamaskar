package com.restaurant.model.api.response.login

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LoginDetail {

    @SerializedName("user_id")
    @Expose
    var userId: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("email")
    @Expose
    var email: String? = null
    @SerializedName("phone")
    @Expose
    var phone: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("user_image")
    @Expose
    var userImage: String? = null
    @SerializedName("cart_items")
    @Expose
    var cartItems: Int? = null
    @SerializedName("promo_rowcount")
    @Expose
    var promoRowcount: String? = null
}