package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.app.AlertDialog
import android.os.Bundle
import android.support.v7.widget.*
import android.view.View
import android.widget.LinearLayout
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.AppConstant
import com.restaurant.constant.RestConstant
import com.restaurant.db.DBQuery
import com.restaurant.model.api.response.DefaultResponse
import com.restaurant.model.api.response.comment.commentlist.CommentList
import com.restaurant.model.api.response.comment.commentlist.CommentResponse
import com.restaurant.model.api.response.comment.like.LikeResponse
import com.restaurant.model.api.response.comment.logincomment.LoginCommentResponse
import com.restaurant.model.api.response.comment.subcomment.SubCommentResponse
import com.restaurant.model.api.response.comment.unlike.UnLikeResponse
import com.restaurant.model.db.CategoryListRealm
import com.restaurant.model.parcelable.CategoryParcelable
import com.restaurant.model.parcelable.CommentParcelable
import com.restaurant.presenter.DetailPresenter
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.CommentAdapter
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.view.DetailView
import java.util.*

class DetailActivity : SimpleMVPActivity<DetailPresenter, DetailView>(), DetailView, CommentAdapter.ItemListener {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appTvBadge: AppCompatTextView? = null

    private var appTvTitleCategory: AppCompatTextView? = null
    private var appTvRateAvgCategory: AppCompatTextView? = null
    private var appRbCategory: AppCompatRatingBar? = null
    private var appTvTotalRatingCategory: AppCompatTextView? = null
    private var appTvPrice: AppCompatTextView? = null
    private var appTvDetail: AppCompatTextView? = null
    private var appIvCategoryImage: AppCompatImageView? = null

    val appIvLoginCommentSend by bind<AppCompatImageView>(R.id.appIvLoginCommentSend)
    val appEdtLoginComment by bind<AppCompatEditText>(R.id.appEdtLoginComment)
    val LlLoginRatting by bind<LinearLayout>(R.id.LlLoginRatting)
    val recyclerView by bind<RecyclerView>(R.id.recyclerView)

    private var loginRatting: String? = null
    private var listCategoryParcelable: List<CategoryParcelable>? = null
    private lateinit var commentAdapter: CommentAdapter

    private var commentList: CommentList? = null
    private var position: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_menu)

        hideSoftKeyboard()
        setRecyclerView(recyclerView, 0, recyclerViewLinearLayout)
        loginRatting = "0"

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)
        appTvBadge = toolBar!!.findViewById(R.id.appTvBadge)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        appTvTitleCategory = findViewById(R.id.appTvTitleCategory)
        appTvRateAvgCategory = findViewById(R.id.appTvRateAvgCategory)
        appRbCategory = findViewById(R.id.appRbCategory)
        appTvTotalRatingCategory = findViewById(R.id.appTvTotalRatingCategory)
        appTvPrice = findViewById(R.id.appTvPrice)
        appTvDetail = findViewById(R.id.appTvDetail)
        appIvCategoryImage = findViewById(R.id.appIvCategoryImage)

        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem

        listCategoryParcelable = AppUtils.getParcelable(activity, AppConstant.BUNDLE_PARCELABLE)
        if (listCategoryParcelable!!.isNotEmpty()) {
            appTvTitle!!.text = listCategoryParcelable!![0].nameMenu.toUpperCase()
            appTvTitleCategory!!.text = listCategoryParcelable!![0].nameCategory
            appTvRateAvgCategory!!.text = listCategoryParcelable!![0].totalRateAvgCategory
            appRbCategory!!.rating = listCategoryParcelable!![0].totalRateAvgCategory.toFloat()
            appTvTotalRatingCategory!!.text = "(" + listCategoryParcelable!![0].totalRateCategory + " ratings)"
            appTvDetail!!.text = listCategoryParcelable!![0].descriptionCategory
            appTvPrice!!.text = listCategoryParcelable!![0].priceCategory.toString()

            AppUtils.glideSetAppImageView(this, RestConstant.IMAGE_URL + listCategoryParcelable!![0].imageCategory, this.appIvCategoryImage!!)
        }

        val param: HashMap<String, String> = hashMapOf(
                RestConstant.PARAM_MID to listCategoryParcelable!![0].idCategory
        )
        presenter!!.apiCall(param, RestConstant.CALL_API_COMMENT_LIST)

        findViewById<AppCompatButton>(R.id.appBtnPesanMenu).setOnClickListener(
                {
                    if (listCategoryParcelable!!.isNotEmpty()) {
                        val param: HashMap<String, String> = hashMapOf(
                                RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                                RestConstant.MENU_ID to listCategoryParcelable!![0].idCategory,
                                RestConstant.MENU_NAME to  listCategoryParcelable!![0].nameCategory,
                                RestConstant.MENU_QTY to "1",
                                RestConstant.MENU_PRICE to listCategoryParcelable!![0].priceCategory
                        )
                        presenter!!.apiCall(param, RestConstant.CALL_API_ADD_TO_CART)
                    }
                })

        appIvLoginCommentSend.setOnClickListener({
            var loginComment = appEdtLoginComment.text.toString()
            if (loginRatting!!.isEmpty()) {
                loginRatting = "0"
            }

            val param: HashMap<String, String> = hashMapOf(
                    RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                    RestConstant.PARAM_RATE to loginRatting.toString(),
                    RestConstant.PARAM_MSG to  loginComment,
                    RestConstant.PARAM_MID to listCategoryParcelable!![0].idCategory
            )
            presenter!!.apiCall(param, RestConstant.CALL_API_COMMENT_LOGIN)
        })

        LlLoginRatting.setOnClickListener({
            dialogLoginComment()
        })

        appIvDrawer!!.setOnClickListener { activity.finish() }
    }

    override fun onResume() {
        super.onResume()

        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun createPresenter(): DetailPresenter {
        return DetailPresenter()
    }

    override fun attachView(): DetailView {
        return this
    }

    override fun apiGetAddToCartResponse(response: DefaultResponse) {
        if (response.response!!.code == RestConstant.OK_200) {
            DBQuery.with(activity()).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), listCategoryParcelable!![0].idCategory))
        }

        AppUtils.startActivity(activity, RincianPesananAndaActivity::class.java)
    }

    override fun apiGetLoginCommentResponse(response: LoginCommentResponse) {
        //AppUtils.showToast(this, response.response!!.message + "")
        appEdtLoginComment.text = null

        val param: HashMap<String, String> = hashMapOf(
                RestConstant.PARAM_MID to  listCategoryParcelable!![0].idCategory
        )
        presenter!!.apiCall(param, RestConstant.CALL_API_COMMENT_LIST)
    }

    override fun apiPostCommentListResponse(response: CommentResponse) {
        if (response.response!!.code == RestConstant.OK_200) {
            commentAdapter = CommentAdapter(activity, response.commentList!!)
            commentAdapter.setOnListener(this)
            recyclerView.adapter = commentAdapter
        } else {
            //AppUtils.showToast(this, response.response!!.message + "")
        }
    }

    override fun apiPostSubCommentResponse(response: SubCommentResponse) {

    }

    override fun onClickViewComment(commentList: CommentList) {
        val alPassDataQuestion = ArrayList<CommentParcelable>()
        alPassDataQuestion.add(CommentParcelable(commentList.rId!!, commentList.name!!, listCategoryParcelable!![0].nameCategory))
        AppUtils.sentParcelsLaunchClear(activity, CommentViewActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
    }

    override fun apiPostLikeResponse(response: LikeResponse) {
        commentAdapter.likeCount(this.position!!, this.commentList!!)
    }

    override fun apiPostUnLikeResponse(response: UnLikeResponse) {
        commentAdapter.unLikeCount(this.position!!, this.commentList!!)
    }

    override fun onClickLike(position: Int, commentList: CommentList) {
        this.commentList = commentList
        this.position = position
        when {
            commentList.likeUnlike == 0 -> {
                val param: HashMap<String, String> = hashMapOf(
                        RestConstant.PARAM_USER_ID to commentList.ip.toString(),
                        RestConstant.PARAM_R_ID to commentList.rId.toString()
                )

                presenter!!.apiCall(param, RestConstant.CALL_API_LIKE)
            }
            else -> {
                if (PreferenceUtils.preferenceInstance(this).userId == commentList.ip.toString()) {
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_USER_ID to commentList.ip.toString(),
                            RestConstant.PARAM_R_ID to commentList.rId.toString()
                    )

                    presenter!!.apiCall(param, RestConstant.CALL_API_UNLIKE)
                }
            }
        }
    }

    override fun onClickChildComment(commentList: CommentList) {
        dialogSubComment(commentList)
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }

    private fun dialogLoginComment() {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_ratting, null)
        alertDialog.setView(dialogView)

        val appRbLoginRatting = dialogView.findViewById(R.id.appRbLoginRatting) as AppCompatRatingBar
        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        appTvYes.setOnClickListener(
                {
                    loginRatting = appRbLoginRatting.rating.toString()
                    alertDialog.dismiss()
                }
        )
        appTvNo.setOnClickListener(
                {
                    loginRatting = "0"
                    alertDialog.dismiss()
                })

        alertDialog.show()
    }

    private fun dialogSubComment(commentList: CommentList) {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_sub_comment, null)
        alertDialog.setView(dialogView)

        val appEdtComment = dialogView.findViewById(R.id.appEdtComment) as AppCompatEditText
        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        appTvYes.setOnClickListener(
                {
                    if (presenter!!.validationComment(appEdtComment.text.toString())) {

                        val param: HashMap<String, String> = hashMapOf(
                                RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                                RestConstant.PARAM_COMMENT to appEdtComment.text.toString(),
                                RestConstant.PARAM_R_ID to commentList.rId.toString(),
                                RestConstant.PARAM_MID to listCategoryParcelable!![0].idCategory
                        )

                        presenter!!.apiCall(param, RestConstant.CALL_API_SUB_COMMENT)
                        alertDialog.dismiss()
                    }
                }
        )
        appTvNo.setOnClickListener(
                {
                    loginRatting = "0"
                    alertDialog.dismiss()
                })

        alertDialog.show()
    }
}
