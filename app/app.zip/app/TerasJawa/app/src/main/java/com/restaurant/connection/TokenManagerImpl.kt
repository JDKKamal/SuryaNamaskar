package com.restaurant.connection

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import com.restaurant.utils.PreferenceUtils

class TokenManagerImpl(private val context: Context) : TokenManager {

    override //TOKEN SET
    val token: String
        get() = PreferenceUtils.preferenceInstance(context).deviceToken

    override fun hasToken(): Boolean {
        //TOKEN CHECK
        return PreferenceUtils.preferenceInstance(context).isToken
    }

    override fun clearToken() {
        //TOKEN CLEAR
        PreferenceUtils.preferenceInstance(context).deviceToken = ""
    }

    @Synchronized
    override fun refreshToken() {
        //TOKEN REFRESH
    }
}
