package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatRatingBar
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.terasjawa.R
import com.restaurant.model.api.response.comment.commentlist.CommentList
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView

class CommentAdapter(private val context: Context, private val commentList: MutableList<CommentList>) : BaseRecyclerView<CommentList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): CommentList {
        return commentList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<CommentList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_section_parent, parent, false))
    }

    override fun getItemCount(): Int {
        return commentList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<CommentList>(itemView) {
        var tvParentTitle: AppCompatTextView? = null
        var appTvParentComment: AppCompatTextView? = null
        var appRbParentComment: AppCompatRatingBar? = null
        var appTvParentCommentCount: AppCompatTextView? = null
        var appIvParentCommentAdd: AppCompatImageView? = null


        var appIvParent: CircleImageView? = null
        var appTvParentLikeCount: AppCompatTextView? = null
        var appIvParentLike: AppCompatImageView? = null
        var appTvParentView: AppCompatTextView? = null

        init {
            appTvParentView = itemView.findViewById(R.id.appTvParentView)
            tvParentTitle = itemView.findViewById(R.id.tvParentTitle)
            appTvParentComment = itemView.findViewById(R.id.appTvParentComment)
            appRbParentComment = itemView.findViewById(R.id.appRbParentComment)
            appTvParentCommentCount = itemView.findViewById(R.id.appTvParentCommentCount)
            appIvParentCommentAdd= itemView.findViewById(R.id.appIvParentCommentAdd)
            appIvParent = itemView.findViewById(R.id.appIvParent)
            appTvParentLikeCount = itemView.findViewById(R.id.appTvParentLikeCount)
            appIvParentLike = itemView.findViewById(R.id.appIvParentLike)
        }

        override fun populateItem(t: CommentList) {
            if (t.userImage!!.isNotEmpty()) {
                AppUtils.glideSetAppImageView(context, t.userImage!!, appIvParent!!)
            }

            tvParentTitle!!.text = t.name
            appRbParentComment!!.rating = t.rate!!.toFloat()
            appTvParentComment!!.text = t.msg

            if (t.count!!.isNotEmpty()) {
                appTvParentCommentCount!!.text = "Comments available"
            } else {
                appTvParentCommentCount!!.text = "No comments"
            }
            if (t.count!!.isNotEmpty()) {
                appTvParentLikeCount!!.text = t.count.toString() + " Likes"
            } else {
                appTvParentLikeCount!!.text = "0 Likes"
            }

            /* if (PreferenceUtils.preferenceInstance(context).userId == userId) {
                 sectionViewHolder.appIvParentLike.setColorFilter(R.color.colorLike)
             } else {
                 sectionViewHolder.appIvParentLike.setColorFilter(R.color.colorUnlike)
             }*/

            appIvParentCommentAdd!!.setOnClickListener({
                listener!!.onClickChildComment(commentList[layoutPosition])
            })

            appIvParentLike!!.setOnClickListener({
                listener!!.onClickLike(layoutPosition, commentList[layoutPosition])
            })

            appTvParentView!!.setOnClickListener({
                listener!!.onClickLike(layoutPosition, commentList[layoutPosition])
            })

            appTvParentView!!.setOnClickListener({
                listener!!.onClickViewComment(commentList[layoutPosition])
            })
        }
    }

    interface ItemListener {
        fun onClickChildComment(commentList: CommentList)
        fun onClickLike(position: Int, commentList: CommentList)
        fun onClickViewComment(commentList: CommentList)
    }

    fun likeCount(position: Int, item : CommentList) {
        var calCount = item.count!!.toInt() + 1
        commentList[position] = CommentList(calCount.toString(), item.rId, item.ip, item.rate, item.msg, item.name, item.userImage, 1)
        notifyItemChanged(position)
    }

    fun unLikeCount(position: Int, item : CommentList) {
        var calCount = item.count!!.toInt() - 1
        commentList[position] = CommentList(calCount.toString(), item.rId, item.ip, item.rate, item.msg, item.name, item.userImage, 0)
        notifyItemChanged(position)
    }
}
