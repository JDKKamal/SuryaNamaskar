package com.restaurant.model.api.response.comment.commentview

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ViewMoreCommentList {

    @SerializedName("c_id")
    @Expose
    var cId: String? = null
    @SerializedName("comment")
    @Expose
    var comment: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("user_image")
    @Expose
    var userImage: String? = null
    @SerializedName("user_id")
    @Expose
    var userId: String? = null

}