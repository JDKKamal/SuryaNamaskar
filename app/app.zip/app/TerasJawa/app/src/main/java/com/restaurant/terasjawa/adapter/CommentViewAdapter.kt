package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.app.Activity
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.terasjawa.R
import com.restaurant.model.api.response.comment.commentview.ViewMoreCommentList
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView

class CommentViewAdapter(private val activity: Activity, private val profiles: List<ViewMoreCommentList>) : BaseRecyclerView<ViewMoreCommentList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    override fun getItem(position: Int): ViewMoreCommentList {
        return profiles[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<ViewMoreCommentList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_section_child, parent, false))
    }

    override fun getItemCount(): Int {
        return profiles.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<ViewMoreCommentList>(itemView) {
        var appTvChildTitle: AppCompatTextView? = null
        var appTvChildComment: AppCompatTextView? = null
        var appIvChild: CircleImageView? = null

        init {
            appTvChildTitle = itemView.findViewById(R.id.appTvChildTitle)
            appTvChildComment = itemView.findViewById(R.id.appTvChildComment)
            appIvChild = itemView.findViewById(R.id.appIvChild)
        }

        override fun populateItem(t: ViewMoreCommentList) {
            appTvChildTitle!!.text = t.name
            appTvChildComment!!.text = t.comment

            AppUtils.glideSetAppImageView(activity, t.userImage!!, this.appIvChild!!)

        }
    }
}
