package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.*
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.AppConstant
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.spdialog.SpDialogCountry
import com.restaurant.terasjawa.spdialog.SpDialogDistrict
import com.restaurant.model.api.request.DistrictRequest
import com.restaurant.model.api.response.shipping.country.CountryList
import com.restaurant.model.api.response.shipping.country.CountryResponse
import com.restaurant.model.api.response.shipping.district.DistrictList
import com.restaurant.model.api.response.shipping.district.DistrictResponse
import com.restaurant.model.api.response.shipping.orderdelivery.OrderDeliveryResponse
import com.restaurant.model.parcelable.DeliveryParcelable
import com.restaurant.presenter.OpsiPengirimanPresenter
import com.restaurant.utils.AppUtils
import com.restaurant.view.OpsiPengirimanView
import com.restaurant.utils.Validator

class OpsiPengirimanDeliveryActivity : SimpleMVPActivity<OpsiPengirimanPresenter, OpsiPengirimanView>(), OpsiPengirimanView {
    internal var appBtnDelivery: AppCompatButton? = null

    internal var toolBar: Toolbar? = null
    internal var appTvTitle: AppCompatTextView? = null
    internal var appIvDrawer: AppCompatImageView? = null
    internal var rlCount: RelativeLayout? = null

    private val appTvCountry by bind<AppCompatTextView>(R.id.appTvCountry)
    private val appTvDistrict by bind<AppCompatTextView>(R.id.appTvDistrict)
    private val appEdtTitle by bind<AppCompatEditText>(R.id.appEdtTitle)
    private val appEdtFullName by bind<AppCompatEditText>(R.id.appEdtFullName)
    private val appEdtAddress by bind<AppCompatEditText>(R.id.appEdtAddress)
    private val appEdtMobile by bind<AppCompatEditText>(R.id.appEdtMobile)

    private var listCountry: MutableList<CountryList> = arrayListOf()
    private var listDistrict: MutableList<DistrictList> = arrayListOf()
    private var countryId: String? = null
    private var districtId: String? = null
    private var districtDeliveryService: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_opsi_pengiriman_delivery)
        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        rlCount = toolBar!!.findViewById(R.id.rlCount)

        appTvTitle!!.text = getString(R.string.toolbar_title_opsi_pengiriman).toUpperCase()
        rlCount!!.visibility = View.INVISIBLE

        presenter!!.apiCall(RestConstant.CALL_API_COUNTRY, null, null)

        appIvDrawer!!.setOnClickListener { activity.finish() }

        findViewById<AppCompatImageView>(R.id.appIvTakeawayUnselect).setOnClickListener {
            AppUtils.startActivity(this, OpsiPengirimanTakeAwayActivity::class.java)
        }

        findViewById<AppCompatButton>(R.id.appBtnDelivery).setOnClickListener {
            var title = appEdtTitle.text.toString()
            var fullName = appEdtFullName.text.toString()
            var address = appEdtAddress.text.toString()
            var mobile = appEdtMobile.text.toString()

            when {
                presenter!!.validation(title, fullName, address, countryId.toString(), districtId.toString(), districtDeliveryService.toString(), mobile) -> {
                    val alPassDataQuestion = ArrayList<DeliveryParcelable>()
                    alPassDataQuestion.add(DeliveryParcelable(title, fullName, address, this.countryId!!, this!!.districtId!!, appTvCountry.text.toString(), appTvDistrict.text.toString(), this.districtDeliveryService!!, mobile, 1))
                    AppUtils.sentParcelsLaunchClear(activity, OrderDeliveryActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
                    //presenter!!.apiCall(this, RestConstant.CALL_API_ORDER_DELIVERY, null, OrderDeliveryRequest(PreferenceUtils.preferenceInstance(this).userId, title, fullName, mobile, address, this!!.countryId!!, this!!.districtId!!))
                }
            }
        }

        findViewById<LinearLayout>(R.id.llCountry).setOnClickListener {
            when {
                listCountry.isNotEmpty() -> {
                    val dialogCountry = SpDialogCountry(this, getStringFromId(R.string.sp_select_country), SpDialogCountry.OnItemClick { `object` ->
                        var selectedCountry = `object` as CountryList
                        appTvCountry.text = selectedCountry.countryName
                        countryId = selectedCountry.countryId

                        districtId = ""
                        districtDeliveryService = ""

                        appTvDistrict.text = getString(R.string.kelurahan)
                        presenter!!.apiCall(RestConstant.CALL_API_DISTRICT, DistrictRequest(selectedCountry.countryId!!), null)

                    }, listCountry)
                    dialogCountry.show()
                }
                else -> AppUtils.showToastById(this, R.string.msg_no_data)
            }
        }

        findViewById<LinearLayout>(R.id.llDistrict).setOnClickListener {
            when {
                listDistrict.isNotEmpty() -> {
                    val dialogDistrict = SpDialogDistrict(this, getStringFromId(R.string.sp_select_country), SpDialogDistrict.OnItemClick { `object` ->
                        var selectedDistrict = `object` as DistrictList
                        appTvDistrict.text = selectedDistrict.stateName
                        districtId = selectedDistrict.stateId
                        districtDeliveryService = selectedDistrict.serviceCharge

                    }, listDistrict)
                    dialogDistrict.show()
                }
                else -> AppUtils.showToastById(this, R.string.msg_no_data)
            }
        }
    }

    override fun createPresenter(): OpsiPengirimanPresenter {
        return OpsiPengirimanPresenter()
    }

    override fun attachView(): OpsiPengirimanView {
        return this
    }

    override fun apiGetCountryResponse(response: CountryResponse) {
        countryId = ""
        listCountry = response.countryList as MutableList<CountryList>
    }

    override fun apiGetDistrictResponse(response: DistrictResponse) {
        listDistrict = response.districtList as MutableList<DistrictList>
    }

    override fun apiPostOrderDeliveryResponse(response: OrderDeliveryResponse) {
        AppUtils.showToast(this, response.response!!.message + "")

        when {
            response.response!!.code == RestConstant.OK_200 -> AppUtils.startActivity(this, OrderDeliveryActivity::class.java)
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }
}
