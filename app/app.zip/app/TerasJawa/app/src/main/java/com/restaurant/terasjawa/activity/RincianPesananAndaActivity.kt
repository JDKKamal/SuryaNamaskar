package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.*
import android.view.View
import android.widget.LinearLayout
import com.restaurant.terasjawa.activity.OpsiPengirimanDeliveryActivity
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.AppConstant
import com.restaurant.constant.RestConstant
import com.restaurant.db.DBQuery
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.RincianPesananAndaAdapter
import com.restaurant.model.api.response.DefaultResponse
import com.restaurant.model.api.response.addtocart.cartlist.CartList
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.presenter.AddToCartPresenter
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.view.AddToCartView
import kotlinx.android.synthetic.main.activity_rincian_pesanan_anda.*

class RincianPesananAndaActivity : SimpleMVPActivity<AddToCartPresenter, AddToCartView>(), AddToCartView, RincianPesananAndaAdapter.ItemListener {
    private var recyclerView: RecyclerView? = null

    private var toolBar: Toolbar? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appTvBadge: AppCompatTextView? = null

    private var llAddToCartList: LinearLayout? = null
    private var appTvTotal: AppCompatTextView? = null
    private var menuIdDelete: String? = null
    private var positionDelete: Int? = null

    private val appBtnTambahPesanan by bind<AppCompatButton>(R.id.appBtnTambahPesanan)
    private lateinit var rincianPesananAndaAdapter: RincianPesananAndaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rincian_pesanan_anda)

        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        appTvBadge = toolBar!!.findViewById(R.id.appTvBadge)
        recyclerView = findViewById(R.id.recyclerView)
        llAddToCartList = findViewById(R.id.llAddToCartList)
        appTvTotal = findViewById(R.id.appTvTotal)

        appTvTitle!!.text = getString(R.string.toolbar_title_rincian_pesanan_anda).toUpperCase()
        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem

        appIvDrawer!!.setOnClickListener { activity.finish() }

        setRecyclerView(recyclerView!!, 0, recyclerViewLinearLayout)

        val param = HashMap<String, String>()
        param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
        presenter!!.apiCall(1, param, RestConstant.CALL_API_ADD_TO_CART_LIST)

        if (hasInternet()) {
            findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
                    presenter!!.apiCall(0, param, RestConstant.CALL_API_ADD_TO_CART_LIST)
                }, 1000)
            }
        }

        findViewById<AppCompatButton>(R.id.appBtnLanjut).setOnClickListener(
                {
                    if (java.lang.Integer.valueOf(PreferenceUtils.preferenceInstance(this).cartItem) > 0) {
                        AppUtils.startActivity(this, OpsiPengirimanDeliveryActivity::class.java)
                    } else {
                        AppUtils.showToast(this, "Cart empty")
                    }
                })

        appBtnTambahPesanan.setOnClickListener(
                {
                    //AppUtils.startActivity(activity(), CategoryActivity::class.java)
                })

        findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)
    }

    override fun createPresenter(): AddToCartPresenter {
        return AddToCartPresenter()
    }

    override fun attachView(): AddToCartView {
        return this
    }

    override fun apiGetAddToCartListResponse(response: CartListResponse) {
        swipeRefreshLayout.isRefreshing = false
        when {
            response.response!!.code == RestConstant.OK_200 -> {
                rincianPesananAndaAdapter = RincianPesananAndaAdapter(activity!!, response.cartList!!)
                rincianPesananAndaAdapter.setOnListener(this)
                recyclerView!!.adapter = rincianPesananAndaAdapter

                appTvBadge!!.text = response.cartList!!.size.toString()
                PreferenceUtils.preferenceInstance(this).cartItem = response.cartList!!.size.toString()

                DrawerActivity.appTvBadge!!.text = response.cartList!!.size.toString()

            }
            else -> {
                DBQuery.with(this).realmDeleteTable()

                var emptyCartList = ArrayList<CartList>()
                rincianPesananAndaAdapter = RincianPesananAndaAdapter(activity, emptyCartList)
                rincianPesananAndaAdapter.setOnListener(this)
                recyclerView!!.adapter = rincianPesananAndaAdapter

                appTvBadge!!.text = AppConstant.DEFAULT_PRICE
                appTvTotal!!.text = AppConstant.DEFAULT_PRICE
                PreferenceUtils.preferenceInstance(this).cartItem = AppConstant.DEFAULT_PRICE
                DrawerActivity.appTvBadge!!.text = AppConstant.DEFAULT_PRICE
            }
        }
    }

    override fun onClickDeleteCartItem(position: Int, cartId: Int, menuId: String, cartName: String) {
        positionDelete = position
        dialogDeleteItem(cartId, menuId, cartName);
    }

    override fun onCartChange(grandTotal: Double, cartItems: CartList, status: Int) {
        appTvTotal!!.text = activity.getString(R.string.total) + grandTotal.toString()

        when (status) {
            1 -> {
                val qtyCal = cartItems.menuQty!!.toDouble()
                val priceCal = cartItems.menuPrice!!.toDouble()

                val param = HashMap<String, String>()
                param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
                param[RestConstant.REST_ID] = cartItems.restId.toString()
                param[RestConstant.MENU_ID] = cartItems.menuId.toString()
                param[RestConstant.MENU_QTY] = cartItems.menuQty.toString()
                param[RestConstant.MENU_PRICE] = (qtyCal * priceCal).toString()

                presenter!!.apiCall(0, param, RestConstant.CALL_API_UPDATE_CART_ITEM)
            }
        }
    }

    override fun onCartChange(grandTotal: Double, cartItem : String) {
        appTvTotal!!.text = activity.getString(R.string.total) + grandTotal.toString()
        PreferenceUtils.preferenceInstance(this).cartItem = cartItem

        appTvBadge!!.text =  PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun apiGetUpdateItemResponse(response: DefaultResponse) {
        when {
            response.response!!.code == RestConstant.OK_200 -> {
            }
            else -> AppUtils.showToast(this, response.response!!.message + "")
        }
    }

    override fun apiGetDeleteItemResponse(response: DefaultResponse) {
        AppUtils.showToast(this, response.response!!.message + "")

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                DBQuery.with(activity()).realmDeleteCategoryId(this.menuIdDelete!!)
                //val param = HashMap<String, String>()
                //param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
                //presenter!!.apiCall(1, param, RestConstant.CALL_API_ADD_TO_CART_LIST)

                rincianPesananAndaAdapter.remove(this.positionDelete!!)
            }
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }

    private fun dialogDeleteItem(cartId: Int, menuId: String, name: String) {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_close, null)
        alertDialog.setView(dialogView)

        val appTvMessage = dialogView.findViewById(R.id.appTvMessage) as AppCompatTextView
        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView

        appTvMessage.text = resources.getString(R.string.dialog_message_delete) + " " + name.toLowerCase() + "?";

        appTvYes.setOnClickListener({
            menuIdDelete = menuId;
            val param = HashMap<String, String>()
            param[RestConstant.PARAM_CART_ID] = cartId.toString()
            presenter!!.apiCall(0, param, RestConstant.CALL_API_DELETE_CART_ITEM)

            alertDialog.dismiss()
        })
        appTvNo.setOnClickListener({ alertDialog.dismiss() })

        alertDialog.show()
    }
}
