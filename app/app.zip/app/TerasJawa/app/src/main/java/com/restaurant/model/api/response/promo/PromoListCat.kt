package com.restaurant.model.api.response.promo

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class PromoListCat {

    @SerializedName("mid")
    @Expose
    var mid: String? = null
    @SerializedName("menu_name")
    @Expose
    var menuName: String? = null
    @SerializedName("menu_info")
    @Expose
    var menuInfo: String? = null
    @SerializedName("menu_price")
    @Expose
    var menuPrice: String? = null
    @SerializedName("special_price")
    @Expose
    var specialPrice: String? = null
    @SerializedName("total_rate")
    @Expose
    var totalRate: String? = null
    @SerializedName("rate_avg")
    @Expose
    var rateAvg: String? = null
    @SerializedName("menu_image")
    @Expose
    var menuImage: String? = null
}
