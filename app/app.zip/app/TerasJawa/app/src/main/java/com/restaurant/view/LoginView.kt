package com.restaurant.view
/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.model.api.response.login.LoginResponse

interface LoginView : BaseView {
    fun apiPostLoginResponse(response: LoginResponse)
    fun apiGetAddToCartListResponse(response: CartListResponse)
}