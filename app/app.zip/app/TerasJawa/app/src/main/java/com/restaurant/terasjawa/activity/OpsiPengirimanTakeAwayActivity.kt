package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.*
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.RelativeLayout
import com.restaurant.baseclass.BaseActivity
import com.restaurant.constant.AppConstant
import com.restaurant.terasjawa.R
import com.restaurant.model.parcelable.DeliveryParcelable
import com.restaurant.utils.AppUtils
import com.restaurant.utils.Validator
import java.text.SimpleDateFormat
import java.util.*

class OpsiPengirimanTakeAwayActivity : BaseActivity(), AdapterView.OnItemSelectedListener {
    private var appIvDrawer: AppCompatImageView? = null
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var rlCount: RelativeLayout? = null

    private val appEdtTitle by bind<AppCompatEditText>(R.id.appEdtTitle)
    private val appEdtFullName by bind<AppCompatEditText>(R.id.appEdtFullName)
    private val appEdtMobile by bind<AppCompatEditText>(R.id.appEdtMobile)
    private val appSpTime by bind<AppCompatSpinner>(R.id.appSpTime)

    private var time: String? = null
    var listCountry: MutableList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_opsi_pengiriman_take_away)

        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        rlCount = toolBar!!.findViewById(R.id.rlCount)

        appTvTitle!!.text = getString(R.string.toolbar_title_opsi_pengiriman).toUpperCase()
        rlCount!!.visibility = View.INVISIBLE
        listCountry.add("Time")

        val aaTime = ArrayAdapter(this,R.layout.itemview_spinner_select , listCountry)
        aaTime.setDropDownViewResource(R.layout.itemview_spinner_default)
        appSpTime.adapter = aaTime

        //LISTENER
        appSpTime.onItemSelectedListener = this

        appIvDrawer!!.setOnClickListener { activity.finish() }

        findViewById<AppCompatImageView>(R.id.appIvUnDeliverySelect).setOnClickListener(
                {
                    finish()
                })

        findViewById<AppCompatButton>(R.id.appBtnTakeAway).setOnClickListener(
                {
                    var title = appEdtTitle.text.toString()
                    var fullName = appEdtFullName.text.toString()
                    var mobile = appEdtMobile.text.toString()

                    if (validation(title, fullName, mobile)) {
                        if (!time.equals("Time")) {
                            val alPassDataQuestion = ArrayList<DeliveryParcelable>()
                            alPassDataQuestion.add(DeliveryParcelable(title, fullName, this.time!!, "", "", "", "", "", mobile, 0))
                            AppUtils.sentParcelsLaunchClear(activity, OrderDeliveryActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
                        } else {
                            AppUtils.showToast(this, "Pilih waktu" + "")
                        }
                    }
                })

        val sdf = SimpleDateFormat("HH:mm:aa")
        val currentDateTime = sdf.format(Date())

        val splitTime = currentDateTime.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()

        if (Integer.valueOf(splitTime[0]) in 10..21) {
            for (i in Integer.valueOf(splitTime[0])..20) {
                if (i < 22 && i >= 10) {
                    listCountry.add(i.toString() + ":" + splitTime[1])
                }
            }
        } else {
            println("eResto is close")
        }
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

        time = when {
            listCountry[position] != "Time" -> listCountry[position]
            else -> "Time"
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>) {

    }

    private fun validation(title: String, fullName: String, mobile: String): Boolean {
        return when {
            Validator.isEmpty(title) -> {
                AppUtils.showToast(this, activity.getString(R.string.msg_empty_title_order))
                false
            }
            Validator.isEmpty(fullName) -> {
                AppUtils.showToast(this, activity.getString(R.string.msg_empty_full_name_order))
                false
            }
            Validator.isEmpty(mobile) -> {
                AppUtils.showToast(this, activity.getString(R.string.msg_empty_mobile))
                false
            }

            else -> true
        }
    }
}
