package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.menu.MenuResponse
import com.restaurant.view.MenuView

class MenuPresenter : BasePresenter<MenuView>() {
    private fun callApiGetMenu(swipeRefreshStatus: Int) {
        appInteractor.apiGetMenu(view!!.activity(), object : InterActorCallback<MenuResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: MenuResponse) {
                view!!.apiPostMenuResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    fun apiCall(swipeRefreshStatus: Int, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_MENU -> callApiGetMenu(swipeRefreshStatus)
            }
        }
    }
}
