package com.restaurant.view

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.DefaultResponse

interface AddToCartView : BaseView
{
    fun apiGetAddToCartListResponse(response: CartListResponse)
    fun apiGetDeleteItemResponse(response: DefaultResponse)
    fun apiGetUpdateItemResponse(response: DefaultResponse)

}
