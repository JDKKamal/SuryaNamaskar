package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.DefaultResponse
import com.restaurant.model.api.response.comment.commentlist.CommentResponse
import com.restaurant.model.api.response.comment.like.LikeResponse
import com.restaurant.model.api.response.comment.logincomment.LoginCommentResponse
import com.restaurant.model.api.response.comment.subcomment.SubCommentResponse
import com.restaurant.model.api.response.comment.unlike.UnLikeResponse
import com.restaurant.utils.AppUtils
import com.restaurant.view.DetailView
import com.restaurant.utils.Validator
import kotlin.collections.HashMap

class DetailPresenter : BasePresenter<DetailView>() {
    private fun callApiGetAdToCart(params: HashMap<String, String>) {
        appInteractor.apiGetAddToCart(view!!.activity(), params, object : InterActorCallback<DefaultResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: DefaultResponse) {
                view!!.apiGetAddToCartResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    private fun callApiGetLoginComment(params: HashMap<String, String>) {
        appInteractor.apiGetLoginComment(view!!.activity(), params, object : InterActorCallback<LoginCommentResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: LoginCommentResponse) {
                view!!.apiGetLoginCommentResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    private fun callApiPostCommentList(params: HashMap<String, String>) {
        appInteractor.apiPostCommentList(view!!.activity(), params, object : InterActorCallback<CommentResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: CommentResponse) {
                view!!.apiPostCommentListResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    private fun callApiPostSubComment(params: HashMap<String, String>) {
        appInteractor.apiPostSubComment(view!!.activity(), params, object : InterActorCallback<SubCommentResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: SubCommentResponse) {
                view!!.apiPostSubCommentResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    private fun callApiPostLike(params: HashMap<String, String>) {
        appInteractor.apiPostLike(view!!.activity(), params, object : InterActorCallback<LikeResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: LikeResponse) {
                view!!.apiPostLikeResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    private fun callApiPostUnLike(params: HashMap<String, String>) {
        appInteractor.apiPostUnLike(view!!.activity(), params, object : InterActorCallback<UnLikeResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: UnLikeResponse) {
                view!!.apiPostUnLikeResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }


    internal fun apiCall(params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() ->
                when (apiNo) {
                    RestConstant.CALL_API_ADD_TO_CART -> callApiGetAdToCart(params)

                    RestConstant.CALL_API_COMMENT_LOGIN -> callApiGetLoginComment(params)

                    RestConstant.CALL_API_COMMENT_LIST -> callApiPostCommentList(params)

                    RestConstant.CALL_API_SUB_COMMENT -> callApiPostSubComment(params)

                    RestConstant.CALL_API_LIKE -> callApiPostLike(params)

                    RestConstant.CALL_API_UNLIKE -> callApiPostUnLike(params)
                }
        }
    }

    internal fun validationComment(comment: String): Boolean {
        return when {
            Validator.isEmpty(comment) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_comment))
                false
            }
            else -> true
        }
    }
}
