package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313

   https://github.com/antoniolg/kotlin-android-training/blob/master/app/src/main/java/com/antonioleiva/kotlinandroidtraining/LoginRequest.kt
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.request.LoginRequest
import com.restaurant.model.api.response.login.LoginResponse
import com.restaurant.utils.AppUtils
import com.restaurant.view.LoginView
import com.restaurant.utils.Validator
import kotlin.collections.HashMap

class LoginPresenter : BasePresenter<LoginView>() {
    fun callApiPostLogin(params: HashMap<String, String>) {
        appInteractor.apiPostLogin(view!!.activity(), params, object : InterActorCallback<LoginResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: LoginResponse) {
                view!!.apiPostLoginResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(apiNo: Int, loginRequest: LoginRequest) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_LOGIN -> {
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_EMAIL to loginRequest.email!!.toLowerCase(),
                            RestConstant.PARAM_PASSWORD to loginRequest.password!!
                    )
                    callApiPostLogin(param)
                }
                RestConstant.CALL_LOGIN_SOCIAL -> {
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_EMAIL to loginRequest.email!!.toLowerCase()
                    )
                    callApiPostLogin(param)
                }
            }
        }
    }

    //TODO VALIDATION
    fun validation(email: String, password: String) {
        return when {
            Validator.isEmpty(email) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_email))
            }
            !Validator.isRegexValidator(email, Validator.patternEmail) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_valid_email))
            }
            Validator.isEmpty(password) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_password))
            }
            else -> apiCall(RestConstant.CALL_API_LOGIN, LoginRequest(email, password))
        }
    }
    //FINISH VALIDATION
}
