package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.RelativeLayout

import com.restaurant.baseclass.BaseActivity
import com.restaurant.terasjawa.R

import butterknife.BindView

class PesananAndaActivity : BaseActivity() {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var rlCount: RelativeLayout? = null

    @BindView(R.id.recyclerView)
    internal var recyclerView: RecyclerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_persanan_anda)

        //bindViews();
        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        rlCount = toolBar!!.findViewById(R.id.rlCount)

        appTvTitle!!.text = "PESANAN ANDA"
        rlCount!!.visibility = View.INVISIBLE

        appIvDrawer!!.setOnClickListener { activity.finish() }

        //setRecyclerView(recyclerView, 0, recyclerViewLinearLayout);

        //recyclerView.setAdapter(new PesananAndaAdapter(this, listPesananAnda()));
    }

}
