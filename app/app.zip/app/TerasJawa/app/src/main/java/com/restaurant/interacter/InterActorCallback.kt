package com.restaurant.interacter

import com.restaurant.model.api.Response

/*
   Developed BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

interface InterActorCallback<T> {

    fun onStart()

    fun onResponse(response: T)

    fun onFinish()

    fun onError(message: String)
}
