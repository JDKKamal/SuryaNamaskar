package com.restaurant.model.api.response.profile

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ProfileResponse  : Response(){
    @SerializedName("update_user_profile")
    @Expose
    var updateUserProfile: UpdateUserProfile? = null

}