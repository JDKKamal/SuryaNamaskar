package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.menucategory.MenuCategoryResponse
import com.restaurant.view.MenuCategoryView

class MenuCategoryPresenter : BasePresenter<MenuCategoryView>() {
    private fun callApiGetMenu(swipeRefreshStatus: Int, params: HashMap<String, String>) {
        appInteractor.apiGetMenuCategory(view!!.activity(), params, object : InterActorCallback<MenuCategoryResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: MenuCategoryResponse) {
                view!!.apiPostMenuCategoryResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(swipeRefreshStatus: Int, params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_MENU_CATEGORY -> callApiGetMenu(swipeRefreshStatus, params)
            }
        }
    }
}
