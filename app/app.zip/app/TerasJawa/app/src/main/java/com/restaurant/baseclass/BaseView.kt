package com.restaurant.baseclass

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Activity

interface BaseView {
    val defaultParameter: Map<String, String>
    fun activity(): Activity
    fun hasInternet(): Boolean
    fun showProgressDialog(show: Boolean)
    //void onSuccess(T response);
    //void onSuccess(List<T> response);
    fun onFailure(message: String)
}