package com.restaurant.view

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.forgotpassword.ForgotPasswordResponse
import com.restaurant.model.api.response.login.LoginResponse

interface ForgotPasswordView : BaseView {
    fun apiPostForgotPasswordResponse(response: ForgotPasswordResponse)
}