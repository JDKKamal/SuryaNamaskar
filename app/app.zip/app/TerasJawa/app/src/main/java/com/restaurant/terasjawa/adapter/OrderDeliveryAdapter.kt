package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.terasjawa.R

import com.restaurant.constant.RestConstant
import com.restaurant.model.api.response.addtocart.cartlist.CartList
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView

class OrderDeliveryAdapter(private val context: Context, private val profiles: List<CartList>) : BaseRecyclerView<CartList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): CartList {
        return profiles[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<CartList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_order_delivery, parent, false))
    }

    override fun getItemCount(): Int {
        return profiles.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<CartList>(itemView) {
        var appIvMenuIcon: CircleImageView? = null
        var appTvTitle: AppCompatTextView? = null
        var appTvQuantity: AppCompatTextView? = null
        var appTvPrice: AppCompatTextView? = null

        init {
            appIvMenuIcon = itemView.findViewById(R.id.appIvMenuIcon)
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appTvQuantity = itemView.findViewById(R.id.appTvQuantity)
            appTvPrice = itemView.findViewById(R.id.appTvPrice)
        }

        override fun populateItem(t: CartList) {
            AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + t.menuImage, this!!.appIvMenuIcon!!)
            appTvTitle!!.text = t.menuName
            appTvQuantity!!.text = t.menuQty

            val qtyCal = profiles[layoutPosition].menuQty!!.toDouble()
            val priceCal = profiles[layoutPosition].menuPrice!!.toDouble()
            appTvPrice!!.text = (qtyCal * priceCal).toString()

            updateTotal(layoutPosition)
        }
    }

    fun updateTotal(position : Int) {
        var grandTotal = 0.00
        profiles.forEach({ product ->
            val qty = product.menuQty!!.toDouble()
            val price = product.menuPrice!!.toDouble()
            grandTotal += qty * price
        })
        listener!!.onCartChange(grandTotal, profiles[position])

    }

    interface ItemListener {
        fun onCartChange(grandTotal: Double, cartItems: CartList)
    }
}
