package com.restaurant.model

class ModelDrawer {
    var icon: Int = 0
    var title: String? = null

    constructor() {}

    constructor(icon: Int, title: String) {
        this.icon = icon
        this.title = title
    }
}