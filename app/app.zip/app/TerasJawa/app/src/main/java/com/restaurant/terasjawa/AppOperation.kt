package com.restaurant.terasjawa

import android.app.Activity
import android.content.Intent
import com.restaurant.constant.AppConstant
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterHelper
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.model.api.response.login.LoginResponse
import com.restaurant.model.api.response.menu.MenuList
import com.restaurant.model.api.response.menucategory.MenuCategoryList
import com.restaurant.model.parcelable.CategoryParcelable
import com.restaurant.model.parcelable.MenuParcelable
import com.restaurant.terasjawa.activity.*
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginHelper
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginHelper
import java.util.*


sealed class AppOperation
class Finish(var activity: Activity) : AppOperation()
class LogoutBack(var activity: Activity) : AppOperation()
class ForgotPassword(var activity: Activity) : AppOperation()
class SignUpIntent(var activity: Activity) : AppOperation()
class FacebookLogin(var activity: Activity, var facebookLoginHelper: FacebookLoginHelper) : AppOperation()
class TwitterLogin(var twitterHelper: TwitterHelper) : AppOperation()
class GooglePlusLogin(var activity: Activity, var googleLoginHelper: GoogleLoginHelper) : AppOperation()
class Login(var activity: Activity, var response: LoginResponse, var loginStatus: Int) : AppOperation()
class DrawerIntentLogin(var activity: Activity, var response: CartListResponse) : AppOperation()
class SignUpTerms(var activity: Activity) : AppOperation()

class IntentDrawerActivity(var activity: Activity) : AppOperation()
class MenuClick(var activity: Activity, var modelMenu: MenuList, var alPassDataQuestion: ArrayList<MenuParcelable>) : AppOperation()
class CategoryClick(var activity: Activity, var parcelableTopic: List<MenuParcelable>?, var menuCategoryList: MenuCategoryList, var listCategoryPassData: ArrayList<CategoryParcelable>) : AppOperation()
class ActivityResultSocialLogin(var googleLoginHelper: GoogleLoginHelper, var facebookLoginHelper: FacebookLoginHelper, var twitterHelper: TwitterHelper, var requestCode: Int, var resultCode: Int, var data: Intent) : AppOperation()

fun execute(op: AppOperation) = when (op) {
    is Finish -> op.activity.finish()
    is LogoutBack -> {
        PreferenceUtils.preferenceInstance(op.activity).isLogout == 0
        op.activity.startActivity(Intent(op.activity, SliderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
        op.activity.finish()
    }
    is ForgotPassword -> AppUtils.startActivity(op.activity, ForgotPasswordActivity::class.java)
    is SignUpIntent -> AppUtils.startActivity(op.activity, SignUpActivity::class.java)
    is FacebookLogin -> op.facebookLoginHelper.performSignIn(op.activity)
    is TwitterLogin -> op.twitterHelper.performSignIn()
    is GooglePlusLogin -> {
        op.googleLoginHelper.performSignOut()
        op.googleLoginHelper.performSignIn(op.activity)
    }
    is Login -> {
        PreferenceUtils.preferenceInstance(op.activity).isLogin = true
        PreferenceUtils.preferenceInstance(op.activity).loginStatus = op.loginStatus
        PreferenceUtils.preferenceInstance(op.activity).isLogout = 1
        PreferenceUtils.preferenceInstance(op.activity).userId = op.response.loginDetail!!.userId!!
        PreferenceUtils.preferenceInstance(op.activity).userName = op.response.loginDetail!!.name!!
        PreferenceUtils.preferenceInstance(op.activity).email = op.response.loginDetail!!.email!!
        PreferenceUtils.preferenceInstance(op.activity).mobile = op.response.loginDetail!!.phone!!
        PreferenceUtils.preferenceInstance(op.activity).promoItem = op.response.loginDetail!!.promoRowcount!!

        PreferenceUtils.preferenceInstance(op.activity).profilepicture = op.response.loginDetail!!.userImage!!

        if (op.response.loginDetail!!.cartItems!! > 0) {
            PreferenceUtils.preferenceInstance(op.activity).cartItem = op.response.loginDetail!!.cartItems.toString()
        } else {
            PreferenceUtils.preferenceInstance(op.activity).cartItem = "00"
        }
    }
    is DrawerIntentLogin -> {
        AppUtils.startActivity(op.activity, DrawerActivity::class.java)
        op.activity.finish()
    }

    is SignUpTerms -> AppUtils.startActivity(op.activity, SignUpTermsActivity::class.java)

    is IntentDrawerActivity -> {
        AppUtils.startActivity(op.activity, DrawerActivity::class.java)
        op.activity.finish()
    }
    is MenuClick -> {
        op.alPassDataQuestion.add(MenuParcelable(op.modelMenu.cid!!, op.modelMenu.categoryName!!, op.modelMenu.categoryImage!!))
        AppUtils.sentParcelsLaunchClear(op.activity, CategoryActivity::class.java, AppConstant.BUNDLE_PARCELABLE, op.alPassDataQuestion, 1)
    }
    is CategoryClick -> {
        op.listCategoryPassData.add(
                CategoryParcelable(op.parcelableTopic!![0].cid,
                        op.menuCategoryList.menuName!!, //parcelableTopic!![0].categoryName
                        op.menuCategoryList.mid!!,
                        op.menuCategoryList.menuName!!,
                        op.menuCategoryList.menuInfo!!,
                        op.menuCategoryList.menuImage!!,
                        op.menuCategoryList.totalRate!!,
                        op.menuCategoryList.rateAvg!!,
                        op.menuCategoryList.menuPrice!!
                ))
        AppUtils.sentParcelsLaunchClear(op.activity, DetailActivity::class.java, AppConstant.BUNDLE_PARCELABLE, op.listCategoryPassData, 1)
    }
    is ActivityResultSocialLogin -> {
        op.facebookLoginHelper.onActivityResult(op.requestCode, op.resultCode, op.data)
        op.googleLoginHelper.onActivityResult(op.requestCode, op.data)
        op.twitterHelper.onActivityResult(op.requestCode, op.resultCode, op.data)
    }
}
