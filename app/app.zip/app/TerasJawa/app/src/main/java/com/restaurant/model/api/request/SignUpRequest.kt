package com.restaurant.model.api.request

class SignUpRequest(var name: String? = null, var email: String? = null, var mobile: String? = null, var password: String? = null) {
}
