package com.restaurant.model.api.response.menu

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuList {

    @SerializedName("cid")
    @Expose
    var cid: String? = null
    @SerializedName("category_name")
    @Expose
    var categoryName: String? = null
    @SerializedName("category_image")
    @Expose
    var categoryImage: String? = null
    @SerializedName("total_rate")
    @Expose
    var totalRate: String? = null
    @SerializedName("rate_avg")
    @Expose
    var rateAvg: String? = null

}