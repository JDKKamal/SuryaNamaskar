package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY KAMLESH LAKHANI
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatCheckBox
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.text.Html.fromHtml
import android.view.View
import android.widget.LinearLayout
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginHelper
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginListener
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginModel
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginHelper
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginListener
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginModel
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.RestConstant
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterHelper
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterListener
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterUser
import com.restaurant.db.DBQuery
import com.restaurant.model.api.request.SignUpRequest
import com.restaurant.model.api.response.signup.SignUpResponse
import com.restaurant.model.api.response.signup.facebook.FacebookResponse
import com.restaurant.model.api.response.signup.gmail.GmailSignUpResponse
import com.restaurant.model.api.response.signup.twitter.TwitterSignUpResponse
import com.restaurant.presenter.SignUpPresenter
import com.restaurant.terasjawa.*
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.utils.logInfo
import com.restaurant.view.SignUpView
import kotlinx.android.synthetic.main.activity_signup.*

class SignUpActivity : SimpleMVPActivity<SignUpPresenter, SignUpView>(), SignUpView, FacebookLoginListener, GoogleLoginListener, TwitterListener, View.OnClickListener {
    private var facebookLoginHelper: FacebookLoginHelper? = null
    private var googleLoginHelper: GoogleLoginHelper? = null
    private var twitterHelper: TwitterHelper? = null

    private val llBack by bind<LinearLayout>(R.id.llBack)
    private val appBtnSignUp by bind<AppCompatButton>(R.id.appBtnSignUp)
    private val appCBTermsCondition by bind<AppCompatCheckBox>(R.id.appCBTermsCondition)
    private val appIvSocialFacebook by bind<AppCompatImageView>(R.id.appIvSocialFacebook)
    private val appIvSocialTwitter by bind<AppCompatImageView>(R.id.appIvSocialTwitter)
    private val appIvSocialGooglePlus by bind<AppCompatImageView>(R.id.appIvSocialGooglePlus)
    private val appTvTerms by bind<AppCompatTextView>(R.id.appTvTerms)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        hideSoftKeyboard()

        //TODO SOCIAL LOGIN
        facebookLoginHelper = FacebookLoginHelper(this)
        googleLoginHelper = GoogleLoginHelper(this, this, RestConstant.SOCIAL_GOOGLE_ID)
        twitterHelper = TwitterHelper(R.string.twitter_api_key, R.string.twitter_secrate_key, this, this)

        llBack.setOnClickListener(this)
        appBtnSignUp.setOnClickListener(this)
        appIvSocialFacebook.setOnClickListener(this)
        appIvSocialTwitter.setOnClickListener(this)
        appIvSocialGooglePlus.setOnClickListener(this)
        appTvTerms.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.llBack -> {
                var intentOperation = Finish(activity)
                execute(intentOperation)
            }

            R.id.appBtnSignUp -> {
                val name = appEdtName.text.toString()
                val email = appEdtEmail.text.toString()
                val mobile = appEdtMobile.text.toString()
                val password = appEdtPassword.text.toString()

                presenter!!.validation(name, email, mobile, password, appCBTermsCondition)
            }

            R.id.appIvSocialFacebook -> {
                var intentOperation = facebookLoginHelper?.let { FacebookLogin(activity, it) }
                execute(intentOperation!!)
            }

            R.id.appIvSocialTwitter -> {
                var intentOperation = twitterHelper?.let { TwitterLogin(it) }
                execute(intentOperation!!)
            }

            R.id.appIvSocialGooglePlus -> {
                var intentOperation = googleLoginHelper?.let { GooglePlusLogin(activity, it) }
                execute(intentOperation!!)
            }

            R.id.appTvTerms -> {
                if (isInternet) {
                    var intentOperation = SignUpTerms(activity)
                    execute(intentOperation)
                }
            }
        }
    }

    override fun createPresenter(): SignUpPresenter {
        return SignUpPresenter()
    }

    override fun attachView(): SignUpView {
        return this
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        var intentOperation = ActivityResultSocialLogin(googleLoginHelper!!, facebookLoginHelper!!, twitterHelper!!, requestCode, resultCode, data)
        execute(intentOperation)
    }

    override fun onFbSignInFail(errorMessage: String) {
        //AppUtils.showToast(this, errorMessage + "")
    }

    override fun onFbSignInSuccess(facebookLoginModel: FacebookLoginModel) {
        val name = facebookLoginModel.name
        val email = facebookLoginModel.email
        val mobile = ""
        val facebookId = facebookLoginModel.id

        presenter!!.apiCall(RestConstant.CALL_API_FACEBOOK_REGISTER, SignUpRequest(name!!, email!!, mobile, facebookId!!))
    }

    override fun onFBSignOut() {

    }

    override fun onGoogleAuthSignIn(googleLoginModel: GoogleLoginModel) {
        val name = googleLoginModel.name
        val email = googleLoginModel.email
        val mobile = ""
        val googlePlusId = googleLoginModel.id

        presenter!!.apiCall(RestConstant.CALL_API_GOOGLE_PLUS_REGISTER, SignUpRequest(name!!, email!!, mobile, googlePlusId!!))
    }

    override fun onGoogleAuthSignInFailed(errorMessage: String) {
    }

    override fun onGoogleAuthSignOut() {
    }

    override fun onTwitterError() {
    }

    override fun onTwitterSignIn(userId: String, userName: String) {
        logInfo(getToJsonClass(userId + userName))
    }

    override fun onTwitterProfileReceived(twitterUser: TwitterUser) {
        logInfo(getToJsonClass(twitterUser))

        val name = twitterUser.name
        val email = twitterUser.email
        val mobile = ""
        val twitterId = twitterUser.id

        presenter!!.apiCall(RestConstant.CALL_API_TWITTER_REGISTER, SignUpRequest(name!!, email!!, mobile, twitterId.toString()))
    }

    override fun apiPostSignUpResponse(response: SignUpResponse) {
        AppUtils.showToast(this, response.response!!.message + "")

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                var simpleSignUp = response.signUpDetail
                signUpRedirect(simpleSignUp!!.userId!!, simpleSignUp.name!!, simpleSignUp.email!!, simpleSignUp.phone!!, RestConstant.LOGIN_SIMPLE_STATUS)
            }
            else -> appEdiTextNullSet(R.id.appEdtPassword)
        }
    }

    override fun apiPostFacebookSignUpResponse(response: FacebookResponse) {
        AppUtils.showToast(this, response.response!!.message + "")

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                var facebookRegister = response.facebookRegister

                signUpRedirect(facebookRegister!!.userId!!, facebookRegister.name!!, facebookRegister.email!!, "", RestConstant.LOGIN_FACEBOOK_STATUS)
            }
        }
    }

    override fun apiPostGooglePlusSignUpResponse(response: GmailSignUpResponse) {
        AppUtils.showToast(this,response.response!!.message + "")

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                var facebookRegister = response.gplusRegister

                signUpRedirect(facebookRegister!!.userId!!, facebookRegister.name!!, facebookRegister.email!!, "", RestConstant.LOGIN_GOOGLE_PLUS_STATUS)
            }
        }
    }

    override fun apiPostTwitterPlusSignUpResponse(response: TwitterSignUpResponse) {
        AppUtils.showToast(this, response.response!!.message + "")

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                var facebookRegister = response.twiterRegister

                signUpRedirect(facebookRegister!!.userId!!, facebookRegister.name!!, facebookRegister.email!!, "", RestConstant.LOGIN_TWITTER_STATUS)
            }
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }

    private fun signUpRedirect(userID: String, userName: String, email: String, mobile: String, signUpStatus: Int) {
        DBQuery.with(this).realmDeleteTable()
        PreferenceUtils.preferenceInstance(this).isLogout = 1

        PreferenceUtils.preferenceInstance(this).loginStatus = signUpStatus
        PreferenceUtils.preferenceInstance(this).isLogin = true
        PreferenceUtils.preferenceInstance(this).userId = userID
        PreferenceUtils.preferenceInstance(this).userName = userName
        PreferenceUtils.preferenceInstance(this).email = email
        PreferenceUtils.preferenceInstance(this).mobile = mobile
        PreferenceUtils.preferenceInstance(this).cartItem = "00"

        var intentOperation = IntentDrawerActivity(activity)
        execute(intentOperation)
    }

    override fun onBackPressed() {
        var intentOperation = Finish(activity)
        execute(intentOperation)
    }
}
