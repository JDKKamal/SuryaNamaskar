package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.content.Context
import android.os.Bundle
import android.support.v4.app.FragmentManager
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.RelativeLayout
import com.restaurant.baseclass.BaseActivity
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.fragment.FragmentDrawer
import com.restaurant.terasjawa.fragment.MenuFragment
import com.restaurant.model.event.ProfileEvent
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import com.bytotech.model.event.PromoEvent
import java.util.*

class DrawerActivity : BaseActivity(), View.OnClickListener, FragmentDrawer.FragmentDrawerListener {

    private var toolBar: Toolbar? = null
    private var drawer: DrawerLayout? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var rlCount: RelativeLayout? = null

    private var fm: FragmentManager? = null
    private var drawerFragment: FragmentDrawer? = null

    companion object {
        var appTvBadge: AppCompatTextView? = null
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawer)

        fm = supportFragmentManager
        EventBus.getDefault().register(this)

        drawer = findViewById(R.id.drawer_layout)

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        rlCount = toolBar!!.findViewById(R.id.rlCount)
        appTvBadge = toolBar!!.findViewById(R.id.appTvBadge)

        appTvTitle!!.text = getString(R.string.toolbar_title_drawer)
        appIvDrawer!!.setImageResource(R.mipmap.arrow_drawer)

        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem

        rlCount!!.setOnClickListener {
            if (java.lang.Integer.valueOf(PreferenceUtils.preferenceInstance(this).cartItem) > 0) {
                AppUtils.startActivity(this, RincianPesananAndaActivity::class.java)
            } else {
                AppUtils.showToast(this, "Cart empty")
            }
        }

        drawerFragment = supportFragmentManager.findFragmentById(R.id.fragment_navigation_drawer) as FragmentDrawer
        drawerFragment!!.setUp(R.id.fragment_navigation_drawer, findViewById(R.id.drawer_layout))
        drawerFragment!!.setDrawerListener(this)

        val fragmentTransaction = fm!!.beginTransaction()
        fragmentTransaction.replace(R.id.fragment, MenuFragment())
        fragmentTransaction.commit()

        appIvDrawer!!.setOnClickListener { drawer!!.openDrawer(GravityCompat.START) }

        /*
        startService(Intent(this, PromoCountService::class.java))
        val cal = Calendar.getInstance()
        val intent = Intent(this, PromoCountService::class.java)
        val pintent = PendingIntent.getService(this, 0, intent, 0)
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), (60 * 1000).toLong(), pintent)
        */
    }

    override fun onResume() {
        super.onResume()
        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun onBackPressed() {
        appExist()
    }

    private fun drawerClose() {
        drawer!!.closeDrawer(GravityCompat.START)
    }

    @Subscribe
    fun onEvent(event: ProfileEvent) {
        AppUtils.glideSetAppImageView(activity, event.userProfile, FragmentDrawer.appIvProfile!!)
    }

    @Subscribe
    fun onEvent(event: PromoEvent) {
        AppUtils.glideSetAppImageView(this.activity!!, event.promoCount, FragmentDrawer.appIvProfile!!)
    }

    override fun onClick(view: View) {
        when (view.id) {

        }
    }

    override fun onDrawerItemSelected(view: View, position: Int) {
        drawerMenuClick(position)
        drawerClose()
    }

    private fun drawerMenuClick(id: Int) {
        when (id) {
            0 -> {

            }

            1 -> {
                AppUtils.startActivity(this, RincianPesananAndaActivity::class.java)
            }

            2 -> {
                AppUtils.startActivity(this, PromoActivity::class.java)
            }
        }
    }
}
