package com.restaurant.model.parcelable

import android.os.Parcel
import android.os.Parcelable

class DeliveryParcelable(
        val title: String,
        val fullName: String,
        val address: String,
        val countryId: String,
        val districtId: String,
        val countryName: String,
        val districtName: String,
        val deliveryService: String,
        val mobile: String,
        val status: Int
) : Parcelable {

    constructor(source: Parcel) :
            this(
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readString(),
                    source.readInt())

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(this.title)
        dest?.writeString(this.fullName)
        dest?.writeString(this.address)
        dest?.writeString(this.countryId)
        dest?.writeString(this.districtId)
        dest?.writeString(this.countryName)
        dest?.writeString(this.districtName)
        dest?.writeString(this.deliveryService)
        dest?.writeString(this.mobile)
        dest?.writeInt(this.status)
    }

    companion object {
        @JvmField
        final val CREATOR: Parcelable.Creator<DeliveryParcelable> = object : Parcelable.Creator<DeliveryParcelable> {
            override fun createFromParcel(source: Parcel): DeliveryParcelable {
                return DeliveryParcelable(source)
            }

            override fun newArray(size: Int): Array<DeliveryParcelable?> {
                return arrayOfNulls(size)
            }
        }
    }
}
