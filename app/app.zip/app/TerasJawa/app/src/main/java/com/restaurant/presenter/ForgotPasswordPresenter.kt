package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.request.ForgotPasswordRequest
import com.restaurant.model.api.response.forgotpassword.ForgotPasswordResponse
import com.restaurant.utils.AppUtils
import com.restaurant.view.ForgotPasswordView
import com.restaurant.utils.Validator
import kotlin.collections.HashMap

class ForgotPasswordPresenter : BasePresenter<ForgotPasswordView>() {
    private fun callApiPostForgotPassword(params: HashMap<String, String>) {
        appInteractor.apiPostForgotPassword(view!!.activity(), params, object : InterActorCallback<ForgotPasswordResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: ForgotPasswordResponse) {
                view!!.apiPostForgotPasswordResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    fun apiCall(apiNo: Int, forgotPasswordRequest: ForgotPasswordRequest) {
        when {
            hasInternet() ->
                when (apiNo) {
                RestConstant.CALL_API_FORGOTPASSWORD -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_EMAIL] = forgotPasswordRequest.email!!.toLowerCase()
                    callApiPostForgotPassword(param)
                }
            }
        }
    }

    //TODO VALIDATION
    fun validation(email: String) {
        return when {
            Validator.isEmpty(email) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_empty_email))
            }
            !Validator.isRegexValidator(email, Validator.patternEmail) -> {
                AppUtils.showToast(view!!.activity(), view!!.activity().getString(R.string.msg_valid_email))
            }
            else -> apiCall(RestConstant.CALL_API_FORGOTPASSWORD, ForgotPasswordRequest(email))
        }
    }
    //FINISH VALIDATION
}
