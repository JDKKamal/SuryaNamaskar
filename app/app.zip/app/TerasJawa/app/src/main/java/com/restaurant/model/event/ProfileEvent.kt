package com.restaurant.model.event

class ProfileEvent(val userProfile: String)
