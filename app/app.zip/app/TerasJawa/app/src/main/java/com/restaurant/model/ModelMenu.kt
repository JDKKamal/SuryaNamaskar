package com.restaurant.model

class ModelMenu(var menuicon: Int, var id: String?, var title: String?, var ratting: Double)