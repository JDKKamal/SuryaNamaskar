package com.restaurant.model.api.response.profile

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UpdateUserProfile {

    @SerializedName("user_id")
    @Expose
    var userId: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("email")
    @Expose
    var email: String? = null
    @SerializedName("phone")
    @Expose
    var phone: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("user_image")
    @Expose
    var userImage: String? = null
    @SerializedName("msg")
    @Expose
    var msg: String? = null
    @SerializedName("success")
    @Expose
    var success: String? = null

}