package com.restaurant.view

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.signup.SignUpResponse
import com.restaurant.model.api.response.signup.facebook.FacebookResponse
import com.restaurant.model.api.response.signup.gmail.GmailSignUpResponse
import com.restaurant.model.api.response.signup.twitter.TwitterSignUpResponse

interface SignUpView : BaseView {
    fun apiPostSignUpResponse(response: SignUpResponse)
    fun apiPostFacebookSignUpResponse(response: FacebookResponse)
    fun apiPostGooglePlusSignUpResponse(response: GmailSignUpResponse)
    fun apiPostTwitterPlusSignUpResponse(response: TwitterSignUpResponse)
}