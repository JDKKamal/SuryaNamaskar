package com.restaurant.terasjawa.adapter;

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import com.restaurant.customviews.recyclerview.BaseRecyclerView;
import com.restaurant.customviews.recyclerview.BaseViewHolder;
import com.restaurant.terasjawa.R;
import com.restaurant.model.ModelOrderStatus;

public class PesananAndaAdapter extends BaseRecyclerView<ModelOrderStatus> {

    private LayoutInflater inflater;
    private List<ModelOrderStatus> profiles;

    public PesananAndaAdapter(Context context, List<ModelOrderStatus> profiles) {
        this.inflater = LayoutInflater.from(context);
        this.profiles = profiles;
    }

    @Override
    protected ModelOrderStatus getItem(int position) {
        return profiles.get(position);
    }

    @Override
    public BaseViewHolder<ModelOrderStatus> onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(inflater.inflate(R.layout.itemview_pesanan_anda, parent, false));
    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    class ViewHolder extends BaseViewHolder<ModelOrderStatus> {
        AppCompatTextView appTvId;
        AppCompatTextView appTvStatus;
        AppCompatTextView appTvTotal;
        AppCompatTextView appTvTime;

        AppCompatImageView appIvProfile;
        AppCompatImageView appIvOrder;

        public ViewHolder(View itemView) {
            super(itemView);
        }

        @Override
        public void populateItem(ModelOrderStatus profile) {
            /*appTvId.setText("Order id - " + profile.getId() + "");
            appTvStatus.setText("(" + profile.getOrderstatus() + ")");
            appTvTotal.setText("Total Persanan - " + profile.getTotal() + "");
            appTvTime.setText(profile.getTime() + "");

            appIvProfile.setBackgroundResource(profile.getProfile());
            appIvOrder.setBackgroundResource(profile.getOrder());*/
        }
    }
}
