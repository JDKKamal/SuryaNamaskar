package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v7.widget.AppCompatButton
import android.util.DisplayMetrics
import com.bikomobile.circleindicatorpager.CircleIndicatorPager
import com.google.gson.Gson
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.RestConstant
import com.restaurant.model.api.Response
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.CarouselPagerAdapter
import com.restaurant.model.api.response.slider.SliderList
import com.restaurant.model.api.response.slider.SliderResponse
import com.restaurant.presenter.SliderPresenter
import com.restaurant.utils.AppUtils
import com.restaurant.view.SliderView

open class SliderActivity : SimpleMVPActivity<SliderPresenter, SliderView>(), SliderView {
    var viewPager: ViewPager? = null
    var circleIndicatorPager: CircleIndicatorPager? = null
    private lateinit var adapter: CarouselPagerAdapter

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slider)

        presenter!!.apiCall(RestConstant.CALL_API_SLIDER)

        viewPager = findViewById(R.id.viewPager)
        circleIndicatorPager = findViewById(R.id.circleIndicatorPager)

        findViewById<AppCompatButton>(R.id.appBtnSkip).setOnClickListener(
                {
                    AppUtils.startActivity(this, LoginActivity::class.java)
                    finish()
                })

        findViewById<AppCompatButton>(R.id.appBtnNext).setOnClickListener(
                {
                    vpNextPrevious(viewPager!!.currentItem + 1)
                })
    }

    override fun onBackPressed() {
        appExist()
    }

    //TODO CONSTANT VARIABLE DECLARATION
    companion object {
        const val LOOPS = 1
        var count = 5 //ViewPager items size

        var FIRST_PAGE = 0
        var listSlider: List<SliderList>? = null
    }

    override fun createPresenter(): SliderPresenter {
        return SliderPresenter()
    }

    override fun attachView(): SliderView {
        return this
    }

    override fun apiGetSliderResponse(response: SliderResponse) {
        val responseCheck = response.response

        if (responseManage(responseCheck!!)) {
            listSlider = response.sliderList!!
            vpNextPrevious(FIRST_PAGE)
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(activity, message + "")
    }

    private fun vpNextPrevious(pageNo: Int) {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val pageMargin = metrics.widthPixels / 5 * 2
        viewPager!!.pageMargin = -pageMargin

        adapter = CarouselPagerAdapter(this, supportFragmentManager)
        viewPager!!.adapter = CarouselPagerAdapter(this, supportFragmentManager)
        adapter.notifyDataSetChanged()

        viewPager!!.addOnPageChangeListener(adapter)
        viewPager!!.currentItem = pageNo
        viewPager!!.offscreenPageLimit = 3

        circleIndicatorPager!!.setViewPager(viewPager)
    }

    private fun responseManage(response: Response): Boolean =
            when {
                response!!.code == RestConstant.OK_200 -> true
                else -> false
            }
}