package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Handler
import com.restaurant.baseclass.BasePresenter
import com.restaurant.terasjawa.activity.SliderActivity
import com.restaurant.utils.AppUtils
import com.restaurant.view.SplashScreenView

class SplashScreenPresenter : BasePresenter<SplashScreenView>() {
    fun getSplashScreenWait(timeOut: Int) {
        Handler().postDelayed({
            AppUtils.startActivity(view!!.activity(), SliderActivity::class.java); //SliderActivity
            view!!.activity().finish()

        }, timeOut.toLong())
    }
}