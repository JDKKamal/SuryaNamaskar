package com.restaurant.model.api.response.signup.gmail

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class GmailSignUpResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("gplus_register")
    @Expose
    var gplusRegister: GplusRegister? = null
}