package com.restaurant.view
/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.DefaultResponse
import com.restaurant.model.api.response.comment.like.LikeResponse
import com.restaurant.model.api.response.comment.logincomment.LoginCommentResponse
import com.restaurant.model.api.response.comment.commentlist.CommentResponse
import com.restaurant.model.api.response.comment.subcomment.SubCommentResponse
import com.restaurant.model.api.response.comment.unlike.UnLikeResponse

interface DetailView : BaseView {
    fun apiGetAddToCartResponse(response: DefaultResponse)
    fun apiGetLoginCommentResponse(response: LoginCommentResponse)
    fun apiPostCommentListResponse(response: CommentResponse)
    fun apiPostSubCommentResponse(response: SubCommentResponse)

    fun apiPostLikeResponse(response: LikeResponse)
    fun apiPostUnLikeResponse(response: UnLikeResponse)
}
