package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.View
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.AppConstant
import com.restaurant.constant.RestConstant
import com.restaurant.db.DBQuery
import com.restaurant.model.api.response.menucategory.MenuCategoryList
import com.restaurant.model.api.response.menucategory.MenuCategoryResponse
import com.restaurant.model.db.CategoryListRealm
import com.restaurant.model.parcelable.CategoryParcelable
import com.restaurant.model.parcelable.MenuParcelable
import com.restaurant.presenter.MenuCategoryPresenter
import com.restaurant.terasjawa.CategoryClick
import com.restaurant.terasjawa.Finish
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.CategoryAdapter
import com.restaurant.terasjawa.execute
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.view.MenuCategoryView
import kotlinx.android.synthetic.main.activity_persanan_anda.*
import java.util.*

class CategoryActivity : SimpleMVPActivity<MenuCategoryPresenter, MenuCategoryView>(), MenuCategoryView, CategoryAdapter.ItemListener {
    private var toolBar: Toolbar? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appTvBadge: AppCompatTextView? = null
    internal var recyclerView: RecyclerView? = null

    private var parcelableMenu: List<MenuParcelable>? = null
    private lateinit var categoryAdapter: CategoryAdapter
    private var listCategory: MutableList<MenuCategoryList>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_persanan_anda)

        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)
        appTvBadge = toolBar!!.findViewById(R.id.appTvBadge)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        recyclerView = findViewById(R.id.recyclerView)

        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem

        setRecyclerView(recyclerView!!, 2, recyclerViewGridLayout)


        parcelableMenu = AppUtils.getParcelable(activity, AppConstant.BUNDLE_PARCELABLE)
        if (parcelableMenu != null) {
            appTvTitle!!.text = parcelableMenu!![0].categoryName.toUpperCase()

            val param: HashMap<String, String> = hashMapOf(
                    RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                    RestConstant.PARAM_MENU_LIST_CAT_ID to parcelableMenu!![0].cid
            )

            listCategory = mutableListOf()
            presenter!!.apiCall(1, param, RestConstant.CALL_API_MENU_CATEGORY)

            categoryAdapter = CategoryAdapter(this, parcelableMenu!![0].categoryName, listCategory!!)
            categoryAdapter.setOnListener(this)
            recyclerView!!.adapter = categoryAdapter

        }

        if (hasInternet()) {
            findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    listCategory = mutableListOf()
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                            RestConstant.PARAM_MENU_LIST_CAT_ID to parcelableMenu!![0].cid
                    )
                    presenter!!.apiCall(1, param, RestConstant.CALL_API_MENU_CATEGORY)

                }, 1000)
            }
        } else {
            swipeRefreshLayout.isRefreshing = false
        }

        findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)

        appIvDrawer!!.setOnClickListener {
            var intentOperation = Finish(activity)
            execute(intentOperation)
        }
    }

    override fun onResume() {
        super.onResume()
        appTvBadge!!.text = PreferenceUtils.preferenceInstance(this).cartItem
        categoryAdapter.notifyDataSetChanged()
    }

    override fun createPresenter(): MenuCategoryPresenter {
        return MenuCategoryPresenter()
    }

    override fun attachView(): MenuCategoryView {
        return this
    }

    override fun apiPostMenuCategoryResponse(response: MenuCategoryResponse) {
        swipeRefreshLayout.isRefreshing = false

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                when {
                    response.menuCart!!.isNotEmpty() -> {
                        DBQuery.with(this).realmDeleteTable()
                        response.menuCart!!.forEach { cartList -> DBQuery.with(this).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), cartList.menuId!!)) }
                    }
                    else -> DBQuery.with(this).realmDeleteTable()
                }

                categoryAdapter!!.categoryAddAll(response.menuListCat!!)
            }
            else -> AppUtils.showToast(this, response.response!!.message + "")
        }
    }

    override fun onClickCategory(menuCategoryList: MenuCategoryList) {
        val listCategoryPassData = ArrayList<CategoryParcelable>()
        var intentOperation = CategoryClick(activity, parcelableMenu, menuCategoryList, listCategoryPassData)
        execute(intentOperation)
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }
}
