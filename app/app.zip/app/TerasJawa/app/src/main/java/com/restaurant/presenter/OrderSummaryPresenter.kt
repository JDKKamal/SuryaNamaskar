package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.view.OrderSummaryView
import kotlin.collections.HashMap

class OrderSummaryPresenter : BasePresenter<OrderSummaryView>() {
    private fun callApiGetAddToCartList(swipeRefreshStatus: Int, params: HashMap<String, String>) {
        appInteractor.apiGetAddToCartList(view!!.activity(), params, object : InterActorCallback<CartListResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: CartListResponse) {
                view!!.apiGetAddToCartListResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    fun apiCall(swipeRefreshStatus: Int, params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_ADD_TO_CART_LIST -> callApiGetAddToCartList(swipeRefreshStatus, params)
            }
        }
    }
}
