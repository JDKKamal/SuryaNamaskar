package com.restaurant.terasjawa.fragment

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.baseclass.MVPFragment
import com.restaurant.constant.RestConstant
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.adapter.MenuAdapter
import com.restaurant.model.api.response.menu.MenuList
import com.restaurant.model.api.response.menu.MenuResponse
import com.restaurant.model.parcelable.MenuParcelable
import com.restaurant.presenter.MenuPresenter
import com.restaurant.terasjawa.*
import com.restaurant.terasjawa.execute
import com.restaurant.utils.AppUtils
import com.restaurant.view.MenuView
import kotlinx.android.synthetic.main.fragment_menu.*

class MenuFragment : MVPFragment<MenuPresenter, MenuView>(), MenuView, MenuAdapter.ItemListener {
    private var recyclerView: RecyclerView? = null
    private lateinit var menuAdapter: MenuAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_menu, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        setRecyclerView(recyclerView!!, 2, 1)

        presenter!!.apiCall(1, RestConstant.CALL_API_MENU)

        if (hasInternet()) {
            view.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
                override fun onRefresh() {
                    swipeRefreshLayout.isRefreshing = true
                    Handler().postDelayed({
                        presenter!!.apiCall(0, RestConstant.CALL_API_MENU)
                    }, 1000)
                }
            })
        }

        view.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)

        return view
    }

    override fun createPresenter(): MenuPresenter {
        return MenuPresenter()
    }

    override fun attachView(): MenuView {
        return this
    }

    override fun apiPostMenuResponse(response: MenuResponse) {
        swipeRefreshLayout.isRefreshing = false

        if (response.response!!.code == RestConstant.OK_200) {
            menuAdapter = MenuAdapter(activity!!, response.menucategoryList!!)
            menuAdapter.setOnListener(this)
            recyclerView!!.adapter = menuAdapter
        } else {
            AppUtils.showToast(activity!!, response.response!!.message + "")
        }
    }

    override fun onClickMenu(modelMenu: MenuList) {
        val alPassDataQuestion = ArrayList<MenuParcelable>()
        var intentOperation = MenuClick(activity!!, modelMenu, alPassDataQuestion)
        execute(intentOperation)
    }

    override fun onFailure(message: String) {
        swipeRefreshLayout.isRefreshing = false
        AppUtils.showToast(activity!!, message + "")
    }
}
