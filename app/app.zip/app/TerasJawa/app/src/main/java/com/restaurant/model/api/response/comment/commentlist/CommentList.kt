package com.restaurant.model.api.response.comment.commentlist

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CommentList {

    @SerializedName("count")
    @Expose
    var count: String? = null
    @SerializedName("r_id")
    @Expose
    var rId: String? = null
    @SerializedName("ip")
    @Expose
    var ip: String? = null
    @SerializedName("rate")
    @Expose
    var rate: String? = null
    @SerializedName("msg")
    @Expose
    var msg: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("user_image")
    @Expose
    var userImage: String? = null
    @SerializedName("like_unlike")
    @Expose
    var likeUnlike: Int? = null

    constructor(count: String?, rId: String?, ip: String?, rate: String?, msg: String?, name: String?, userImage: String?, likeUnlike: Int?) {
        this.count = count
        this.rId = rId
        this.ip = ip
        this.rate = rate
        this.msg = msg
        this.name = name
        this.userImage = userImage
        this.likeUnlike = likeUnlike
    }
}