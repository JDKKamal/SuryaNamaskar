package com.restaurant.view

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BaseView
import com.restaurant.model.api.response.promo.PromoResponse

interface PromoView : BaseView {
    fun apiPostPromoResponse(response: PromoResponse)
}