package com.restaurant;

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

public class Note {
    //http://www.devexchanges.info/2016/09/viewpager-cards-like-duolingo.html
    //https://dashboard.xendit.co/auth/register


    //TODO PAYMENT PRODUCTION
    /*Merchant ID = M126922
    Client Key = Mid-client-vR-1dYzXef5qn5k-
    Server Key = Mid-server-r_a1JyPWob7hcYCOZZMCPrXY*/

    //http://doku.com/themes/default/files/References.pdf

    /*
    Test Transactions
Credit Card (3D Secure)
Card No = 4111­1111­1111­1111
CVV2 = 869
Exp Date = 04/20
Credit Card (non­3D Secure)
Card No = 5426­4000­3010­8754
CVV2 = 869
Exp Date = 04/20
DOKU Wallet
DOKUid = 1016998760 / system­noreply@doku.com
Password = Dokupay123
PIN = 1122
Mandiri Clickpay
Card No = 4616­9941­5666­6614
Token response = 000000 
Test Email : nizaramr@gmail.com
    */
}
