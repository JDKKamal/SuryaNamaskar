package com.restaurant.model.api.response.menucategory

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuCategoryResponse{
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("menu_list_cat")
    @Expose
    var menuListCat: MutableList<MenuCategoryList>? = null
    @SerializedName("menu_cart")
    @Expose
    var menuCart: MutableList<MenuCartList>? = null
}