package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Context
import android.support.v7.widget.AppCompatRatingBar
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.restaurant.constant.RestConstant
import com.restaurant.customviews.recyclerview.BaseRecyclerView
import com.restaurant.customviews.recyclerview.BaseViewHolder
import com.restaurant.terasjawa.R
import com.restaurant.model.api.response.menu.MenuList
import com.restaurant.utils.AppUtils
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.itemview_menu.view.*

class MenuAdapter(private val context: Context, private val menuList: MutableList<MenuList>) : BaseRecyclerView<MenuList>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)

    private var listener: ItemListener? = null

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): MenuList {
        return menuList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<MenuList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_menu, parent, false))
    }

    override fun getItemCount(): Int {
        return menuList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<MenuList>(itemView){
        var appTvTitle: AppCompatTextView? = null
        var appIvMenuIcon: CircleImageView? = null
        var appRbMenu : AppCompatRatingBar? = null

        init {
            appTvTitle = itemView.findViewById(R.id.appTvTitle)
            appIvMenuIcon = itemView.findViewById(R.id.appIvMenuIcon)
            appRbMenu = itemView.findViewById(R.id.appRbMenu)
        }

        override fun populateItem(modelMenu: MenuList) {
            appTvTitle!!.text = modelMenu.categoryName.toString()
            appRbMenu!!.rating = modelMenu.rateAvg!!.toFloat()
            AppUtils.glideSetAppImageView(context, RestConstant.IMAGE_URL + modelMenu.categoryImage, appIvMenuIcon!!)

            itemView.setOnClickListener { listener!!.onClickMenu(menuList[layoutPosition]) }
        }
    }

    interface ItemListener {
        fun onClickMenu(modelMenu: MenuList)
    }
}
