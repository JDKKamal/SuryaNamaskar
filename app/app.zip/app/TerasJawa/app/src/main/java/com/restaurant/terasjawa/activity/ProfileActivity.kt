package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.support.v7.app.AlertDialog
import android.support.v7.widget.*
import android.view.View
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.RestConstant
import com.restaurant.model.api.response.profile.ProfileResponse
import com.restaurant.model.event.ProfileEvent
import com.restaurant.presenter.ProfilePresenter
import com.restaurant.terasjawa.R
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.view.ProfileView
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.restaurant.db.DBQuery
import de.hdodenhof.circleimageview.CircleImageView
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.greenrobot.eventbus.EventBus
import java.io.File

class ProfileActivity : SimpleMVPActivity<ProfilePresenter, ProfileView>(), ProfileView, View.OnClickListener {
    private var toolBar: Toolbar? = null
    private var appIvDrawer: AppCompatImageView? = null
    private var appTvTitle: AppCompatTextView? = null
    private var appTvLogout: AppCompatTextView? = null

    private val GALLERY = 1
    private val CAMERA = 2
    private var path: String? = ""

    private val appIvProfile by bind<CircleImageView>(R.id.appIvProfile)
    private val appBtnUpdateProfile by bind<AppCompatButton>(R.id.appBtnUpdateProfile)
    private val appTvUserName by bind<AppCompatTextView>(R.id.appTvUserName)
    private val appEdtName by bind<AppCompatEditText>(R.id.appEdtName)
    private val appEdtEmail by bind<AppCompatEditText>(R.id.appEdtEmail)
    private val appEdtMobile by bind<AppCompatEditText>(R.id.appEdtMobile)
    private val appEdtPassword by bind<AppCompatEditText>(R.id.appEdtPassword)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        hideSoftKeyboard()
        EventBus.getDefault()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar!!.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar!!.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar!!.findViewById(R.id.appIvDrawer)
        appTvLogout = toolBar!!.findViewById(R.id.appTvLogout)

        appTvTitle!!.text = getString(R.string.toolbar_title_profile_event).toUpperCase()

        //TODO IF LOGIN STATUS NOT 0 THEN appEdtName NOT EDIT, appEdtPassword IS GONE
        if (PreferenceUtils.preferenceInstance(this).loginStatus != RestConstant.LOGIN_SIMPLE_STATUS) {
            appEdtEmail.isFocusable = false
            appEdtPassword.visibility = View.GONE
        } else {
            appEdtEmail.clearFocus()
            appEdtEmail.isFocusable = true
            appEdtPassword.visibility = View.VISIBLE
        }

        if (PreferenceUtils.preferenceInstance(this).isLogin) {
            appEdtName.setText(PreferenceUtils.preferenceInstance(this).userName)
            appEdtEmail.setText(PreferenceUtils.preferenceInstance(this).email)

            appTvUserName.text = PreferenceUtils.preferenceInstance(this).userName

            appEdtName.setSelection(appEdtName.text!!.length)
            when {
                PreferenceUtils.preferenceInstance(this.activity).profilepicture.isNotEmpty() -> AppUtils.glideSetAppImageView(this.activity, PreferenceUtils.preferenceInstance(this).profilepicture, appIvProfile)
            }

            when {
                !PreferenceUtils.preferenceInstance(this).mobile.isBlank() -> appEdtMobile.setText(PreferenceUtils.preferenceInstance(this).mobile)
            }
        }

        appIvDrawer!!.setOnClickListener(this)
        appTvLogout!!.setOnClickListener(this)
        appBtnUpdateProfile.setOnClickListener(this)
        appIvProfile.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> finish()

            R.id.appBtnUpdateProfile -> {
                when {
                    presenter!!.validation(appEdtName.text.toString(), appEdtEmail.text.toString(), appEdtMobile.text.toString(), appEdtPassword.text.toString()) -> {
                        var mediaType = MediaType.parse("text/plain")
                        var requestBody: RequestBody?
                        var file: File?
                        var fileName: String?

                        when {
                            path!!.isBlank() -> {
                                requestBody = RequestBody.create(null, ByteArray(0))
                                fileName = ""
                            }
                            else -> {
                                file = File(path!!)
                                requestBody = RequestBody.create(MediaType.parse("*/*"), file)
                                fileName = file.name
                            }
                        }

                        val rbUserId: RequestBody = RequestBody.create(mediaType, PreferenceUtils.preferenceInstance(this).userId)
                        val rbUsername: RequestBody = RequestBody.create(mediaType, appEdtName.text.toString())
                        val rbEmail: RequestBody = RequestBody.create(mediaType, appEdtEmail.text.toString())
                        val rbPassword: RequestBody = RequestBody.create(mediaType, appEdtPassword.text.toString())
                        val rbMobile: RequestBody = RequestBody.create(mediaType, appEdtMobile.text.toString())
                        val rbAddress: RequestBody = RequestBody.create(mediaType, "")

                        val fileUpload = MultipartBody.Part.createFormData(RestConstant.PARAM_USER_IMAGE, fileName, requestBody)
                        presenter!!.callApiProfile(fileUpload, rbUserId, rbUsername, rbEmail, rbPassword, rbMobile, rbAddress)
                    }
                }
            }

            R.id.appTvLogout -> appLogout()

            R.id.appIvProfile -> {
                Dexter.withActivity(this)
                        .withPermissions(
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.CAMERA)
                        .withListener(object : MultiplePermissionsListener {
                            override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {
                                token!!.continuePermissionRequest()
                            }

                            override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                                when {
                                    report.areAllPermissionsGranted() ->
                                        if (hasInternet()) {
                                            showPictureDialog()
                                        }
                                }
                                when {
                                    report.isAnyPermissionPermanentlyDenied -> startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.fromParts("package", packageName, null)))
                                }
                            }
                        })
                        .onSameThread()
                        .check()
            }
        }
    }

    override fun createPresenter(): ProfilePresenter {
        return ProfilePresenter()
    }

    override fun attachView(): ProfileView {
        return this
    }

    override fun apiPostProfileResponse(response: ProfileResponse) {
        AppUtils.showToast(this, response!!.message + "")

        when {
            response!!.code == RestConstant.OK_200 -> {
                //PreferenceUtils.preferenceInstance(this).loginStatus =
                PreferenceUtils.preferenceInstance(this).userName = response.updateUserProfile!!.name!!
                PreferenceUtils.preferenceInstance(this).email = response.updateUserProfile!!.email!!
                PreferenceUtils.preferenceInstance(this).mobile = response.updateUserProfile!!.phone!!
                PreferenceUtils.preferenceInstance(this).profilepicture = response.updateUserProfile!!.userImage!!

                appTvUserName.text = PreferenceUtils.preferenceInstance(this).userName
                EventBus.getDefault().post(ProfileEvent(response.updateUserProfile!!.userImage!!))
            }
        }
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }

    private fun showPictureDialog() {
        val pictureDialog = AlertDialog.Builder(this)
        pictureDialog.setTitle(getString(R.string.dialog_profile_title))
        val pictureDialogItems = arrayOf(getString(R.string.dialog_profile_gallery), getString(R.string.dialog_profile_camera))
        pictureDialog.setItems(pictureDialogItems) { dialog, which ->
            when (which) {
                0 -> chooseFromGallery()
                1 -> takeFromCamera()
            }
        }
        pictureDialog.show()
    }

    private fun chooseFromGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, GALLERY)
    }

    private fun takeFromCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA)
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            GALLERY -> when {
                data != null -> {
                    val contentURI = data.data
                    try {
                        val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, contentURI)
                        val path = saveImage(bitmap)
                        this.path = path
                        appIvProfile.setImageBitmap(bitmap)

                    } catch (ex: Exception) {
                    }
                }
            }
            CAMERA -> try {
                val thumbnail = data!!.extras!!.get("data") as Bitmap
                appIvProfile.setImageBitmap(thumbnail)
                val path = saveImage(thumbnail)
                this.path = path
            } catch (ex: Exception) {

            }
        }
    }

    override fun onBackPressed() {
        finish()
    }

    private fun appLogout() {
        val builder = android.app.AlertDialog.Builder(activity)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_logout, null)
        alertDialog.setView(dialogView)

        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        appTvYes.setOnClickListener(
                {
                    DBQuery.with(activity).realmDeleteTable()
                    
                    PreferenceUtils.preferenceInstance(activity).loginStatus = 0
                    PreferenceUtils.preferenceInstance(activity).isLogin = false
                    PreferenceUtils.preferenceInstance(activity).email = ""
                    PreferenceUtils.preferenceInstance(activity).userName = ""
                    PreferenceUtils.preferenceInstance(activity).mobile = ""
                    PreferenceUtils.preferenceInstance(activity).profilepicture = ""
                    PreferenceUtils.preferenceInstance(activity).loginStatus = 0

                    val newIntent = Intent(activity, LoginActivity::class.java)
                    newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(newIntent)
                })
        appTvNo.setOnClickListener({ alertDialog.dismiss() })

        alertDialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}