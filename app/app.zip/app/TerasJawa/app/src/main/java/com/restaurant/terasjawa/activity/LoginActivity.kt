package com.restaurant.terasjawa.activity

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.view.View
import android.widget.LinearLayout
import com.restaurant.baseclass.SimpleMVPActivity
import com.restaurant.constant.RestConstant
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterHelper
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterListener
import com.restaurant.customviews.socialintegration.twitterintegration.TwitterUser
import com.restaurant.terasjawa.R
import com.restaurant.interacter.AppInteractor
import com.restaurant.model.api.request.LoginRequest
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.model.api.response.login.LoginResponse
import com.restaurant.presenter.LoginPresenter
import com.restaurant.terasjawa.*
import com.restaurant.terasjawa.execute
import com.restaurant.utils.AppUtils
import com.restaurant.utils.PreferenceUtils
import com.restaurant.utils.logInfo
import com.restaurant.view.LoginView
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginHelper
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginListener
import com.jdkgroup.customview.socialintegration.facebookintegration.FacebookLoginModel
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginHelper
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginListener
import com.jdkgroup.customview.socialintegration.googleintegration.GoogleLoginModel
import com.restaurant.db.DBQuery
import com.restaurant.model.api.Response
import com.restaurant.model.db.CategoryListRealm
import kotlinx.android.synthetic.main.activity_login.*
import java.util.*

class LoginActivity : SimpleMVPActivity<LoginPresenter, LoginView>(), LoginView, FacebookLoginListener, GoogleLoginListener, TwitterListener, View.OnClickListener {

    private var facebookLoginHelper: FacebookLoginHelper? = null
    private var googleLoginHelper: GoogleLoginHelper? = null
    private var appInteractor: AppInteractor? = null
    private var twitterHelper: TwitterHelper? = null

    private var loginStatus: Int? = null
    private val llBack by bind<LinearLayout>(R.id.llBack)
    private val appBtnSignIn by bind<AppCompatButton>(R.id.appBtnSignIn)
    private val appTvForgotPassword by bind<AppCompatTextView>(R.id.appTvForgotPassword)
    private val appTvSignUp by bind<AppCompatTextView>(R.id.appTvSignUp)
    private val appIvSocialFacebook by bind<AppCompatImageView>(R.id.appIvSocialFacebook)
    private val appIvSocialTwitter by bind<AppCompatImageView>(R.id.appIvSocialTwitter)
    private val appIvSocialGooglePlus by bind<AppCompatImageView>(R.id.appIvSocialGooglePlus)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        hideSoftKeyboard()
        appInteractor = AppInteractor()
        //TODO SOCIAL LOGIN
        facebookLoginHelper = FacebookLoginHelper(this)
        googleLoginHelper = GoogleLoginHelper(this, this, RestConstant.SOCIAL_GOOGLE_ID)
        twitterHelper = TwitterHelper(R.string.twitter_api_key, R.string.twitter_secrate_key, this, this)

        appInteractor!!.getFacebookHashKey(this, RestConstant.APP_PACKAGE_NAME); //TODO GET FACEBOOK HASHKEY

        llBack.setOnClickListener(this)
        appBtnSignIn.setOnClickListener(this)
        appTvForgotPassword.setOnClickListener(this)
        appTvSignUp.setOnClickListener(this)
        appIvSocialFacebook.setOnClickListener(this)
        appIvSocialTwitter.setOnClickListener(this)
        appIvSocialGooglePlus.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.llBack -> appFinish()
            R.id.appBtnSignIn -> {
                val email = appEdtEmail.text.toString()
                val password = appEdtPassword.text.toString()

                presenter!!.validation(email, password)
                loginStatus = RestConstant.LOGIN_SIMPLE_STATUS
            }

            R.id.appTvForgotPassword -> {
                var intentOperation = ForgotPassword(activity)
                execute(intentOperation)
            }

            R.id.appTvSignUp -> {
                var intentOperation = SignUpIntent(activity)
                execute(intentOperation)
            }

            R.id.appIvSocialFacebook -> {
                var intentOperation = facebookLoginHelper?.let { FacebookLogin(activity, it) }
                execute(intentOperation!!)
            }

            R.id.appIvSocialTwitter -> {
                var intentOperation = twitterHelper?.let { TwitterLogin(it) }
                execute(intentOperation!!)
            }

            R.id.appIvSocialGooglePlus -> {
                var intentOperation = googleLoginHelper?.let { GooglePlusLogin(activity, it) }
                execute(intentOperation!!)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        var intentOperation = ActivityResultSocialLogin(googleLoginHelper!!, facebookLoginHelper!!, twitterHelper!!, requestCode, resultCode, data)
        execute(intentOperation)
    }

    override fun createPresenter(): LoginPresenter {
        return LoginPresenter()
    }

    override fun attachView(): LoginView {
        return this
    }

    override fun onFbSignInFail(errorMessage: String) {
        //AppUtils.showToast(this, errorMessage + "")
    }

    override fun onFbSignInSuccess(facebookLoginModel: FacebookLoginModel) {
        loginStatus = RestConstant.LOGIN_FACEBOOK_STATUS
        presenter!!.apiCall(RestConstant.CALL_LOGIN_SOCIAL, LoginRequest(facebookLoginModel.email!!, ""))
    }

    override fun onFBSignOut() {

    }

    override fun onGoogleAuthSignIn(googleLoginModel: GoogleLoginModel) {
        loginStatus = RestConstant.LOGIN_GOOGLE_PLUS_STATUS
        presenter!!.apiCall(RestConstant.CALL_LOGIN_SOCIAL, LoginRequest(googleLoginModel.email, ""))
    }

    override fun onGoogleAuthSignInFailed(errorMessage: String) {
    }

    override fun onGoogleAuthSignOut() {
    }

    override fun onTwitterError() {
    }

    override fun onTwitterSignIn(userId: String, userName: String) {
    }

    override fun onTwitterProfileReceived(user: TwitterUser) {
        loginStatus = RestConstant.LOGIN_TWITTER_STATUS
        logInfo("Tag" + getToJson(user.email))
        //presenter!!.apiCall(this, RestConstant.CALL_LOGIN_SOCIAL, LoginRequest(twitterUser!!.email!!, ""))
    }

    override fun apiPostLoginResponse(response: LoginResponse) {
        val responseCheck = response.response
        when {
            responseManage(responseCheck!!) -> {
                var intentOperation = Login(activity, response, this.loginStatus!!)
                execute(intentOperation)

                AppUtils.startActivity(activity, DrawerActivity::class.java)
                finish()
            }
            else -> appEdiTextNullSet(R.id.appEdtPassword)
        }
    }

    override fun apiGetAddToCartListResponse(response: CartListResponse) {
        DBQuery.with(this).realmDeleteTable()
        if (response.response!!.code == RestConstant.not_found_404) {
        } else {
            response.cartList!!.forEach { cartList -> DBQuery.with(this).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), cartList.menuId!!)) }
        }

        var intentOperation = DrawerIntentLogin(activity, response)
        execute(intentOperation)
    }

    override fun onFailure(message: String) {
        AppUtils.showToast(this, message)
    }

    override fun onBackPressed() {
        appFinish()
    }

    //FINISH APP WHEN isLogout IS 1 THEN NEW ACTIVITY OPEN IS SliderActivity
    private fun appFinish() {
        when {
            PreferenceUtils.preferenceInstance(this).isLogout == 1 -> {
                var intentOperation = LogoutBack(activity)
                execute(intentOperation)
            }
            else -> {
                appExist()
            }
        }
    }


    private fun responseManage(response: Response): Boolean =
            when {
                response!!.code == RestConstant.OK_200 -> true
                else -> false
            }
}