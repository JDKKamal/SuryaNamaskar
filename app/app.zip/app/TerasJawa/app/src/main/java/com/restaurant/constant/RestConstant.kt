package com.restaurant.constant

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

class RestConstant {
    companion object {
        var URL_CHARGING_DOKU_DAN_CC = "http://crm.doku.com/doku-library-staging/example-payment-mobile/merchant-example.php"
        var URL_CHARGING_MANDIRI_CLICKPAY = "http://crm.doku.com/doku-library-staging/example-payment-mobile/merchant-mandiri-example.php"
        var URL_REQUEST_VACODE = "http://demomerchant.doku.com/va_generate_staging.php"

        var SOCIAL_GOOGLE_ID = "1080442829017-nnenb9u2t6gab9oa59ovag9mm6bcq4s5.apps.googleusercontent.com";
        var APP_PACKAGE_NAME = "com.restaurant.terasjawa";

        var PRIVACY_POLICY_SIGN_UP = " http://kenawastudio.com/privacy-policy";

        var FOLDER_NAME = "/.terasjawa/bytotech"

        var LOGIN_SIMPLE_STATUS = 0;
        var LOGIN_FACEBOOK_STATUS = 1;
        var LOGIN_GOOGLE_PLUS_STATUS = 2;
        var LOGIN_TWITTER_STATUS = 3;

        @JvmField
        var BASE_URL = "http://bytotech.com/onlinerestaurant/"
        var API_GET = "api.php?"
        var IMAGE_URL = "http://bytotech.com/onlinerestaurant/images/"

        var API_GET_CAT_SLIDER = "api.php?slider_list"
        var API_POST_SIGN_UP = "user_register_api?"
        var API_POST_FACEBOOK_SIGN_UP = "user_register_fb_api.php?"
        var API_POST_GOOGLE_SIGN_UP = "user_register_gplus_api.php?"
        var API_POST_TWITTER_SIGN_UP = "user_register_twiter_api.php?"

        var API_POST_LOGIN = "user_login_api.php?"
        var API_POST_FORGOTPASSWORD = "user_forgot_pass_api.php?"

        var API_GET_MENU_LIST = "/api.php?cat_list"

        var API_GET_ADD_TO_CART = "api_cart_add.php?"
        var API_GET_CAT_LIST = "api_cart_list.php?"
        var API_GET_DELETE_CART_ITEM = "api_cart_item_delete.php?"
        var API_GET_UPDATE_CART_ITEM = "api_cart_add_update.php?"
        var API_POST_PROFILE = "user_profile_update_api.php?"

        var API_GET_COUNTRY_LIST = "/api.php?country_list"
        var API_GET_DISTRICT_LIST = "api.php?"
        var API_POST_ORDER_DELIVERY = "api_orderdelivery_detail.php"

        var API_GET_LOGIN_COMMENT = "api_rating.php?"
        var API_GET_PROMO = "api.php?promo_menu"
        var API_POST_COMMENT_LIST = "api.php?review_list"
        var API_POST_SUB_COMMENT = "api.php?comment"
        var API_POST_LIKE = "api.php?like"
        var API_POST_UNLIKE = "api.php?unlike"
        var API_GET_COMMENT_VIEW = "api.php?"

        var CALL_API_SLIDER = 0;
        var CALL_API_LOGIN = 1;
        var CALL_API_REGISTER = 2;
        var CALL_API_FORGOTPASSWORD = 3;
        var CALL_API_MENU = 4;
        var CALL_API_MENU_CATEGORY = 5;

        var CALL_API_ADD_TO_CART_LIST = 6;
        var CALL_API_DELETE_CART_ITEM = 7;
        var CALL_API_ADD_TO_CART = 8;
        var CALL_API_UPDATE_CART_ITEM = 9;
        var CALL_API_FACEBOOK_REGISTER = 10;
        var CALL_API_TWITTER_REGISTER = 11;
        var CALL_API_GOOGLE_PLUS_REGISTER = 12;
        var CALL_LOGIN_SOCIAL = 13;
        var CALL_API_COUNTRY = 14;
        var CALL_API_DISTRICT = 15;
        var CALL_API_ORDER_DELIVERY = 16;
        var CALL_API_COMMENT_LOGIN = 17;
        var CALL_API_PROMO = 18;
        var CALL_API_COMMENT_LIST = 19;
        var CALL_API_SUB_COMMENT = 20;
        var CALL_API_LIKE = 21;
        var CALL_API_UNLIKE = 22;
        var CALL_API_COMMENT_VIEW = 23;


        var REQUEST_AUTH = 1
        var REQUEST_NO_AUTH = 0

        /* DB STATUS */
        var TYPE_DELETION = 0
        var TYPE_INSERTION = 1
        var TYPE_MODIFICATION = 2

        /* ERROR CODE */
        var OK_200 = 200
        var created_201 = 201
        var accepted_202 = 202
        var non_authoritative_information_203 = 203
        var no_content_203 = 204
        var reset_content_205 = 205

        var found_302 = 302
        var see_other_303 = 303
        var not_modified_304 = 304
        var use_proxy_305 = 305
        var temporary_redirect_307 = 307
        var unused_306 = 306
        var permanent_redirect_308 = 308

        var bad_request_400 = 400 //Bad request
        var unauthorized_401 = 401
        var forbidden_403 = 403 //Account is disabled / Authentication failed / Read disabled / Insufficient account permissions
        var not_found_404 = 404
        var method_not_allowed_405 = 405
        var not_acceptable_406 = 406
        var proxy_authentication_required_407 = 407
        var request_timeout_408 = 408
        var conflict_409 = 409 //Account already exists
        var gone_410 = 410
        var length_required_411 = 411
        var precondition_failed_412 = 412
        var request_entity_too_large_413 = 413
        var unsupported_media_type_415 = 415
        var requested_range_not_satisfiable_416 = 416
        var missing_arguments_419 = 419
        var invarid_arguments_420 = 420
        var too_many_requests_429 = 429

        var internal_server_error_500 = 500
        var not_implemented_501 = 501
        var bad_gateway_502 = 502
        var service_unavailable_503 = 503
        var gateway_timeout_504 = 504
        var http_version_not_supported_505 = 505
        var network_authentication_required_511 = 511

        //TODO PARAM
        var PARAM_FACEBOOK_ID = "fb_id"
        var PARAM_GOOGLE_PLUS_ID = "gplus_id"
        var PARAM_TWITTER_ID = "twiter_id"

        var PARAM_NAME = "name"
        var PARAM_EMAIL = "email"
        var PARAM_PASSWORD = "password"
        var PARAM_PHONE = "phone"
        var PARAM_USER_ID = "user_id"
        var PARAM_CART_ID = "cart_id"
        var REST_ID = "rest_id"
        var MENU_ID = "menu_id"
        var MENU_NAME = "menu_name"
        var MENU_QTY = "menu_qty"
        var MENU_PRICE = "menu_price"
        var PARAM_MENU_LIST_CAT_ID = "menu_list_cat_id"
        var PARAM_DISTRICT_CAT = "district_cat"
        var PARAM_TITLE_NAME = "title_name"
        var PARAM_FULL_NAME = "full_name"
        var PARAM_MOBILE_NUMBER = "mobile_number"
        var PARAM_ADDRESS = "address"
        var PARAM_STATE_ID = "state_id"
        var PARAM_COUNTRY_ID = "country_id"
        var PARAM_USER_IMAGE = "user_image"

        var PARAM_RATE = "rate"
        var PARAM_MSG = "msg"
        var PARAM_MID = "mid"
        var PARAM_R_ID = "r_id"
        var PARAM_COMMENT = "comment"
        var PARAM_VIEW_MORE_COMMENT = "view_more_comment"

    }
}
