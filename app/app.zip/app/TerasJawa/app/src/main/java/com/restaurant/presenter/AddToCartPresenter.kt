package com.restaurant.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.baseclass.BasePresenter
import com.restaurant.constant.RestConstant
import com.restaurant.interacter.InterActorCallback
import com.restaurant.model.api.response.DefaultResponse
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.view.AddToCartView
import kotlin.collections.HashMap

class AddToCartPresenter : BasePresenter<AddToCartView>() {
    private fun callApiGetAddToCartList(swipeRefreshStatus: Int, params: HashMap<String, String>) {
        appInteractor.apiGetAddToCartList(view!!.activity(), params, object : InterActorCallback<CartListResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(true)
                }
            }

            override fun onResponse(response: CartListResponse) {
                view!!.apiGetAddToCartListResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view!!.showProgressDialog(false)
                }
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    private fun callApiGeUpdateCartItem(params: HashMap<String, String>) {
        appInteractor.apiGetUpdateCartItem(view!!.activity(), params, object : InterActorCallback<DefaultResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: DefaultResponse) {
                view!!.apiGetUpdateItemResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }
        })
    }

    private fun callApiGetDeleteCartItem(params: HashMap<String, String>) {
        appInteractor.apiGetDeleteCartItem(view!!.activity(), params, object : InterActorCallback<DefaultResponse> {
            override fun onStart() {
                view!!.showProgressDialog(true)
            }

            override fun onResponse(response: DefaultResponse) {
                view!!.apiGetDeleteItemResponse(response)
            }

            override fun onFinish() {
                view!!.showProgressDialog(false)
            }

            override fun onError(message: String) {
                view!!.onFailure(message)
            }

        })
    }

    fun apiCall(swipeRefreshStatus: Int, params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_ADD_TO_CART_LIST -> callApiGetAddToCartList(swipeRefreshStatus, params)
                RestConstant.CALL_API_DELETE_CART_ITEM -> callApiGetDeleteCartItem(params)
                RestConstant.CALL_API_UPDATE_CART_ITEM -> callApiGeUpdateCartItem(params)
            }
        }
    }
}
