package com.restaurant.customviews.socialintegration.twitterintegration

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.app.Activity
import android.content.Intent
import android.support.annotation.StringRes
import android.util.Log

import com.twitter.sdk.android.core.Callback
import com.twitter.sdk.android.core.DefaultLogger
import com.twitter.sdk.android.core.Result
import com.twitter.sdk.android.core.Twitter
import com.twitter.sdk.android.core.TwitterAuthConfig
import com.twitter.sdk.android.core.TwitterConfig
import com.twitter.sdk.android.core.TwitterCore
import com.twitter.sdk.android.core.TwitterException
import com.twitter.sdk.android.core.TwitterSession
import com.twitter.sdk.android.core.identity.TwitterAuthClient
import com.twitter.sdk.android.core.models.User

class TwitterHelper(@StringRes twitterApiKey: Int, @StringRes twitterSecreteKey: Int, private val mListener: TwitterListener, private val mActivity: Activity) {
    private val mAuthClient: TwitterAuthClient?

    init {
        val authConfig = TwitterConfig.Builder(mActivity)
                .logger(DefaultLogger(Log.DEBUG))
                .twitterAuthConfig(TwitterAuthConfig(mActivity.resources.getString(twitterApiKey), mActivity.resources.getString(twitterSecreteKey)))
                .debug(true)
                .build()
        Twitter.initialize(authConfig)

        mAuthClient = TwitterAuthClient()
    }

    /**
     * PERFORM TWITTER SIGN IN. CALL THIS METHOD WHEN USER CLICKS ON "LOGIN WITH TWITTER" BUTTON.
     */
    fun performSignIn() {
        mAuthClient!!.authorize(mActivity, object : Callback<TwitterSession>() {
            override fun success(result: Result<TwitterSession>) {
                val session = result.data
                mListener.onTwitterSignIn(session.userName, session.userId.toString() + " ")

                //LOAD USER DATA
                getUserData()
            }

            override fun failure(exception: TwitterException) {
                mListener.onTwitterError()
            }
        })
    }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        mAuthClient?.onActivityResult(requestCode, resultCode, data)
    }

    private fun getUserData() {
        val twitterApiClient = TwitterCore.getInstance().apiClient
        val statusesService = twitterApiClient.accountService
        val call = statusesService.verifyCredentials(true, true, true)
        call.enqueue(object : Callback<User>() {
            override fun success(userResult: Result<User>) {
                val user = TwitterUser()
                user.name = userResult.data.name
                user.email = userResult.data.email
                user.description = userResult.data.description
                user.pictureUrl = userResult.data.profileImageUrl
                user.bannerUrl = userResult.data.profileBannerUrl
                user.language = userResult.data.lang
                user.id = userResult.data.id

                mListener.onTwitterProfileReceived(user)
            }

            override fun failure(exception: TwitterException) {
                System.out.println("Tag" + exception.toString())
            }
        })
    }
}
