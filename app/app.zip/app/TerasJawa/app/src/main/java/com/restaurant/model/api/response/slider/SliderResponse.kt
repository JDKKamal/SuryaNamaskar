package com.restaurant.model.api.response.slider

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SliderResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("slider_list")
    @Expose
    var sliderList: List<SliderList>? = null
}