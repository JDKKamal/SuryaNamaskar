package com.restaurant.model.api.response.comment.commentview

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CommentViewResponse{
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("view_more_comment_list")
    @Expose
    var viewMoreCommentList: List<ViewMoreCommentList>? = null
}