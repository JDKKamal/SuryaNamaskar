package com.restaurant.terasjawa.adapter

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import android.view.View
import com.restaurant.terasjawa.R
import com.restaurant.terasjawa.fragment.CarouselFragment
import com.restaurant.customviews.carousel.CarouselLinearLayout
import com.restaurant.terasjawa.activity.SliderActivity

class CarouselPagerAdapter(private val context: SliderActivity, private val fragmentManager: FragmentManager) : FragmentPagerAdapter(fragmentManager), ViewPager.OnPageChangeListener {
    private var scale: Float = 0.toFloat()

    override fun getItem(position: Int): Fragment {
        var position = position
        //MAKE THE FIRST PAGER BIGGER THAN OTHERS
        try {
            if (position == SliderActivity.FIRST_PAGE)
                scale = BIG_SCALE
            else
                scale = SMALL_SCALE

            position %= SliderActivity.count

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return CarouselFragment.newInstance(context, position, scale)
    }

    override fun getCount(): Int {
        var count = 0
        try {
            count = SliderActivity.count * SliderActivity.LOOPS
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return count
    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        try {
            if (positionOffset in 0f..1f) {
                val cur = getRootView(position)
                val next = getRootView(position + 1)

                cur.setScaleBoth(BIG_SCALE - DIFF_SCALE * positionOffset)
                next.setScaleBoth(SMALL_SCALE + DIFF_SCALE * positionOffset)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onPageSelected(position: Int) {
    }

    override fun onPageScrollStateChanged(state: Int) {
    }

    private fun getRootView(position: Int): CarouselLinearLayout {
        return fragmentManager.findFragmentByTag(this.getFragmentTag(position)).view!!.findViewById<View>(R.id.root_container) as CarouselLinearLayout
    }

    private fun getFragmentTag(position: Int): String {
        return "android:switcher:" + context.viewPager!!.id + ":" + position
    }

    companion object {
        val BIG_SCALE = 1.3f
        val SMALL_SCALE = 0.7f
        val DIFF_SCALE = BIG_SCALE - SMALL_SCALE
    }
}