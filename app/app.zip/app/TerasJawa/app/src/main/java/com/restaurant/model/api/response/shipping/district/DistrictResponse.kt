package com.restaurant.model.api.response.shipping.district

import com.restaurant.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DistrictResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("district_cat_list")
    @Expose
    var districtList: List<DistrictList>? = null

}