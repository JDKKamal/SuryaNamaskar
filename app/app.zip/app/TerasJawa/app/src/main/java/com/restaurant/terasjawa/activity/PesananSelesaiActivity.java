package com.restaurant.terasjawa.activity;

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import android.os.Bundle;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;

import com.restaurant.baseclass.BaseActivity;
import com.restaurant.terasjawa.R;

public class PesananSelesaiActivity extends BaseActivity {
    private Toolbar toolBar;
    private AppCompatTextView appTvTitle;
    private AppCompatImageView appIvDrawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesanan_selesai);

        //bindViews();
        hideSoftKeyboard();

        toolBar = findViewById(R.id.toolBar);
        setSupportActionBar(toolBar);
        toolBar.findViewById(R.id.appIvDrawer);

        appTvTitle = toolBar.findViewById(R.id.appTvTitle);
        appIvDrawer = toolBar.findViewById(R.id.appIvDrawer);
        appTvTitle.setText("PESANAN ANDA");
        appIvDrawer.setOnClickListener(v -> getActivity().finish());
    }
}
