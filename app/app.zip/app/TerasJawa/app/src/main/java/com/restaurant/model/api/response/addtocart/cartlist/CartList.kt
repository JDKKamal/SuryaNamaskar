package com.restaurant.model.api.response.addtocart.cartlist

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CartList {

    @SerializedName("cart_id")
    @Expose
    var cartId: String? = null
    @SerializedName("user_id")
    @Expose
    var userId: String? = null
    @SerializedName("rest_id")
    @Expose
    val restId: String? = null
    @SerializedName("menu_id")
    @Expose
    var menuId: String? = null
    @SerializedName("menu_name")
    @Expose
    var menuName: String? = null
    @SerializedName("menu_image")
    @Expose
    var menuImage: String? = null
    @SerializedName("menu_qty")
    @Expose
    var menuQty: String? = null
    @SerializedName("menu_price")
    @Expose
    var menuPrice: String? = null

}