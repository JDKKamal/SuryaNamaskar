package com.restaurant.connection

/*
   DEVELOPED BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/

import com.restaurant.model.api.response.DefaultResponse
import com.restaurant.model.api.response.addtocart.cartlist.CartListResponse
import com.restaurant.model.api.response.comment.commentlist.CommentResponse
import com.restaurant.model.api.response.comment.commentview.CommentViewResponse
import com.restaurant.model.api.response.comment.like.LikeResponse
import com.restaurant.model.api.response.comment.logincomment.LoginCommentResponse
import com.restaurant.model.api.response.comment.subcomment.SubCommentResponse
import com.restaurant.model.api.response.comment.unlike.UnLikeResponse
import com.restaurant.model.api.response.forgotpassword.ForgotPasswordResponse
import com.restaurant.model.api.response.login.LoginResponse
import com.restaurant.model.api.response.menu.MenuResponse
import com.restaurant.model.api.response.menucategory.MenuCategoryResponse
import com.restaurant.model.api.response.profile.ProfileResponse
import com.restaurant.model.api.response.promo.PromoResponse
import com.restaurant.model.api.response.shipping.country.CountryResponse
import com.restaurant.model.api.response.shipping.district.DistrictResponse
import com.restaurant.model.api.response.shipping.orderdelivery.OrderDeliveryResponse
import com.restaurant.model.api.response.signup.SignUpResponse
import com.restaurant.model.api.response.signup.facebook.FacebookResponse
import com.restaurant.model.api.response.signup.gmail.GmailSignUpResponse
import com.restaurant.model.api.response.signup.twitter.TwitterSignUpResponse
import com.restaurant.model.api.response.slider.SliderResponse
import io.reactivex.Observable
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*
import kotlin.collections.HashMap

interface RestService {
    @POST
    @FormUrlEncoded
    fun apiPostLogin(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<LoginResponse>

    @POST
    @FormUrlEncoded
    fun apiPostSignUp(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<SignUpResponse>

    @POST
    @FormUrlEncoded
    fun apiPostFacebookSignUp(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<FacebookResponse>

    @POST
    @FormUrlEncoded
    fun apiPostGooglePlusSignUp(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<GmailSignUpResponse>

    @POST
    @FormUrlEncoded
    fun apiPostTwitterSignUp(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<TwitterSignUpResponse>

    @POST
    @FormUrlEncoded
    fun apiPostForgotPassword(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<ForgotPasswordResponse>

    @GET
    fun apiGetMenuList(@Url url: String): Observable<MenuResponse>

    @GET
    fun apiGetMenuCategory(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<MenuCategoryResponse>

    @GET
    fun apiGetSliderList(@Url url: String): Observable<SliderResponse>

    @GET
    fun apiGetAddToCart(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<DefaultResponse>

    @GET
    fun apiGetAddToCartList(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<CartListResponse>

    @GET
    fun apiGetDeleteCartItem(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<DefaultResponse>

    @GET
    fun apiGetUpdateCartItem(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<DefaultResponse>

    @POST
    @Multipart
    fun apiPostProfile(@Url url: String, @Part image: MultipartBody.Part,
                       @Part("user_id") userid: RequestBody,
                       @Part("name") name: RequestBody,
                       @Part("email") email: RequestBody,
                       @Part("password") password: RequestBody,
                       @Part("phone") mobile: RequestBody,
                       @Part("address") address: RequestBody): Observable<ProfileResponse>

    @GET
    fun apiGetCountryList(@Url url: String): Observable<CountryResponse>

    @GET
    fun apiGetDistrictList(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<DistrictResponse>

    @POST
    @FormUrlEncoded
    fun apiPostOrderDelivery(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<OrderDeliveryResponse>

    @GET
    fun apiGetLoginComment(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<LoginCommentResponse>

    @GET
    fun apiGetPromo(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<PromoResponse>

    @POST
    @FormUrlEncoded
    fun apiPostCommentList(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<CommentResponse>

    @POST
    @FormUrlEncoded
    fun apiPostSubComment(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<SubCommentResponse>

    @POST
    @FormUrlEncoded
    fun apiPostLike(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<LikeResponse>

    @POST
    @FormUrlEncoded
    fun apiPostUnLike(@Url url: String, @FieldMap params: HashMap<String, String>): Observable<UnLikeResponse>

    @GET
    fun apiGetCommentView(@Url url: String, @QueryMap param: HashMap<String, String>): Observable<CommentViewResponse>

}


